rm(list = ls())
options(digits = 4)
#### Add Libraries ####
library(readxl)
library(ez)
library(gdata)
library(afex)
library(emmeans)
library(car)
library(lmerTest)
library(tidyverse)
library(reshape2)
library(ggplot2)

#### Load Data table ####
dm = read_excel("./SRM_Output_StatsTable.xlsx",sheet = 1)
savepath = file.path("./")

setwd(savepath)
#### specify variables #### 
# Variable names may be different that default output from SRM_final.m see README.txt
# Factors (participant, magnitude, sex)
dm$Participant = as.factor(dm$Participant)
dm$mag = as.factor(dm$mag)
dm$Sat = as.factor(dm$Sat)
dm$Sex = as.factor(dm$Sex)

# Participant characteristics/scores (height, etc.)
dm$Height = as.numeric(dm$Height)
dm$Weight = as.numeric(dm$Weight)

# EEG Outcome Measures (ERSP peak value, Area under curve, N1)
dm$N1_amp = as.numeric(dm$N1_amp)
dm$N1_latency = as.numeric(dm$N1_latency)
dm$N1_amp_150_50 = as.numeric(dm$N1_amp_150_50)

dm$beta_0_500 = as.numeric(dm$beta_0_500)
dm$beta_50_150 = as.numeric(dm$beta_50_150)
dm$beta_150_250 = as.numeric(dm$beta_150_250)
dm$beta_250_500 = as.numeric(dm$beta_250_500)
dm$Beta_AUC = as.numeric(dm$Beta_AUC)
dm$Beta_AUC_0_500 = as.numeric(dm$Beta_AUC_0_500)
dm$Beta_AUC_50_150 = as.numeric(dm$Beta_AUC_50_150)
dm$Beta_AUC_150_250 = as.numeric(dm$Beta_AUC_150_250)
dm$Beta_AUC_250_500 = as.numeric(dm$Beta_AUC_250_500)

dm$gamma_0_500 = as.numeric(dm$gamma_0_500)
dm$gamma_50_150 = as.numeric(dm$gamma_50_150)
dm$gamma_150_250 = as.numeric(dm$gamma_150_250)
dm$gamma_250_500 = as.numeric(dm$gamma_250_500)

dm$alpha_0_500 = as.numeric(dm$alpha_0_500)
dm$alpha_50_150 = as.numeric(dm$alpha_50_150)
dm$alpha_150_250 = as.numeric(dm$alpha_150_250)
dm$alpha_250_500 = as.numeric(dm$alpha_250_500)

dm$theta_0_500 = as.numeric(dm$theta_0_500)
dm$theta_50_150 = as.numeric(dm$theta_50_150)
dm$theta_150_250 = as.numeric(dm$theta_150_250)
dm$theta_250_500 = as.numeric(dm$theta_250_500)

# EMG Output Measures (Area under curve)
dm$MGL_AUC = as.numeric(dm$MGL_AUC)
dm$MGL_AUC_0_500 = as.numeric(dm$MGL_AUC_0_500)
dm$MGL_AUC_50_150 = as.numeric(dm$MGL_AUC_50_150)
dm$MGL_AUC_150_250 = as.numeric(dm$MGL_AUC_150_250)
dm$MGL_AUC_250_500 = as.numeric(dm$MGL_AUC_250_500)
dm$MGL_AUC_75_200 = as.numeric(dm$MGL_AUC_75_200)
dm$MGL_AUC_200_300 = as.numeric(dm$MGL_AUC_200_300)
dm$MGL_AUC_300_500 = as.numeric(dm$MGL_AUC_300_500)

dm$TAL_AUC = as.numeric(dm$TAL_AUC)
dm$TAL_AUC_0_500 = as.numeric(dm$TAL_AUC_0_500)
dm$TAL_AUC_50_150 = as.numeric(dm$TAL_AUC_50_150)
dm$TAL_AUC_150_250 = as.numeric(dm$TAL_AUC_150_250)
dm$TAL_AUC_250_500 = as.numeric(dm$TAL_AUC_250_500)

dm$Residual_AUC = as.numeric(dm$Residual_AUC)
dm$Residual_AUC_0_500 = as.numeric(dm$Residual_AUC_0_500)
dm$Residual_AUC_50_150 = as.numeric(dm$Residual_AUC_50_150)
dm$Residual_AUC_150_250 = as.numeric(dm$Residual_AUC_150_250)
dm$Residual_AUC_250_500 = as.numeric(dm$Residual_AUC_250_500)

dm$IB_sat = as.logical(dm$IB_sat)
dm$IB_max = as.numeric(dm$IB_max)

# cSRM (Beta) Recon Stats & Feedback Gains
dm$fit_beta_R2 = as.numeric(dm$fit_beta_R2)
dm$fit_beta_VAF = as.numeric(dm$fit_beta_VAF)
dm$Beta_Gains_ka = as.numeric(dm$Beta_Gains_ka)
dm$Beta_Gains_kd = as.numeric(dm$Beta_Gains_kd)
dm$Beta_Gains_kv = as.numeric(dm$Beta_Gains_kv)
dm$Beta_Gains_lambda = as.numeric(dm$Beta_Gains_lambda)

# cSRM (Cz) Recon Stats & Feedback Gains
dm$fit_Cz_R2 = as.numeric(dm$fit_Cz_R2)
dm$fit_Cz_VAF = as.numeric(dm$fit_Cz_VAF)
dm$Cz_Gains_ka = as.numeric(dm$Cz_Gains_ka)
dm$Cz_Gains_kv = as.numeric(dm$Cz_Gains_kv)
dm$Cz_Gains_kd = as.numeric(dm$Cz_Gains_kd)
dm$Cz_Gains_lambda = as.numeric(dm$Cz_Gains_lambda)

# mSRM Recon Stats & Feedback Gains
dm$fit_agonist_R2 = as.numeric(dm$fit_agonist_R2)
dm$fit_agonist_VAF = as.numeric(dm$fit_agonist_VAF)
dm$Ag_Gains_ka = as.numeric(dm$Ag_Gains_ka)
dm$Ag_Gains_kd = as.numeric(dm$Ag_Gains_kd)
dm$Ag_Gains_kv = as.numeric(dm$Ag_Gains_kv)
dm$Ag_Gains_lambda = as.numeric(dm$Ag_Gains_lambda)

# dSRM (Beta) Recon Stats & Feedback Gains
dm$fit_agonist_TotalDual_beta_R2 = as.numeric(dm$fit_agonist_TotalDual_beta_R2)
dm$fit_agonist_TotalDual_beta_VAF = as.numeric(dm$fit_agonist_TotalDual_beta_VAF)
dm$Ag_Gains_TotalDual_beta_ka = as.numeric(dm$Ag_Gains_TotalDual_beta_ka)
dm$Ag_Gains_TotalDual_beta_kv = as.numeric(dm$Ag_Gains_TotalDual_beta_kv)
dm$Ag_Gains_TotalDual_beta_kd = as.numeric(dm$Ag_Gains_TotalDual_beta_kd)
dm$Ag_Gains_TotalDual_beta_lambda1 = as.numeric(dm$Ag_Gains_TotalDual_beta_lambda1)
dm$Ag_Gains_TotalDual_beta_kb = as.numeric(dm$Ag_Gains_TotalDual_beta_kb)
dm$Ag_Gains_TotalDual_beta_lambda2 = as.numeric(dm$Ag_Gains_TotalDual_beta_lambda2)

# dSRM (Cz) Recon Stats & Feedback Gains 
dm$fit_agonist_TotalDual_Cz_R2 = as.numeric(dm$fit_agonist_TotalDual_Cz_R2)
dm$fit_agonist_TotalDual_Cz_VAF = as.numeric(dm$fit_agonist_TotalDual_Cz_VAF)
dm$Ag_Gains_TotalDual_Cz_ka = as.numeric(dm$Ag_Gains_TotalDual_Cz_ka)
dm$Ag_Gains_TotalDual_Cz_kv = as.numeric(dm$Ag_Gains_TotalDual_Cz_kv)
dm$Ag_Gains_TotalDual_Cz_kd = as.numeric(dm$Ag_Gains_TotalDual_Cz_kd)
dm$Ag_Gains_TotalDual_Cz_lambda1 = as.numeric(dm$Ag_Gains_TotalDual_Cz_lambda1)
dm$Ag_Gains_TotalDual_Cz_kCz = as.numeric(dm$Ag_Gains_TotalDual_Cz_kCz)
dm$Ag_Gains_TotalDual_Cz_lambda2 = as.numeric(dm$Ag_Gains_TotalDual_Cz_lambda2)

# dSRM (CoM) Recon Stats & Feedback Gains
dm$fit_agonist_TotalDual_CoM_R2 = as.numeric(dm$fit_agonist_TotalDual_CoM_R2)
dm$fit_agonist_TotalDual_CoM_VAF = as.numeric(dm$fit_agonist_TotalDual_CoM_VAF)
dm$Ag_Gains_TotalDual_CoM_ka1 = as.numeric(dm$Ag_Gains_TotalDual_CoM_ka1)
dm$Ag_Gains_TotalDual_CoM_kv1 = as.numeric(dm$Ag_Gains_TotalDual_CoM_kv1)
dm$Ag_Gains_TotalDual_CoM_kd1 = as.numeric(dm$Ag_Gains_TotalDual_CoM_kd1)
dm$Ag_Gains_TotalDual_CoM_lambda1 = as.numeric(dm$Ag_Gains_TotalDual_CoM_lambda1)
dm$Ag_Gains_TotalDual_CoM_ka2 = as.numeric(dm$Ag_Gains_TotalDual_CoM_ka2)
dm$Ag_Gains_TotalDual_CoM_kv2 = as.numeric(dm$Ag_Gains_TotalDual_CoM_kv2)
dm$Ag_Gains_TotalDual_CoM_kd2 = as.numeric(dm$Ag_Gains_TotalDual_CoM_kd2)
dm$Ag_Gains_TotalDual_CoM_lambda2 = as.numeric(dm$Ag_Gains_TotalDual_CoM_lambda2)

####### Beta ERSP Peak Value vs Perturbation Magnitude/Balance ability #######
## Beta 0-500ms vs Perturbation Magnitude ####
# Use lmer b/c some participants are missing mag 3 data
Beta_0_500_pert_mag = lmer(beta_0_500 ~ mag + (1|Participant), data = dm)
print(Beta_0_500_pert_mag)
summary(Beta_0_500_pert_mag)
emmeans(Beta_0_500_pert_mag,pairwise~mag)
VarCorr(Beta_0_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_0_500) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("beta_0_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_0_500) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("beta_0_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_0_500) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_0_500_vs_pert_mag.txt")
summary(Beta_0_500_pert_mag)
emmeans(Beta_0_500_pert_mag,pairwise~mag)
sink()



## Beta 50-150ms vs Perturbation Magnitude ####
Beta_50_150_pert_mag = lmer(beta_50_150 ~ mag + (1|Participant), data = dm)
print(Beta_50_150_pert_mag)
summary(Beta_50_150_pert_mag)
emmeans(Beta_50_150_pert_mag,pairwise~mag)
VarCorr(Beta_50_150_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_50_150) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("beta_50_150_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_50_150) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("beta_50_150_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_50_150) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("beta_50_150_vs_pert_mag.txt")
summary(Beta_50_150_pert_mag)
emmeans(Beta_50_150_pert_mag,pairwise~mag)
sink()



## Beta 150-250ms vs Perturbation Magnitude ####
Beta_150_250_pert_mag = lmer(beta_150_250 ~ mag + (1|Participant), data = dm)
print(Beta_150_250_pert_mag)
summary(Beta_150_250_pert_mag)
emmeans(Beta_150_250_pert_mag,pairwise~mag)
VarCorr(Beta_150_250_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_150_250) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("beta_150_250_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_150_250) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("beta_150_250_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_150_250) + ylim(0, 20)#+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_150_250_vs_pert_mag.txt")
summary(Beta_150_250_pert_mag)
emmeans(Beta_150_250_pert_mag,pairwise~mag)
sink()


## Beta 250-500ms vs Perturbation Magnitude ####
Beta_250_500_pert_mag = lmer(beta_250_500 ~ mag + (1|Participant), data = dm)
print(Beta_250_500_pert_mag)
summary(Beta_250_500_pert_mag)
emmeans(Beta_250_500_pert_mag,pairwise~mag)
VarCorr(Beta_250_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_250_500) + ylim(0, 20)# + geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("beta_250_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_250_500) + ylim(0, 20)# + geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("beta_250_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = beta_250_500) + ylim(0, 20)# + geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_250_500_vs_pert_mag.txt")
summary(Beta_250_500_pert_mag)
emmeans(Beta_250_500_pert_mag,pairwise~mag)
sink()



###### Beta Area Under Curve vs pert Mag/Balance ability ######
## Beta AUC whole time series vs Perturbation Magnitude ####
Beta_AUC_pert_mag = lmer(Beta_AUC ~ mag + (1|Participant), data = dm)
print(Beta_AUC_pert_mag)
summary(Beta_AUC_pert_mag)
emmeans(Beta_AUC_pert_mag,pairwise~mag)
VarCorr(Beta_AUC_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("Beta_AUC_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("Beta_AUC_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_AUC_vs_pert_mag.txt")
summary(Beta_AUC_pert_mag)
emmeans(Beta_AUC_pert_mag,pairwise~mag)
sink()

# ANOVA
Beta_AUC_pert_mag_aov_car = aov_car(Beta_AUC ~ mag + Error(Participant/mag), data = dm)
shapiro.test(Beta_AUC_pert_mag_aov_car$lm$residuals)
qqPlot(Beta_AUC_pert_mag_aov_car$lm$residuals)
afex_plot(Beta_AUC_pert_mag_aov_car, x = "mag")
print(Beta_AUC_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(Beta_AUC_pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_pert_mag_aov_car))
pairs(emmeans(Beta_AUC_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("Beta_AUC_pert_mag_aov_car.txt")
emmeans(Beta_AUC_pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_pert_mag_aov_car))
pairs(emmeans(Beta_AUC_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


## Beta AUC 0-500ms vs Perturbation Magnitude ####
# Use lmer b/c some participants are missing mag 3 data
Beta_AUC_0_500_pert_mag = lmer(Beta_AUC_0_500 ~ mag + (1|Participant), data = dm)
print(Beta_AUC_0_500_pert_mag)
summary(Beta_AUC_0_500_pert_mag)
emmeans(Beta_AUC_0_500_pert_mag,pairwise~mag)
VarCorr(Beta_AUC_0_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("Beta_AUC_0_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("Beta_AUC_0_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_AUC_0_500_vs_pert_mag.txt")
summary(Beta_AUC_0_500_pert_mag)
emmeans(Beta_AUC_0_500_pert_mag,pairwise~mag)
sink()

# ANOVA
Beta_AUC_0_500__pert_mag_aov_car = aov_car(Beta_AUC_0_500 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(Beta_AUC_0_500__pert_mag_aov_car$lm$residuals)
qqPlot(Beta_AUC_0_500__pert_mag_aov_car$lm$residuals)
afex_plot(Beta_AUC_0_500__pert_mag_aov_car, x = "mag")
print(Beta_AUC_0_500__pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(Beta_AUC_0_500__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_0_500__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_0_500__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("Beta_AUC_0_500__pert_mag_aov_car.txt")
emmeans(Beta_AUC_0_500__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_0_500__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_0_500__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## Beta AUC 50-150ms vs Perturbation Magnitude ####
Beta_AUC_50_150_pert_mag = lmer(Beta_AUC_50_150 ~ mag + (1|Participant), data = dm)
print(Beta_AUC_50_150_pert_mag)
summary(Beta_AUC_50_150_pert_mag)
emmeans(Beta_AUC_50_150_pert_mag,pairwise~mag)
VarCorr(Beta_AUC_50_150_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_50_150) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("Beta_AUC_50_150_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_50_150) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("Beta_AUC_50_150_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_50_150) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_AUC_50_150_vs_pert_mag.txt")
summary(Beta_AUC_50_150_pert_mag)
emmeans(Beta_AUC_50_150_pert_mag,pairwise~mag)
sink()

# ANOVA
Beta_AUC_50_150__pert_mag_aov_car = aov_car(Beta_AUC_50_150 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(Beta_AUC_50_150__pert_mag_aov_car$lm$residuals)
qqPlot(Beta_AUC_50_150__pert_mag_aov_car$lm$residuals)
afex_plot(Beta_AUC_50_150__pert_mag_aov_car, x = "mag")
print(Beta_AUC_50_150__pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(Beta_AUC_50_150__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_50_150__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_50_150__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("Beta_AUC_50_150__pert_mag_aov_car.txt")
emmeans(Beta_AUC_50_150__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_50_150__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_50_150__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## Beta AUC 150-250ms vs Perturbation Magnitude ####
Beta_AUC_150_250_pert_mag = lmer(Beta_AUC_150_250 ~ mag + (1|Participant), data = dm)
print(Beta_AUC_150_250_pert_mag)
summary(Beta_AUC_150_250_pert_mag)
emmeans(Beta_AUC_150_250_pert_mag,pairwise~mag)
VarCorr(Beta_AUC_150_250_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_150_250) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("Beta_AUC_150_250_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_150_250) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("Beta_AUC_150_250_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_150_250) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_AUC_150_250_vs_pert_mag.txt")
summary(Beta_AUC_150_250_pert_mag)
emmeans(Beta_AUC_150_250_pert_mag,pairwise~mag)
sink()

# ANOVA
Beta_AUC_150_250__pert_mag_aov_car = aov_car(Beta_AUC_150_250 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(Beta_AUC_150_250__pert_mag_aov_car$lm$residuals)
qqPlot(Beta_AUC_150_250__pert_mag_aov_car$lm$residuals)
afex_plot(Beta_AUC_150_250__pert_mag_aov_car, x = "mag")
print(Beta_AUC_150_250__pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(Beta_AUC_150_250__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_150_250__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_150_250__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("Beta_AUC_150_250__pert_mag_aov_car.txt")
emmeans(Beta_AUC_150_250__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_150_250__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_150_250__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## Beta AUC 250-500ms vs Perturbation Magnitude ####
Beta_AUC_250_500_pert_mag = lmer(Beta_AUC_250_500 ~ mag + (1|Participant), data = dm)
print(Beta_AUC_250_500_pert_mag)
summary(Beta_AUC_250_500_pert_mag)
emmeans(Beta_AUC_250_500_pert_mag,pairwise~mag)
VarCorr(Beta_AUC_250_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_250_500) # + geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("Beta_AUC_250_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_250_500) # + geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("Beta_AUC_250_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_AUC_250_500) # + geom_point(aes(color = Participant, size = 10))
dev.off()
sink("Beta_AUC_250_500_vs_pert_mag.txt")
summary(Beta_AUC_250_500_pert_mag)
emmeans(Beta_AUC_250_500_pert_mag,pairwise~mag)
sink()

# ANOVA
Beta_AUC_250_500__pert_mag_aov_car = aov_car(Beta_AUC_250_500 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(Beta_AUC_250_500__pert_mag_aov_car$lm$residuals)
qqPlot(Beta_AUC_250_500__pert_mag_aov_car$lm$residuals)
afex_plot(Beta_AUC_250_500__pert_mag_aov_car, x = "mag")
print(Beta_AUC_250_500__pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(Beta_AUC_250_500__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_250_500__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_250_500__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("Beta_AUC_250_500__pert_mag_aov_car.txt")
emmeans(Beta_AUC_250_500__pert_mag_aov_car,~mag)
knitr::kable(nice(Beta_AUC_250_500__pert_mag_aov_car))
pairs(emmeans(Beta_AUC_250_500__pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

####### cSRM (Beta) vs EEG outcomes #######
## cSRM (Beta) Recon vs evoked beta_0_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_beta_0_500 = lmer(fit_beta_R2 ~ mag*beta_0_500 + (1|Participant), data = dm)
print(cSRM_beta_R2_beta_0_500)
summary(cSRM_beta_R2_beta_0_500)
emmeans(cSRM_beta_R2_beta_0_500,pairwise~mag)
VarCorr(cSRM_beta_R2_beta_0_500)
tmp = summary(cSRM_beta_R2_beta_0_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_0_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_beta_0_500.txt")
summary(cSRM_beta_R2_beta_0_500)
emmeans(cSRM_beta_R2_beta_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_beta_0_500 = lmer(fit_beta_VAF ~ mag*beta_0_500 + (1|Participant), data = dm)
print(cSRM_beta_VAF_beta_0_500)
summary(cSRM_beta_VAF_beta_0_500)
emmeans(cSRM_beta_VAF_beta_0_500,pairwise~mag)
VarCorr(cSRM_beta_VAF_beta_0_500)
tmp = summary(cSRM_beta_VAF_beta_0_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_0_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_beta_0_500.txt")
summary(cSRM_beta_VAF_beta_0_500)
emmeans(cSRM_beta_VAF_beta_0_500,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked beta_50_150 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_beta_50_150 = lmer(fit_beta_R2 ~ mag*beta_50_150 + (1|Participant), data = dm)
print(cSRM_beta_R2_beta_50_150)
summary(cSRM_beta_R2_beta_50_150)
emmeans(cSRM_beta_R2_beta_50_150,pairwise~mag)
VarCorr(cSRM_beta_R2_beta_50_150)
tmp = summary(cSRM_beta_R2_beta_50_150)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_50_150, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_beta_50_150.txt")
summary(cSRM_beta_R2_beta_50_150)
emmeans(cSRM_beta_R2_beta_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_beta_50_150 = lmer(fit_beta_VAF ~ mag*beta_50_150 + (1|Participant), data = dm)
print(cSRM_beta_VAF_beta_50_150)
summary(cSRM_beta_VAF_beta_50_150)
emmeans(cSRM_beta_VAF_beta_50_150,pairwise~mag)
VarCorr(cSRM_beta_VAF_beta_50_150)
tmp = summary(cSRM_beta_VAF_beta_50_150)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_50_150, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_beta_50_150.txt")
summary(cSRM_beta_VAF_beta_50_150)
emmeans(cSRM_beta_VAF_beta_50_150,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked beta_150_250 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_beta_150_250 = lmer(fit_beta_R2 ~ mag*beta_150_250 + (1|Participant), data = dm)
print(cSRM_beta_R2_beta_150_250)
summary(cSRM_beta_R2_beta_150_250)
emmeans(cSRM_beta_R2_beta_150_250,pairwise~mag)
VarCorr(cSRM_beta_R2_beta_150_250)
tmp = summary(cSRM_beta_R2_beta_150_250)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_150_250, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_beta_150_250.txt")
summary(cSRM_beta_R2_beta_150_250)
emmeans(cSRM_beta_R2_beta_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_beta_150_250 = lmer(fit_beta_VAF ~ mag*beta_150_250 + (1|Participant), data = dm)
print(cSRM_beta_VAF_beta_150_250)
summary(cSRM_beta_VAF_beta_150_250)
emmeans(cSRM_beta_VAF_beta_150_250,pairwise~mag)
VarCorr(cSRM_beta_VAF_beta_150_250)
tmp = summary(cSRM_beta_VAF_beta_150_250)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_150_250, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_beta_150_250.txt")
summary(cSRM_beta_VAF_beta_150_250)
emmeans(cSRM_beta_VAF_beta_150_250,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked beta_250_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_beta_250_500 = lmer(fit_beta_R2 ~ mag*beta_250_500 + (1|Participant), data = dm)
print(cSRM_beta_R2_beta_250_500)
summary(cSRM_beta_R2_beta_250_500)
emmeans(cSRM_beta_R2_beta_250_500,pairwise~mag)
VarCorr(cSRM_beta_R2_beta_250_500)
tmp = summary(cSRM_beta_R2_beta_250_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_250_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_beta_250_500.txt")
summary(cSRM_beta_R2_beta_250_500)
emmeans(cSRM_beta_R2_beta_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_beta_250_500 = lmer(fit_beta_VAF ~ mag*beta_250_500 + (1|Participant), data = dm)
print(cSRM_beta_VAF_beta_250_500)
summary(cSRM_beta_VAF_beta_250_500)
emmeans(cSRM_beta_VAF_beta_250_500,pairwise~mag)
VarCorr(cSRM_beta_VAF_beta_250_500)
tmp = summary(cSRM_beta_VAF_beta_250_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_250_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_beta_250_500.txt")
summary(cSRM_beta_VAF_beta_250_500)
emmeans(cSRM_beta_VAF_beta_250_500,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked Beta_AUC lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_Beta_AUC = lmer(fit_beta_R2 ~ mag*Beta_AUC + (1|Participant), data = dm)
print(cSRM_beta_R2_Beta_AUC)
summary(cSRM_beta_R2_Beta_AUC)
emmeans(cSRM_beta_R2_Beta_AUC,pairwise~mag)
VarCorr(cSRM_beta_R2_Beta_AUC)
tmp = summary(cSRM_beta_R2_Beta_AUC)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4] 
ggplot(dm) + aes(x = Beta_AUC, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_Beta_AUC.txt")
summary(cSRM_beta_R2_Beta_AUC)
emmeans(cSRM_beta_R2_Beta_AUC,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_Beta_AUC = lmer(fit_beta_VAF ~ mag*Beta_AUC + (1|Participant), data = dm)
print(cSRM_beta_VAF_Beta_AUC)
summary(cSRM_beta_VAF_Beta_AUC)
emmeans(cSRM_beta_VAF_Beta_AUC,pairwise~mag)
VarCorr(cSRM_beta_VAF_Beta_AUC)
tmp = summary(cSRM_beta_VAF_Beta_AUC)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = Beta_AUC, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_Beta_AUC.txt")
summary(cSRM_beta_VAF_Beta_AUC)
emmeans(cSRM_beta_VAF_Beta_AUC,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked Beta_AUC_0_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_Beta_AUC_0_500 = lmer(fit_beta_R2 ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(cSRM_beta_R2_Beta_AUC_0_500)
summary(cSRM_beta_R2_Beta_AUC_0_500)
emmeans(cSRM_beta_R2_Beta_AUC_0_500,pairwise~mag)
VarCorr(cSRM_beta_R2_Beta_AUC_0_500)
tmp = summary(cSRM_beta_R2_Beta_AUC_0_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_Beta_AUC_0_500.txt")
summary(cSRM_beta_R2_Beta_AUC_0_500)
emmeans(cSRM_beta_R2_Beta_AUC_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_Beta_AUC_0_500 = lmer(fit_beta_VAF ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(cSRM_beta_VAF_Beta_AUC_0_500)
summary(cSRM_beta_VAF_Beta_AUC_0_500)
emmeans(cSRM_beta_VAF_Beta_AUC_0_500,pairwise~mag)
VarCorr(cSRM_beta_VAF_Beta_AUC_0_500)
tmp = summary(cSRM_beta_VAF_Beta_AUC_0_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]      
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_Beta_AUC_0_500.txt")
summary(cSRM_beta_VAF_Beta_AUC_0_500)
emmeans(cSRM_beta_VAF_Beta_AUC_0_500,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked Beta_AUC_50_150 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_Beta_AUC_50_150 = lmer(fit_beta_R2 ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(cSRM_beta_R2_Beta_AUC_50_150)
summary(cSRM_beta_R2_Beta_AUC_50_150)
emmeans(cSRM_beta_R2_Beta_AUC_50_150,pairwise~mag)
VarCorr(cSRM_beta_R2_Beta_AUC_50_150)
tmp = summary(cSRM_beta_R2_Beta_AUC_50_150)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]      
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_Beta_AUC_50_150.txt")
summary(cSRM_beta_R2_Beta_AUC_50_150)
emmeans(cSRM_beta_R2_Beta_AUC_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_Beta_AUC_50_150 = lmer(fit_beta_VAF ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(cSRM_beta_VAF_Beta_AUC_50_150)
summary(cSRM_beta_VAF_Beta_AUC_50_150)
emmeans(cSRM_beta_VAF_Beta_AUC_50_150,pairwise~mag)
VarCorr(cSRM_beta_VAF_Beta_AUC_50_150)
tmp = summary(cSRM_beta_VAF_Beta_AUC_50_150)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_Beta_AUC_50_150.txt")
summary(cSRM_beta_VAF_Beta_AUC_50_150)
emmeans(cSRM_beta_VAF_Beta_AUC_50_150,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked Beta_AUC_150_250 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_Beta_AUC_150_250 = lmer(fit_beta_R2 ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(cSRM_beta_R2_Beta_AUC_150_250)
summary(cSRM_beta_R2_Beta_AUC_150_250)
emmeans(cSRM_beta_R2_Beta_AUC_150_250,pairwise~mag)
VarCorr(cSRM_beta_R2_Beta_AUC_150_250)
tmp = summary(cSRM_beta_R2_Beta_AUC_150_250)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_Beta_AUC_150_250.txt")
summary(cSRM_beta_R2_Beta_AUC_150_250)
emmeans(cSRM_beta_R2_Beta_AUC_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_Beta_AUC_150_250 = lmer(fit_beta_VAF ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(cSRM_beta_VAF_Beta_AUC_150_250)
summary(cSRM_beta_VAF_Beta_AUC_150_250)
emmeans(cSRM_beta_VAF_Beta_AUC_150_250,pairwise~mag)
VarCorr(cSRM_beta_VAF_Beta_AUC_150_250)
tmp = summary(cSRM_beta_VAF_Beta_AUC_150_250)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]         
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_Beta_AUC_150_250.txt")
summary(cSRM_beta_VAF_Beta_AUC_150_250)
emmeans(cSRM_beta_VAF_Beta_AUC_150_250,pairwise~mag)
sink()

## cSRM (Beta) Recon vs evoked Beta_AUC_250_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_Beta_AUC_250_500 = lmer(fit_beta_R2 ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(cSRM_beta_R2_Beta_AUC_250_500)
summary(cSRM_beta_R2_Beta_AUC_250_500)
emmeans(cSRM_beta_R2_Beta_AUC_250_500,pairwise~mag)
VarCorr(cSRM_beta_R2_Beta_AUC_250_500)
tmp = summary(cSRM_beta_R2_Beta_AUC_250_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_Beta_AUC_250_500.txt")
summary(cSRM_beta_R2_Beta_AUC_250_500)
emmeans(cSRM_beta_R2_Beta_AUC_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_Beta_AUC_250_500 = lmer(fit_beta_VAF ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(cSRM_beta_VAF_Beta_AUC_250_500)
summary(cSRM_beta_VAF_Beta_AUC_250_500)
emmeans(cSRM_beta_VAF_Beta_AUC_250_500,pairwise~mag)
VarCorr(cSRM_beta_VAF_Beta_AUC_250_500)
tmp = summary(cSRM_beta_VAF_Beta_AUC_250_500)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_Beta_AUC_250_500.txt")
summary(cSRM_beta_VAF_Beta_AUC_250_500)
emmeans(cSRM_beta_VAF_Beta_AUC_250_500,pairwise~mag)
sink()


## cSRM (Beta) Recon vs evoked N1_amp lmer ####
# R2
# fit linear model for beta recon
cSRM_beta_R2_N1_amp = lmer(fit_beta_R2 ~ mag*N1_amp + (1|Participant), data = dm)
print(cSRM_beta_R2_N1_amp)
summary(cSRM_beta_R2_N1_amp)
emmeans(cSRM_beta_R2_N1_amp,pairwise~mag)
VarCorr(cSRM_beta_R2_N1_amp)
tmp = summary(cSRM_beta_R2_N1_amp)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = N1_amp, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_R2_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_R2_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_R2_vs_N1_amp.txt")
summary(cSRM_beta_R2_N1_amp)
emmeans(cSRM_beta_R2_N1_amp,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_beta_VAF_N1_amp = lmer(fit_beta_VAF ~ mag*N1_amp + (1|Participant), data = dm)
print(cSRM_beta_VAF_N1_amp)
summary(cSRM_beta_VAF_N1_amp)
emmeans(cSRM_beta_VAF_N1_amp,pairwise~mag)
VarCorr(cSRM_beta_VAF_N1_amp)
tmp = summary(cSRM_beta_VAF_N1_amp)
# plot linear model
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = N1_amp, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Beta_VAF_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Beta_VAF_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Beta_VAF_vs_N1_amp.txt")
summary(cSRM_beta_VAF_N1_amp)
emmeans(cSRM_beta_VAF_N1_amp,pairwise~mag)
sink()



###### cSRM (Cz) vs EEG Outcomes ######
## cSRM (Cz) Recon vs evoked beta_0_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_beta_0_500 = lmer(fit_Cz_R2 ~ mag*beta_0_500 + (1|Participant), data = dm)
print(cSRM_Cz_R2_beta_0_500)
tmp = summary(cSRM_Cz_R2_beta_0_500)
summary(cSRM_Cz_R2_beta_0_500)
emmeans(cSRM_Cz_R2_beta_0_500,pairwise~mag)
VarCorr(cSRM_Cz_R2_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_0_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_beta_0_500.txt")
summary(cSRM_Cz_R2_beta_0_500)
emmeans(cSRM_Cz_R2_beta_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_beta_0_500 = lmer(fit_Cz_VAF ~ mag*beta_0_500 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_beta_0_500)
summary(cSRM_Cz_VAF_beta_0_500)
tmp = summary(cSRM_Cz_VAF_beta_0_500)
emmeans(cSRM_Cz_VAF_beta_0_500,pairwise~mag)
VarCorr(cSRM_Cz_VAF_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = beta_0_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_beta_0_500.txt")
summary(cSRM_Cz_VAF_beta_0_500)
emmeans(cSRM_Cz_VAF_beta_0_500,pairwise~mag)
sink()

## cSRM (Cz) Recon vs evoked beta_50_150 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_beta_50_150 = lmer(fit_Cz_R2 ~ mag*beta_50_150 + (1|Participant), data = dm)
print(cSRM_Cz_R2_beta_50_150)
summary(cSRM_Cz_R2_beta_50_150)
tmp = summary(cSRM_Cz_R2_beta_50_150)
emmeans(cSRM_Cz_R2_beta_50_150,pairwise~mag)
VarCorr(cSRM_Cz_R2_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = beta_50_150, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_beta_50_150.txt")
summary(cSRM_Cz_R2_beta_50_150)
emmeans(cSRM_Cz_R2_beta_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_beta_50_150 = lmer(fit_Cz_VAF ~ mag*beta_50_150 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_beta_50_150)
summary(cSRM_Cz_VAF_beta_50_150)
tmp = summary(cSRM_Cz_VAF_beta_50_150)
emmeans(cSRM_Cz_VAF_beta_50_150,pairwise~mag)
VarCorr(cSRM_Cz_VAF_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = beta_50_150, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_beta_50_150.txt")
summary(cSRM_Cz_VAF_beta_50_150)
emmeans(cSRM_Cz_VAF_beta_50_150,pairwise~mag)
sink()

## cSRM (Cz) Recon vs evoked beta_150_250 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_beta_150_250 = lmer(fit_Cz_R2 ~ mag*beta_150_250 + (1|Participant), data = dm)
print(cSRM_Cz_R2_beta_150_250)
summary(cSRM_Cz_R2_beta_150_250)
tmp = summary(cSRM_Cz_R2_beta_150_250)
emmeans(cSRM_Cz_R2_beta_150_250,pairwise~mag)
VarCorr(cSRM_Cz_R2_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = beta_150_250, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_beta_150_250.txt")
summary(cSRM_Cz_R2_beta_150_250)
emmeans(cSRM_Cz_R2_beta_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_beta_150_250 = lmer(fit_Cz_VAF ~ mag*beta_150_250 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_beta_150_250)
summary(cSRM_Cz_VAF_beta_150_250)
tmp = summary(cSRM_Cz_VAF_beta_150_250)
emmeans(cSRM_Cz_VAF_beta_150_250,pairwise~mag)
VarCorr(cSRM_Cz_VAF_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]          
ggplot(dm) + aes(x = beta_150_250, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_beta_150_250.txt")
summary(cSRM_Cz_VAF_beta_150_250)
emmeans(cSRM_Cz_VAF_beta_150_250,pairwise~mag)
sink()

## cSRM (Cz) Recon vs evoked beta_250_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_beta_250_500 = lmer(fit_Cz_R2 ~ mag*beta_250_500 + (1|Participant), data = dm)
print(cSRM_Cz_R2_beta_250_500)
summary(cSRM_Cz_R2_beta_250_500)
tmp = summary(cSRM_Cz_R2_beta_250_500)
emmeans(cSRM_Cz_R2_beta_250_500,pairwise~mag)
VarCorr(cSRM_Cz_R2_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = beta_250_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_beta_250_500.txt")
summary(cSRM_Cz_R2_beta_250_500)
emmeans(cSRM_Cz_R2_beta_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_beta_250_500 = lmer(fit_Cz_VAF ~ mag*beta_250_500 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_beta_250_500)
summary(cSRM_Cz_VAF_beta_250_500)
tmp = summary(cSRM_Cz_VAF_beta_250_500)
emmeans(cSRM_Cz_VAF_beta_250_500,pairwise~mag)
VarCorr(cSRM_Cz_VAF_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = beta_250_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_beta_250_500.txt")
summary(cSRM_Cz_VAF_beta_250_500)
emmeans(cSRM_Cz_VAF_beta_250_500,pairwise~mag)
sink()

## cSRM (Cz) Recon vs evoked Beta_AUC lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_Beta_AUC = lmer(fit_Cz_R2 ~ mag*Beta_AUC + (1|Participant), data = dm)
print(cSRM_Cz_R2_Beta_AUC)
summary(cSRM_Cz_R2_Beta_AUC)
tmp = summary(cSRM_Cz_R2_Beta_AUC)
emmeans(cSRM_Cz_R2_Beta_AUC,pairwise~mag)
VarCorr(cSRM_Cz_R2_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = Beta_AUC, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_Beta_AUC.txt")
summary(cSRM_Cz_R2_Beta_AUC)
emmeans(cSRM_Cz_R2_Beta_AUC,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_Beta_AUC = lmer(fit_Cz_VAF ~ mag*Beta_AUC + (1|Participant), data = dm)
print(cSRM_Cz_VAF_Beta_AUC)
summary(cSRM_Cz_VAF_Beta_AUC)
tmp = summary(cSRM_Cz_VAF_Beta_AUC)
emmeans(cSRM_Cz_VAF_Beta_AUC,pairwise~mag)
VarCorr(cSRM_Cz_VAF_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]          
ggplot(dm) + aes(x = Beta_AUC, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_Beta_AUC.txt")
summary(cSRM_Cz_VAF_Beta_AUC)
emmeans(cSRM_Cz_VAF_Beta_AUC,pairwise~mag)
sink()

## cSRM (Cz) Recon vs evoked Beta_AUC_0_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_Beta_AUC_0_500 = lmer(fit_Cz_R2 ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(cSRM_Cz_R2_Beta_AUC_0_500)
tmp = summary(cSRM_Cz_R2_Beta_AUC_0_500)
summary(cSRM_Cz_R2_Beta_AUC_0_500)
emmeans(cSRM_Cz_R2_Beta_AUC_0_500,pairwise~mag)
VarCorr(cSRM_Cz_R2_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]           
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_Beta_AUC_0_500.txt")
summary(cSRM_Cz_R2_Beta_AUC_0_500)
emmeans(cSRM_Cz_R2_Beta_AUC_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_Beta_AUC_0_500 = lmer(fit_Cz_VAF ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_Beta_AUC_0_500)
summary(cSRM_Cz_VAF_Beta_AUC_0_500)
tmp = summary(cSRM_Cz_VAF_Beta_AUC_0_500)
emmeans(cSRM_Cz_VAF_Beta_AUC_0_500,pairwise~mag)
VarCorr(cSRM_Cz_VAF_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]         
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_Beta_AUC_0_500.txt")
summary(cSRM_Cz_VAF_Beta_AUC_0_500)
emmeans(cSRM_Cz_VAF_Beta_AUC_0_500,pairwise~mag)
sink()

## cSRM (CZ) Recon vs evoked Beta_AUC_50_150 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_Beta_AUC_50_150 = lmer(fit_Cz_R2 ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(cSRM_Cz_R2_Beta_AUC_50_150)
tmp = summary(cSRM_Cz_R2_Beta_AUC_50_150)
summary(cSRM_Cz_R2_Beta_AUC_50_150)
emmeans(cSRM_Cz_R2_Beta_AUC_50_150,pairwise~mag)
VarCorr(cSRM_Cz_R2_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]            
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_Beta_AUC_50_150.txt")
summary(cSRM_Cz_R2_Beta_AUC_50_150)
emmeans(cSRM_Cz_R2_Beta_AUC_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_Beta_AUC_50_150 = lmer(fit_Cz_VAF ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_Beta_AUC_50_150)
summary(cSRM_Cz_VAF_Beta_AUC_50_150)
tmp = summary(cSRM_Cz_VAF_Beta_AUC_50_150)
emmeans(cSRM_Cz_VAF_Beta_AUC_50_150,pairwise~mag)
VarCorr(cSRM_Cz_VAF_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]          
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_Beta_AUC_50_150.txt")
summary(cSRM_Cz_VAF_Beta_AUC_50_150)
emmeans(cSRM_Cz_VAF_Beta_AUC_50_150,pairwise~mag)
sink()

## cSRM (CZ) Recon vs evoked Beta_AUC_150_250 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_Beta_AUC_150_250 = lmer(fit_Cz_R2 ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(cSRM_Cz_R2_Beta_AUC_150_250)
summary(cSRM_Cz_R2_Beta_AUC_150_250)
tmp = summary(cSRM_Cz_R2_Beta_AUC_150_250)
emmeans(cSRM_Cz_R2_Beta_AUC_150_250,pairwise~mag)
VarCorr(cSRM_Cz_R2_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]           
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_Beta_AUC_150_250.txt")
summary(cSRM_Cz_R2_Beta_AUC_150_250)
emmeans(cSRM_Cz_R2_Beta_AUC_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_Beta_AUC_150_250 = lmer(fit_Cz_VAF ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_Beta_AUC_150_250)
summary(cSRM_Cz_VAF_Beta_AUC_150_250)
tmp = summary(cSRM_Cz_VAF_Beta_AUC_150_250)
emmeans(cSRM_Cz_VAF_Beta_AUC_150_250,pairwise~mag)
VarCorr(cSRM_Cz_VAF_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]            
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_Beta_AUC_150_250.txt")
summary(cSRM_Cz_VAF_Beta_AUC_150_250)
emmeans(cSRM_Cz_VAF_Beta_AUC_150_250,pairwise~mag)
sink()

## cSRM (Cz) Recon vs evoked Beta_AUC_250_500 lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_Beta_AUC_250_500 = lmer(fit_Cz_R2 ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(cSRM_Cz_R2_Beta_AUC_250_500)
summary(cSRM_Cz_R2_Beta_AUC_250_500)
tmp = summary(cSRM_Cz_R2_Beta_AUC_250_500)
emmeans(cSRM_Cz_R2_Beta_AUC_250_500,pairwise~mag)
VarCorr(cSRM_Cz_R2_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_Beta_AUC_250_500.txt")
summary(cSRM_Cz_R2_Beta_AUC_250_500)
emmeans(cSRM_Cz_R2_Beta_AUC_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_Beta_AUC_250_500 = lmer(fit_Cz_VAF ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(cSRM_Cz_VAF_Beta_AUC_250_500)
summary(cSRM_Cz_VAF_Beta_AUC_250_500)
tmp = summary(cSRM_Cz_VAF_Beta_AUC_250_500)
emmeans(cSRM_Cz_VAF_Beta_AUC_250_500,pairwise~mag)
VarCorr(cSRM_Cz_VAF_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]           
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_Beta_AUC_250_500.txt")
summary(cSRM_Cz_VAF_Beta_AUC_250_500)
emmeans(cSRM_Cz_VAF_Beta_AUC_250_500,pairwise~mag)
sink()


## cSRM (Cz) Recon vs evoked N1_amp lmer ####
# R2
# fit linear model for beta recon
cSRM_Cz_R2_N1_amp = lmer(fit_Cz_R2 ~ mag*N1_amp + (1|Participant), data = dm)
print(cSRM_Cz_R2_N1_amp)
summary(cSRM_Cz_R2_N1_amp)
tmp = summary(cSRM_Cz_R2_N1_amp)
emmeans(cSRM_Cz_R2_N1_amp,pairwise~mag)
VarCorr(cSRM_Cz_R2_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = N1_amp, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_R2_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_R2_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_R2_vs_N1_amp.txt")
summary(cSRM_Cz_R2_N1_amp)
emmeans(cSRM_Cz_R2_N1_amp,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
cSRM_Cz_VAF_N1_amp = lmer(fit_Cz_VAF ~ mag*N1_amp + (1|Participant), data = dm)
print(cSRM_Cz_VAF_N1_amp)
summary(cSRM_Cz_VAF_N1_amp)
tmp = summary(cSRM_Cz_VAF_N1_amp)
emmeans(cSRM_Cz_VAF_N1_amp,pairwise~mag)
VarCorr(cSRM_Cz_VAF_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = N1_amp, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("cSRM_Cz_VAF_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("cSRM_Cz_VAF_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("cSRM_Cz_VAF_vs_N1_amp.txt")
summary(cSRM_Cz_VAF_N1_amp)
emmeans(cSRM_Cz_VAF_N1_amp,pairwise~mag)
sink()

####### mSRM vs EEG outcomes #######
## mSRM Recon vs evoked beta_0_500 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_beta_0_500 = lmer(fit_agonist_R2 ~ mag*beta_0_500 + (1|Participant), data = dm)
print(mSRM_R2_beta_0_500)
summary(mSRM_R2_beta_0_500)
tmp = summary(mSRM_R2_beta_0_500)
emmeans(mSRM_R2_beta_0_500,pairwise~mag)
VarCorr(mSRM_R2_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_beta_0_500.txt")
summary(mSRM_R2_beta_0_500)
emmeans(mSRM_R2_beta_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_beta_0_500 = lmer(fit_agonist_VAF ~ mag*beta_0_500 + (1|Participant), data = dm)
print(mSRM_VAF_beta_0_500)
summary(mSRM_VAF_beta_0_500)
tmp = summary(mSRM_VAF_beta_0_500)
emmeans(mSRM_VAF_beta_0_500,pairwise~mag)
VarCorr(mSRM_VAF_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4] 
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_beta_0_500.txt")
summary(mSRM_VAF_beta_0_500)
emmeans(mSRM_VAF_beta_0_500,pairwise~mag)
sink()

## mSRM Recon vs evoked beta_50_150 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_beta_50_150 = lmer(fit_agonist_R2 ~ mag*beta_50_150 + (1|Participant), data = dm)
print(mSRM_R2_beta_50_150)
summary(mSRM_R2_beta_50_150)
tmp = summary(mSRM_R2_beta_50_150)
emmeans(mSRM_R2_beta_50_150,pairwise~mag)
VarCorr(mSRM_R2_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_beta_50_150.txt")
summary(mSRM_R2_beta_50_150)
emmeans(mSRM_R2_beta_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_beta_50_150 = lmer(fit_agonist_VAF ~ mag*beta_50_150 + (1|Participant), data = dm)
print(mSRM_VAF_beta_50_150)
summary(mSRM_VAF_beta_50_150)
tmp = summary(mSRM_VAF_beta_50_150)
emmeans(mSRM_VAF_beta_50_150,pairwise~mag)
VarCorr(mSRM_VAF_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_beta_50_150.txt")
summary(mSRM_VAF_beta_50_150)
emmeans(mSRM_VAF_beta_50_150,pairwise~mag)
sink()

## mSRM Recon vs evoked beta_150_250 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_beta_150_250 = lmer(fit_agonist_R2 ~ mag*beta_150_250 + (1|Participant), data = dm)
print(mSRM_R2_beta_150_250)
summary(mSRM_R2_beta_150_250)
tmp = summary(mSRM_R2_beta_150_250)
emmeans(mSRM_R2_beta_150_250,pairwise~mag)
VarCorr(mSRM_R2_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_beta_150_250.txt")
summary(mSRM_R2_beta_150_250)
emmeans(mSRM_R2_beta_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_beta_150_250 = lmer(fit_agonist_VAF ~ mag*beta_150_250 + (1|Participant), data = dm)
print(mSRM_VAF_beta_150_250)
summary(mSRM_VAF_beta_150_250)
tmp = summary(mSRM_VAF_beta_150_250)
emmeans(mSRM_VAF_beta_150_250,pairwise~mag)
VarCorr(mSRM_VAF_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_beta_150_250.txt")
summary(mSRM_VAF_beta_150_250)
emmeans(mSRM_VAF_beta_150_250,pairwise~mag)
sink()

## mSRM Recon vs evoked beta_250_500 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_beta_250_500 = lmer(fit_agonist_R2 ~ mag*beta_250_500 + (1|Participant), data = dm)
print(mSRM_R2_beta_250_500)
summary(mSRM_R2_beta_250_500)
tmp = summary(mSRM_R2_beta_250_500)
emmeans(mSRM_R2_beta_250_500,pairwise~mag)
VarCorr(mSRM_R2_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]      
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_beta_250_500.txt")
summary(mSRM_R2_beta_250_500)
emmeans(mSRM_R2_beta_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_beta_250_500 = lmer(fit_agonist_VAF ~ mag*beta_250_500 + (1|Participant), data = dm)
print(mSRM_VAF_beta_250_500)
summary(mSRM_VAF_beta_250_500)
tmp = summary(mSRM_VAF_beta_250_500)
emmeans(mSRM_VAF_beta_250_500,pairwise~mag)
VarCorr(mSRM_VAF_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_beta_250_500.txt")
summary(mSRM_VAF_beta_250_500)
emmeans(mSRM_VAF_beta_250_500,pairwise~mag)
sink()

## mSRM Recon vs evoked Beta_AUC lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_Beta_AUC = lmer(fit_agonist_R2 ~ mag*Beta_AUC + (1|Participant), data = dm)
print(mSRM_R2_Beta_AUC)
summary(mSRM_R2_Beta_AUC)
tmp = summary(mSRM_R2_Beta_AUC)
emmeans(mSRM_R2_Beta_AUC,pairwise~mag)
VarCorr(mSRM_R2_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_Beta_AUC.txt")
summary(mSRM_R2_Beta_AUC)
emmeans(mSRM_R2_Beta_AUC,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_Beta_AUC = lmer(fit_agonist_VAF ~ mag*Beta_AUC + (1|Participant), data = dm)
print(mSRM_VAF_Beta_AUC)
summary(mSRM_VAF_Beta_AUC)
tmp = summary(mSRM_VAF_Beta_AUC)
emmeans(mSRM_VAF_Beta_AUC,pairwise~mag)
VarCorr(mSRM_VAF_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]       
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_Beta_AUC.txt")
summary(mSRM_VAF_Beta_AUC)
emmeans(mSRM_VAF_Beta_AUC,pairwise~mag)
sink()

## mSRM Recon vs evoked Beta_AUC_0_500 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_Beta_AUC_0_500 = lmer(fit_agonist_R2 ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(mSRM_R2_Beta_AUC_0_500)
summary(mSRM_R2_Beta_AUC_0_500)
tmp = summary(mSRM_R2_Beta_AUC_0_500)
emmeans(mSRM_R2_Beta_AUC_0_500,pairwise~mag)
VarCorr(mSRM_R2_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]         
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_Beta_AUC_0_500.txt")
summary(mSRM_R2_Beta_AUC_0_500)
emmeans(mSRM_R2_Beta_AUC_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_Beta_AUC_0_500 = lmer(fit_agonist_VAF ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(mSRM_VAF_Beta_AUC_0_500)
summary(mSRM_VAF_Beta_AUC_0_500)
tmp = summary(mSRM_VAF_Beta_AUC_0_500)
emmeans(mSRM_VAF_Beta_AUC_0_500,pairwise~mag)
VarCorr(mSRM_VAF_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]         
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_Beta_AUC_0_500.txt")
summary(mSRM_VAF_Beta_AUC_0_500)
emmeans(mSRM_VAF_Beta_AUC_0_500,pairwise~mag)
sink()

## mSRM Recon vs evoked Beta_AUC_50_150 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_Beta_AUC_50_150 = lmer(fit_agonist_R2 ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(mSRM_R2_Beta_AUC_50_150)
summary(mSRM_R2_Beta_AUC_50_150)
tmp = summary(mSRM_R2_Beta_AUC_50_150)
emmeans(mSRM_R2_Beta_AUC_50_150,pairwise~mag)
VarCorr(mSRM_R2_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4] 
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_Beta_AUC_50_150.txt")
summary(mSRM_R2_Beta_AUC_50_150)
emmeans(mSRM_R2_Beta_AUC_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_Beta_AUC_50_150 = lmer(fit_agonist_VAF ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(mSRM_VAF_Beta_AUC_50_150)
summary(mSRM_VAF_Beta_AUC_50_150)
tmp = summary(mSRM_VAF_Beta_AUC_50_150)
emmeans(mSRM_VAF_Beta_AUC_50_150,pairwise~mag)
VarCorr(mSRM_VAF_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]        
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_Beta_AUC_50_150.txt")
summary(mSRM_VAF_Beta_AUC_50_150)
emmeans(mSRM_VAF_Beta_AUC_50_150,pairwise~mag)
sink()

## mSRM Recon vs evoked Beta_AUC_150_250 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_Beta_AUC_150_250 = lmer(fit_agonist_R2 ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(mSRM_R2_Beta_AUC_150_250)
tmp = summary(mSRM_R2_Beta_AUC_150_250)
summary(mSRM_R2_Beta_AUC_150_250)
emmeans(mSRM_R2_Beta_AUC_150_250,pairwise~mag)
VarCorr(mSRM_R2_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_Beta_AUC_150_250.txt")
summary(mSRM_R2_Beta_AUC_150_250)
emmeans(mSRM_R2_Beta_AUC_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_Beta_AUC_150_250 = lmer(fit_agonist_VAF ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(mSRM_VAF_Beta_AUC_150_250)
summary(mSRM_VAF_Beta_AUC_150_250)
tmp = summary(mSRM_VAF_Beta_AUC_150_250)
emmeans(mSRM_VAF_Beta_AUC_150_250,pairwise~mag)
VarCorr(mSRM_VAF_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]          
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_Beta_AUC_150_250.txt")
summary(mSRM_VAF_Beta_AUC_150_250)
emmeans(mSRM_VAF_Beta_AUC_150_250,pairwise~mag)
sink()

## mSRM Recon vs evoked Beta_AUC_250_500 lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_Beta_AUC_250_500 = lmer(fit_agonist_R2 ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(mSRM_R2_Beta_AUC_250_500)
summary(mSRM_R2_Beta_AUC_250_500)
tmp = summary(mSRM_R2_Beta_AUC_250_500)
emmeans(mSRM_R2_Beta_AUC_250_500,pairwise~mag)
VarCorr(mSRM_R2_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_Beta_AUC_250_500.txt")
summary(mSRM_R2_Beta_AUC_250_500)
emmeans(mSRM_R2_Beta_AUC_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_Beta_AUC_250_500 = lmer(fit_agonist_VAF ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(mSRM_VAF_Beta_AUC_250_500)
summary(mSRM_VAF_Beta_AUC_250_500)
tmp = summary(mSRM_VAF_Beta_AUC_250_500)
emmeans(mSRM_VAF_Beta_AUC_250_500,pairwise~mag)
VarCorr(mSRM_VAF_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]     
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_Beta_AUC_250_500.txt")
summary(mSRM_VAF_Beta_AUC_250_500)
emmeans(mSRM_VAF_Beta_AUC_250_500,pairwise~mag)
sink()

## mSRM Recon vs evoked N1_amp lmer ####
# R2
# fit linear model for beta recon
mSRM_R2_N1_amp = lmer(fit_agonist_R2 ~ mag*N1_amp + (1|Participant), data = dm)
print(mSRM_R2_N1_amp)
summary(mSRM_R2_N1_amp)
tmp = summary(mSRM_R2_N1_amp)
emmeans(mSRM_R2_N1_amp,pairwise~mag)
VarCorr(mSRM_R2_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_R2_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_R2_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_R2_vs_N1_amp.txt")
summary(mSRM_R2_N1_amp)
emmeans(mSRM_R2_N1_amp,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
mSRM_VAF_N1_amp = lmer(fit_agonist_VAF ~ mag*N1_amp + (1|Participant), data = dm)
print(mSRM_VAF_N1_amp)
summary(mSRM_VAF_N1_amp)
tmp = summary(mSRM_VAF_N1_amp)
emmeans(mSRM_VAF_N1_amp,pairwise~mag)
VarCorr(mSRM_VAF_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]       
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("mSRM_VAF_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("mSRM_VAF_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("mSRM_VAF_vs_N1_amp.txt")
summary(mSRM_VAF_N1_amp)
emmeans(mSRM_VAF_N1_amp,pairwise~mag)
sink()


####### dSRM (beta) vs EEG outcomes #######
## dSRM (beta) Recon vs evoked beta_0_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_beta_0_500 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*beta_0_500 + (1|Participant), data = dm)
print(dSRM_beta_R2_beta_0_500)
summary(dSRM_beta_R2_beta_0_500)
tmp = summary(dSRM_beta_R2_beta_0_500)
emmeans(dSRM_beta_R2_beta_0_500,pairwise~mag)
VarCorr(dSRM_beta_R2_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4] 
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_beta_0_500.txt")
summary(dSRM_beta_R2_beta_0_500)
emmeans(dSRM_beta_R2_beta_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_beta_0_500 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*beta_0_500 + (1|Participant), data = dm)
print(dSRM_beta_VAF_beta_0_500)
summary(dSRM_beta_VAF_beta_0_500)
tmp = summary(dSRM_beta_VAF_beta_0_500)
emmeans(dSRM_beta_VAF_beta_0_500,pairwise~mag)
VarCorr(dSRM_beta_VAF_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4] 
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_beta_0_500.txt")
summary(dSRM_beta_VAF_beta_0_500)
emmeans(dSRM_beta_VAF_beta_0_500,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked beta_50_150 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_beta_50_150 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*beta_50_150 + (1|Participant), data = dm)
print(dSRM_beta_R2_beta_50_150)
summary(dSRM_beta_R2_beta_50_150)
tmp = summary(dSRM_beta_R2_beta_50_150)
emmeans(dSRM_beta_R2_beta_50_150,pairwise~mag)
VarCorr(dSRM_beta_R2_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_beta_50_150.txt")
summary(dSRM_beta_R2_beta_50_150)
emmeans(dSRM_beta_R2_beta_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_beta_50_150 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*beta_50_150 + (1|Participant), data = dm)
print(dSRM_beta_VAF_beta_50_150)
summary(dSRM_beta_VAF_beta_50_150)
tmp = summary(dSRM_beta_VAF_beta_50_150)
emmeans(dSRM_beta_VAF_beta_50_150,pairwise~mag)
VarCorr(dSRM_beta_VAF_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]      
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_beta_50_150.txt")
summary(dSRM_beta_VAF_beta_50_150)
emmeans(dSRM_beta_VAF_beta_50_150,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked beta_150_250 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_beta_150_250 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*beta_150_250 + (1|Participant), data = dm)
print(dSRM_beta_R2_beta_150_250)
summary(dSRM_beta_R2_beta_150_250)
tmp = summary(dSRM_beta_R2_beta_150_250)
emmeans(dSRM_beta_R2_beta_150_250,pairwise~mag)
VarCorr(dSRM_beta_R2_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]   
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_beta_150_250.txt")
summary(dSRM_beta_R2_beta_150_250)
emmeans(dSRM_beta_R2_beta_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_beta_150_250 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*beta_150_250 + (1|Participant), data = dm)
print(dSRM_beta_VAF_beta_150_250)
summary(dSRM_beta_VAF_beta_150_250)
tmp = summary(dSRM_beta_VAF_beta_150_250)
emmeans(dSRM_beta_VAF_beta_150_250,pairwise~mag)
VarCorr(dSRM_beta_VAF_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]        
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_beta_150_250.txt")
summary(dSRM_beta_VAF_beta_150_250)
emmeans(dSRM_beta_VAF_beta_150_250,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked beta_250_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_beta_250_500 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*beta_250_500 + (1|Participant), data = dm)
print(dSRM_beta_R2_beta_250_500)
summary(dSRM_beta_R2_beta_250_500)
tmp = summary(dSRM_beta_R2_beta_250_500)
emmeans(dSRM_beta_R2_beta_250_500,pairwise~mag)
VarCorr(dSRM_beta_R2_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]         
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_beta_250_500.txt")
summary(dSRM_beta_R2_beta_250_500)
emmeans(dSRM_beta_R2_beta_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_beta_250_500 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*beta_250_500 + (1|Participant), data = dm)
print(dSRM_beta_VAF_beta_250_500)
summary(dSRM_beta_VAF_beta_250_500)
tmp = summary(dSRM_beta_VAF_beta_250_500)
emmeans(dSRM_beta_VAF_beta_250_500,pairwise~mag)
VarCorr(dSRM_beta_VAF_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]    
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_beta_250_500.txt")
summary(dSRM_beta_VAF_beta_250_500)
emmeans(dSRM_beta_VAF_beta_250_500,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked Beta_AUC lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_Beta_AUC = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*Beta_AUC + (1|Participant), data = dm)
print(dSRM_beta_R2_Beta_AUC)
summary(dSRM_beta_R2_Beta_AUC)
tmp = summary(dSRM_beta_R2_Beta_AUC)
emmeans(dSRM_beta_R2_Beta_AUC,pairwise~mag)
VarCorr(dSRM_beta_R2_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]       
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_Beta_AUC.txt")
summary(dSRM_beta_R2_Beta_AUC)
emmeans(dSRM_beta_R2_Beta_AUC,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_Beta_AUC = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*Beta_AUC + (1|Participant), data = dm)
print(dSRM_beta_VAF_Beta_AUC)
summary(dSRM_beta_VAF_Beta_AUC)
tmp = summary(dSRM_beta_VAF_Beta_AUC)
emmeans(dSRM_beta_VAF_Beta_AUC,pairwise~mag)
VarCorr(dSRM_beta_VAF_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]            
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_Beta_AUC.txt")
summary(dSRM_beta_VAF_Beta_AUC)
emmeans(dSRM_beta_VAF_Beta_AUC,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked Beta_AUC_0_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_Beta_AUC_0_500 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(dSRM_beta_R2_Beta_AUC_0_500)
summary(dSRM_beta_R2_Beta_AUC_0_500)
tmp = summary(dSRM_beta_R2_Beta_AUC_0_500)
emmeans(dSRM_beta_R2_Beta_AUC_0_500,pairwise~mag)
VarCorr(dSRM_beta_R2_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]                
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_Beta_AUC_0_500.txt")
summary(dSRM_beta_R2_Beta_AUC_0_500)
emmeans(dSRM_beta_R2_Beta_AUC_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_Beta_AUC_0_500 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(dSRM_beta_VAF_Beta_AUC_0_500)
summary(dSRM_beta_VAF_Beta_AUC_0_500)
tmp = summary(dSRM_beta_VAF_Beta_AUC_0_500)
emmeans(dSRM_beta_VAF_Beta_AUC_0_500,pairwise~mag)
VarCorr(dSRM_beta_VAF_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]              
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_Beta_AUC_0_500.txt")
summary(dSRM_beta_VAF_Beta_AUC_0_500)
emmeans(dSRM_beta_VAF_Beta_AUC_0_500,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked Beta_AUC_50_150 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_Beta_AUC_50_150 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(dSRM_beta_R2_Beta_AUC_50_150)
summary(dSRM_beta_R2_Beta_AUC_50_150)
tmp = summary(dSRM_beta_R2_Beta_AUC_50_150)
emmeans(dSRM_beta_R2_Beta_AUC_50_150,pairwise~mag)
VarCorr(dSRM_beta_R2_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]      
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_Beta_AUC_50_150.txt")
summary(dSRM_beta_R2_Beta_AUC_50_150)
emmeans(dSRM_beta_R2_Beta_AUC_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_Beta_AUC_50_150 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(dSRM_beta_VAF_Beta_AUC_50_150)
summary(dSRM_beta_VAF_Beta_AUC_50_150)
tmp = summary(dSRM_beta_VAF_Beta_AUC_50_150)
emmeans(dSRM_beta_VAF_Beta_AUC_50_150,pairwise~mag)
VarCorr(dSRM_beta_VAF_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]           
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_Beta_AUC_50_150.txt")
summary(dSRM_beta_VAF_Beta_AUC_50_150)
emmeans(dSRM_beta_VAF_Beta_AUC_50_150,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked Beta_AUC_150_250 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_Beta_AUC_150_250 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(dSRM_beta_R2_Beta_AUC_150_250)
summary(dSRM_beta_R2_Beta_AUC_150_250)
tmp = summary(dSRM_beta_R2_Beta_AUC_150_250)
emmeans(dSRM_beta_R2_Beta_AUC_150_250,pairwise~mag)
VarCorr(dSRM_beta_R2_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4] 
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_Beta_AUC_150_250.txt")
summary(dSRM_beta_R2_Beta_AUC_150_250)
emmeans(dSRM_beta_R2_Beta_AUC_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_Beta_AUC_150_250 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(dSRM_beta_VAF_Beta_AUC_150_250)
summary(dSRM_beta_VAF_Beta_AUC_150_250)
tmp = summary(dSRM_beta_VAF_Beta_AUC_150_250)
emmeans(dSRM_beta_VAF_Beta_AUC_150_250,pairwise~mag)
VarCorr(dSRM_beta_VAF_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]               
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_Beta_AUC_150_250.txt")
summary(dSRM_beta_VAF_Beta_AUC_150_250)
emmeans(dSRM_beta_VAF_Beta_AUC_150_250,pairwise~mag)
sink()

## dSRM (beta) Recon vs evoked Beta_AUC_250_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_Beta_AUC_250_500 = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(dSRM_beta_R2_Beta_AUC_250_500)
summary(dSRM_beta_R2_Beta_AUC_250_500)
tmp = summary(dSRM_beta_R2_Beta_AUC_250_500)
emmeans(dSRM_beta_R2_Beta_AUC_250_500,pairwise~mag)
VarCorr(dSRM_beta_R2_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]           
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_Beta_AUC_250_500.txt")
summary(dSRM_beta_R2_Beta_AUC_250_500)
emmeans(dSRM_beta_R2_Beta_AUC_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_Beta_AUC_250_500 = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(dSRM_beta_VAF_Beta_AUC_250_500)
summary(dSRM_beta_VAF_Beta_AUC_250_500)
tmp = summary(dSRM_beta_VAF_Beta_AUC_250_500)
emmeans(dSRM_beta_VAF_Beta_AUC_250_500,pairwise~mag)
VarCorr(dSRM_beta_VAF_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]          
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_Beta_AUC_250_500.txt")
summary(dSRM_beta_VAF_Beta_AUC_250_500)
emmeans(dSRM_beta_VAF_Beta_AUC_250_500,pairwise~mag)
sink()


## dSRM (beta) Recon vs evoked N1_amp lmer ####
# R2
# fit linear model for beta recon
dSRM_beta_R2_N1_amp = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*N1_amp + (1|Participant), data = dm)
print(dSRM_beta_R2_N1_amp)
summary(dSRM_beta_R2_N1_amp)
tmp = summary(dSRM_beta_R2_N1_amp)
emmeans(dSRM_beta_R2_N1_amp,pairwise~mag)
VarCorr(dSRM_beta_R2_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]          
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_beta_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_N1_amp.txt")
summary(dSRM_beta_R2_N1_amp)
emmeans(dSRM_beta_R2_N1_amp,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_beta_VAF_N1_amp = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*N1_amp + (1|Participant), data = dm)
print(dSRM_beta_VAF_N1_amp)
summary(dSRM_beta_VAF_N1_amp)
tmp = summary(dSRM_beta_VAF_N1_amp)
emmeans(dSRM_beta_VAF_N1_amp,pairwise~mag)
VarCorr(dSRM_beta_VAF_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(lmer)
sl = tmp$coefficients[4]             
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_beta_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_N1_amp.txt")
summary(dSRM_beta_VAF_N1_amp)
emmeans(dSRM_beta_VAF_N1_amp,pairwise~mag)
sink()

####### dSRM (Cz) vs EEG outcomes #######
## dSRM (Cz) Recon vs evoked beta_0_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_beta_0_500 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*beta_0_500 + (1|Participant), data = dm)
print(dSRM_Cz_R2_beta_0_500)
summary(dSRM_Cz_R2_beta_0_500)
emmeans(dSRM_Cz_R2_beta_0_500,pairwise~mag)
VarCorr(dSRM_Cz_R2_beta_0_500)
tmp = summary(dSRM_Cz_R2_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_beta_0_500.txt")
summary(dSRM_Cz_R2_beta_0_500)
emmeans(dSRM_Cz_R2_beta_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_beta_0_500 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*beta_0_500 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_beta_0_500)
summary(dSRM_Cz_VAF_beta_0_500)
emmeans(dSRM_Cz_VAF_beta_0_500,pairwise~mag)
VarCorr(dSRM_Cz_VAF_beta_0_500)
tmp = summary(dSRM_Cz_VAF_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_beta_0_500.txt")
summary(dSRM_Cz_VAF_beta_0_500)
emmeans(dSRM_Cz_VAF_beta_0_500,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked beta_50_150 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_beta_50_150 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*beta_50_150 + (1|Participant), data = dm)
print(dSRM_Cz_R2_beta_50_150)
summary(dSRM_Cz_R2_beta_50_150)
emmeans(dSRM_Cz_R2_beta_50_150,pairwise~mag)
VarCorr(dSRM_Cz_R2_beta_50_150)
tmp = summary(dSRM_Cz_R2_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_beta_50_150.txt")
summary(dSRM_Cz_R2_beta_50_150)
emmeans(dSRM_Cz_R2_beta_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_beta_50_150 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*beta_50_150 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_beta_50_150)
summary(dSRM_Cz_VAF_beta_50_150)
emmeans(dSRM_Cz_VAF_beta_50_150,pairwise~mag)
VarCorr(dSRM_Cz_VAF_beta_50_150)
tmp = summary(dSRM_Cz_VAF_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_beta_50_150.txt")
summary(dSRM_Cz_VAF_beta_50_150)
emmeans(dSRM_Cz_VAF_beta_50_150,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked beta_150_250 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_beta_150_250 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*beta_150_250 + (1|Participant), data = dm)
print(dSRM_Cz_R2_beta_150_250)
summary(dSRM_Cz_R2_beta_150_250)
emmeans(dSRM_Cz_R2_beta_150_250,pairwise~mag)
VarCorr(dSRM_Cz_R2_beta_150_250)
tmp = summary(dSRM_Cz_R2_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_beta_150_250.txt")
summary(dSRM_Cz_R2_beta_150_250)
emmeans(dSRM_Cz_R2_beta_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_beta_150_250 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*beta_150_250 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_beta_150_250)
summary(dSRM_Cz_VAF_beta_150_250)
emmeans(dSRM_Cz_VAF_beta_150_250,pairwise~mag)
VarCorr(dSRM_Cz_VAF_beta_150_250)
tmp = summary(dSRM_Cz_VAF_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_beta_150_250.txt")
summary(dSRM_Cz_VAF_beta_150_250)
emmeans(dSRM_Cz_VAF_beta_150_250,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked beta_250_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_beta_250_500 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*beta_250_500 + (1|Participant), data = dm)
print(dSRM_Cz_R2_beta_250_500)
summary(dSRM_Cz_R2_beta_250_500)
emmeans(dSRM_Cz_R2_beta_250_500,pairwise~mag)
VarCorr(dSRM_Cz_R2_beta_250_500)
tmp = summary(dSRM_Cz_R2_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_beta_250_500.txt")
summary(dSRM_Cz_R2_beta_250_500)
emmeans(dSRM_Cz_R2_beta_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_beta_250_500 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*beta_250_500 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_beta_250_500)
summary(dSRM_Cz_VAF_beta_250_500)
emmeans(dSRM_Cz_VAF_beta_250_500,pairwise~mag)
VarCorr(dSRM_Cz_VAF_beta_250_500)
tmp = summary(dSRM_Cz_VAF_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_beta_250_500.txt")
summary(dSRM_Cz_VAF_beta_250_500)
emmeans(dSRM_Cz_VAF_beta_250_500,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked Beta_AUC lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_Beta_AUC = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*Beta_AUC + (1|Participant), data = dm)
print(dSRM_Cz_R2_Beta_AUC)
summary(dSRM_Cz_R2_Beta_AUC)
emmeans(dSRM_Cz_R2_Beta_AUC,pairwise~mag)
VarCorr(dSRM_Cz_R2_Beta_AUC)
tmp = summary(dSRM_Cz_R2_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_Beta_AUC.txt")
summary(dSRM_Cz_R2_Beta_AUC)
emmeans(dSRM_Cz_R2_Beta_AUC,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_Beta_AUC = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*Beta_AUC + (1|Participant), data = dm)
print(dSRM_Cz_VAF_Beta_AUC)
summary(dSRM_Cz_VAF_Beta_AUC)
emmeans(dSRM_Cz_VAF_Beta_AUC,pairwise~mag)
VarCorr(dSRM_Cz_VAF_Beta_AUC)
tmp = summary(dSRM_Cz_VAF_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_Beta_AUC.txt")
summary(dSRM_Cz_VAF_Beta_AUC)
emmeans(dSRM_Cz_VAF_Beta_AUC,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked Beta_AUC_0_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_Beta_AUC_0_500 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(dSRM_Cz_R2_Beta_AUC_0_500)
summary(dSRM_Cz_R2_Beta_AUC_0_500)
emmeans(dSRM_Cz_R2_Beta_AUC_0_500,pairwise~mag)
VarCorr(dSRM_Cz_R2_Beta_AUC_0_500)
tmp = summary(dSRM_Cz_R2_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_Beta_AUC_0_500.txt")
summary(dSRM_Cz_R2_Beta_AUC_0_500)
emmeans(dSRM_Cz_R2_Beta_AUC_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_Beta_AUC_0_500 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_Beta_AUC_0_500)
summary(dSRM_Cz_VAF_Beta_AUC_0_500)
emmeans(dSRM_Cz_VAF_Beta_AUC_0_500,pairwise~mag)
VarCorr(dSRM_Cz_VAF_Beta_AUC_0_500)
tmp = summary(dSRM_Cz_VAF_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_Beta_AUC_0_500.txt")
summary(dSRM_Cz_VAF_Beta_AUC_0_500)
emmeans(dSRM_Cz_VAF_Beta_AUC_0_500,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked Beta_AUC_50_150 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_Beta_AUC_50_150 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(dSRM_Cz_R2_Beta_AUC_50_150)
summary(dSRM_Cz_R2_Beta_AUC_50_150)
emmeans(dSRM_Cz_R2_Beta_AUC_50_150,pairwise~mag)
VarCorr(dSRM_Cz_R2_Beta_AUC_50_150)
tmp = summary(dSRM_Cz_R2_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_Beta_AUC_50_150.txt")
summary(dSRM_Cz_R2_Beta_AUC_50_150)
emmeans(dSRM_Cz_R2_Beta_AUC_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_Beta_AUC_50_150 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_Beta_AUC_50_150)
summary(dSRM_Cz_VAF_Beta_AUC_50_150)
emmeans(dSRM_Cz_VAF_Beta_AUC_50_150,pairwise~mag)
VarCorr(dSRM_Cz_VAF_Beta_AUC_50_150)
tmp = summary(dSRM_Cz_VAF_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_Beta_AUC_50_150.txt")
summary(dSRM_Cz_VAF_Beta_AUC_50_150)
emmeans(dSRM_Cz_VAF_Beta_AUC_50_150,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked Beta_AUC_150_250 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_Beta_AUC_150_250 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(dSRM_Cz_R2_Beta_AUC_150_250)
summary(dSRM_Cz_R2_Beta_AUC_150_250)
emmeans(dSRM_Cz_R2_Beta_AUC_150_250,pairwise~mag)
VarCorr(dSRM_Cz_R2_Beta_AUC_150_250)
tmp = summary(dSRM_Cz_R2_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_Beta_AUC_150_250.txt")
summary(dSRM_Cz_R2_Beta_AUC_150_250)
emmeans(dSRM_Cz_R2_Beta_AUC_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_Beta_AUC_150_250 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_Beta_AUC_150_250)
summary(dSRM_Cz_VAF_Beta_AUC_150_250)
emmeans(dSRM_Cz_VAF_Beta_AUC_150_250,pairwise~mag)
VarCorr(dSRM_Cz_VAF_Beta_AUC_150_250)
tmp = summary(dSRM_Cz_VAF_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_Beta_AUC_150_250.txt")
summary(dSRM_Cz_VAF_Beta_AUC_150_250)
emmeans(dSRM_Cz_VAF_Beta_AUC_150_250,pairwise~mag)
sink()

## dSRM (Cz) Recon vs evoked Beta_AUC_250_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_Beta_AUC_250_500 = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(dSRM_Cz_R2_Beta_AUC_250_500)
summary(dSRM_Cz_R2_Beta_AUC_250_500)
emmeans(dSRM_Cz_R2_Beta_AUC_250_500,pairwise~mag)
VarCorr(dSRM_Cz_R2_Beta_AUC_250_500)
tmp = summary(dSRM_Cz_R2_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_Beta_AUC_250_500.txt")
summary(dSRM_Cz_R2_Beta_AUC_250_500)
emmeans(dSRM_Cz_R2_Beta_AUC_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_Beta_AUC_250_500 = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(dSRM_Cz_VAF_Beta_AUC_250_500)
summary(dSRM_Cz_VAF_Beta_AUC_250_500)
emmeans(dSRM_Cz_VAF_Beta_AUC_250_500,pairwise~mag)
VarCorr(dSRM_Cz_VAF_Beta_AUC_250_500)
tmp = summary(dSRM_Cz_VAF_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_Beta_AUC_250_500.txt")
summary(dSRM_Cz_VAF_Beta_AUC_250_500)
emmeans(dSRM_Cz_VAF_Beta_AUC_250_500,pairwise~mag)
sink()


## dSRM (Cz) Recon vs evoked N1_amp lmer ####
# R2
# fit linear model for beta recon
dSRM_Cz_R2_N1_amp = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*N1_amp + (1|Participant), data = dm)
print(dSRM_Cz_R2_N1_amp)
summary(dSRM_Cz_R2_N1_amp)
emmeans(dSRM_Cz_R2_N1_amp,pairwise~mag)
VarCorr(dSRM_Cz_R2_N1_amp)
tmp = summary(dSRM_Cz_R2_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_Cz_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_N1_amp.txt")
summary(dSRM_Cz_R2_N1_amp)
emmeans(dSRM_Cz_R2_N1_amp,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_Cz_VAF_N1_amp = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*N1_amp + (1|Participant), data = dm)
print(dSRM_Cz_VAF_N1_amp)
summary(dSRM_Cz_VAF_N1_amp)
emmeans(dSRM_Cz_VAF_N1_amp,pairwise~mag)
VarCorr(dSRM_Cz_VAF_N1_amp)
tmp = summary(dSRM_Cz_VAF_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_Cz_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_N1_amp.txt")
summary(dSRM_Cz_VAF_N1_amp)
emmeans(dSRM_Cz_VAF_N1_amp,pairwise~mag)
sink()


####### dSRM (CoM) vs EEG outcomes #######
## dSRM (CoM) Recon vs evoked beta_0_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_beta_0_500 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*beta_0_500 + (1|Participant), data = dm)
print(dSRM_CoM_R2_beta_0_500)
summary(dSRM_CoM_R2_beta_0_500)
emmeans(dSRM_CoM_R2_beta_0_500,pairwise~mag)
VarCorr(dSRM_CoM_R2_beta_0_500)
tmp = summary(dSRM_CoM_R2_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_beta_0_500.txt")
summary(dSRM_CoM_R2_beta_0_500)
emmeans(dSRM_CoM_R2_beta_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_beta_0_500 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*beta_0_500 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_beta_0_500)
summary(dSRM_CoM_VAF_beta_0_500)
emmeans(dSRM_CoM_VAF_beta_0_500,pairwise~mag)
VarCorr(dSRM_CoM_VAF_beta_0_500)
tmp = summary(dSRM_CoM_VAF_beta_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_beta_0_500.txt")
summary(dSRM_CoM_VAF_beta_0_500)
emmeans(dSRM_CoM_VAF_beta_0_500,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked beta_50_150 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_beta_50_150 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*beta_50_150 + (1|Participant), data = dm)
print(dSRM_CoM_R2_beta_50_150)
summary(dSRM_CoM_R2_beta_50_150)
emmeans(dSRM_CoM_R2_beta_50_150,pairwise~mag)
VarCorr(dSRM_CoM_R2_beta_50_150)
tmp = summary(dSRM_CoM_R2_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_beta_50_150.txt")
summary(dSRM_CoM_R2_beta_50_150)
emmeans(dSRM_CoM_R2_beta_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_beta_50_150 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*beta_50_150 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_beta_50_150)
summary(dSRM_CoM_VAF_beta_50_150)
emmeans(dSRM_CoM_VAF_beta_50_150,pairwise~mag)
VarCorr(dSRM_CoM_VAF_beta_50_150)
tmp = summary(dSRM_CoM_VAF_beta_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_beta_50_150.txt")
summary(dSRM_CoM_VAF_beta_50_150)
emmeans(dSRM_CoM_VAF_beta_50_150,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked beta_150_250 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_beta_150_250 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*beta_150_250 + (1|Participant), data = dm)
print(dSRM_CoM_R2_beta_150_250)
summary(dSRM_CoM_R2_beta_150_250)
emmeans(dSRM_CoM_R2_beta_150_250,pairwise~mag)
VarCorr(dSRM_CoM_R2_beta_150_250)
tmp = summary(dSRM_CoM_R2_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_beta_150_250.txt")
summary(dSRM_CoM_R2_beta_150_250)
emmeans(dSRM_CoM_R2_beta_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_beta_150_250 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*beta_150_250 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_beta_150_250)
summary(dSRM_CoM_VAF_beta_150_250)
emmeans(dSRM_CoM_VAF_beta_150_250,pairwise~mag)
VarCorr(dSRM_CoM_VAF_beta_150_250)
tmp = summary(dSRM_CoM_VAF_beta_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_beta_150_250.txt")
summary(dSRM_CoM_VAF_beta_150_250)
emmeans(dSRM_CoM_VAF_beta_150_250,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked beta_250_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_beta_250_500 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*beta_250_500 + (1|Participant), data = dm)
print(dSRM_CoM_R2_beta_250_500)
summary(dSRM_CoM_R2_beta_250_500)
emmeans(dSRM_CoM_R2_beta_250_500,pairwise~mag)
VarCorr(dSRM_CoM_R2_beta_250_500)
tmp = summary(dSRM_CoM_R2_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_beta_250_500.txt")
summary(dSRM_CoM_R2_beta_250_500)
emmeans(dSRM_CoM_R2_beta_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_beta_250_500 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*beta_250_500 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_beta_250_500)
summary(dSRM_CoM_VAF_beta_250_500)
emmeans(dSRM_CoM_VAF_beta_250_500,pairwise~mag)
VarCorr(dSRM_CoM_VAF_beta_250_500)
tmp = summary(dSRM_CoM_VAF_beta_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_beta_250_500.txt")
summary(dSRM_CoM_VAF_beta_250_500)
emmeans(dSRM_CoM_VAF_beta_250_500,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked Beta_AUC lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_Beta_AUC = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*Beta_AUC + (1|Participant), data = dm)
print(dSRM_CoM_R2_Beta_AUC)
summary(dSRM_CoM_R2_Beta_AUC)
emmeans(dSRM_CoM_R2_Beta_AUC,pairwise~mag)
VarCorr(dSRM_CoM_R2_Beta_AUC)
tmp = summary(dSRM_CoM_R2_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_Beta_AUC.txt")
summary(dSRM_CoM_R2_Beta_AUC)
emmeans(dSRM_CoM_R2_Beta_AUC,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_Beta_AUC = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*Beta_AUC + (1|Participant), data = dm)
print(dSRM_CoM_VAF_Beta_AUC)
summary(dSRM_CoM_VAF_Beta_AUC)
emmeans(dSRM_CoM_VAF_Beta_AUC,pairwise~mag)
VarCorr(dSRM_CoM_VAF_Beta_AUC)
tmp = summary(dSRM_CoM_VAF_Beta_AUC)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_Beta_AUC.txt")
summary(dSRM_CoM_VAF_Beta_AUC)
emmeans(dSRM_CoM_VAF_Beta_AUC,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked Beta_AUC_0_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_Beta_AUC_0_500 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(dSRM_CoM_R2_Beta_AUC_0_500)
summary(dSRM_CoM_R2_Beta_AUC_0_500)
emmeans(dSRM_CoM_R2_Beta_AUC_0_500,pairwise~mag)
VarCorr(dSRM_CoM_R2_Beta_AUC_0_500)
tmp = summary(dSRM_CoM_R2_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_Beta_AUC_0_500.txt")
summary(dSRM_CoM_R2_Beta_AUC_0_500)
emmeans(dSRM_CoM_R2_Beta_AUC_0_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_Beta_AUC_0_500 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*Beta_AUC_0_500 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_Beta_AUC_0_500)
summary(dSRM_CoM_VAF_Beta_AUC_0_500)
emmeans(dSRM_CoM_VAF_Beta_AUC_0_500,pairwise~mag)
VarCorr(dSRM_CoM_VAF_Beta_AUC_0_500)
tmp = summary(dSRM_CoM_VAF_Beta_AUC_0_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_Beta_AUC_0_500.txt")
summary(dSRM_CoM_VAF_Beta_AUC_0_500)
emmeans(dSRM_CoM_VAF_Beta_AUC_0_500,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked Beta_AUC_50_150 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_Beta_AUC_50_150 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(dSRM_CoM_R2_Beta_AUC_50_150)
summary(dSRM_CoM_R2_Beta_AUC_50_150)
emmeans(dSRM_CoM_R2_Beta_AUC_50_150,pairwise~mag)
VarCorr(dSRM_CoM_R2_Beta_AUC_50_150)
tmp = summary(dSRM_CoM_R2_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_Beta_AUC_50_150.txt")
summary(dSRM_CoM_R2_Beta_AUC_50_150)
emmeans(dSRM_CoM_R2_Beta_AUC_50_150,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_Beta_AUC_50_150 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*Beta_AUC_50_150 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_Beta_AUC_50_150)
summary(dSRM_CoM_VAF_Beta_AUC_50_150)
emmeans(dSRM_CoM_VAF_Beta_AUC_50_150,pairwise~mag)
VarCorr(dSRM_CoM_VAF_Beta_AUC_50_150)
tmp = summary(dSRM_CoM_VAF_Beta_AUC_50_150)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_Beta_AUC_50_150.txt")
summary(dSRM_CoM_VAF_Beta_AUC_50_150)
emmeans(dSRM_CoM_VAF_Beta_AUC_50_150,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked Beta_AUC_150_250 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_Beta_AUC_150_250 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(dSRM_CoM_R2_Beta_AUC_150_250)
summary(dSRM_CoM_R2_Beta_AUC_150_250)
emmeans(dSRM_CoM_R2_Beta_AUC_150_250,pairwise~mag)
VarCorr(dSRM_CoM_R2_Beta_AUC_150_250)
tmp = summary(dSRM_CoM_R2_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_Beta_AUC_150_250.txt")
summary(dSRM_CoM_R2_Beta_AUC_150_250)
emmeans(dSRM_CoM_R2_Beta_AUC_150_250,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_Beta_AUC_150_250 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*Beta_AUC_150_250 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_Beta_AUC_150_250)
summary(dSRM_CoM_VAF_Beta_AUC_150_250)
emmeans(dSRM_CoM_VAF_Beta_AUC_150_250,pairwise~mag)
VarCorr(dSRM_CoM_VAF_Beta_AUC_150_250)
tmp = summary(dSRM_CoM_VAF_Beta_AUC_150_250)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_Beta_AUC_150_250.txt")
summary(dSRM_CoM_VAF_Beta_AUC_150_250)
emmeans(dSRM_CoM_VAF_Beta_AUC_150_250,pairwise~mag)
sink()

## dSRM (CoM) Recon vs evoked Beta_AUC_250_500 lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_Beta_AUC_250_500 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(dSRM_CoM_R2_Beta_AUC_250_500)
summary(dSRM_CoM_R2_Beta_AUC_250_500)
emmeans(dSRM_CoM_R2_Beta_AUC_250_500,pairwise~mag)
VarCorr(dSRM_CoM_R2_Beta_AUC_250_500)
tmp = summary(dSRM_CoM_R2_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_Beta_AUC_250_500.txt")
summary(dSRM_CoM_R2_Beta_AUC_250_500)
emmeans(dSRM_CoM_R2_Beta_AUC_250_500,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_Beta_AUC_250_500 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*Beta_AUC_250_500 + (1|Participant), data = dm)
print(dSRM_CoM_VAF_Beta_AUC_250_500)
summary(dSRM_CoM_VAF_Beta_AUC_250_500)
emmeans(dSRM_CoM_VAF_Beta_AUC_250_500,pairwise~mag)
VarCorr(dSRM_CoM_VAF_Beta_AUC_250_500)
tmp = summary(dSRM_CoM_VAF_Beta_AUC_250_500)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_Beta_AUC_250_500.txt")
summary(dSRM_CoM_VAF_Beta_AUC_250_500)
emmeans(dSRM_CoM_VAF_Beta_AUC_250_500,pairwise~mag)
sink()


## dSRM (CoM) Recon vs evoked N1_amp lmer ####
# R2
# fit linear model for beta recon
dSRM_CoM_R2_N1_amp = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*N1_amp + (1|Participant), data = dm)
print(dSRM_CoM_R2_N1_amp)
summary(dSRM_CoM_R2_N1_amp)
emmeans(dSRM_CoM_R2_N1_amp,pairwise~mag)
VarCorr(dSRM_CoM_R2_N1_amp)
tmp = summary(dSRM_CoM_R2_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_R2_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_R2_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_CoM_R2) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_R2_vs_N1_amp.txt")
summary(dSRM_CoM_R2_N1_amp)
emmeans(dSRM_CoM_R2_N1_amp,pairwise~mag)
sink()

# VAF
# fit linear model for beta recon
dSRM_CoM_VAF_N1_amp = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*N1_amp + (1|Participant), data = dm)
print(dSRM_CoM_VAF_N1_amp)
summary(dSRM_CoM_VAF_N1_amp)
emmeans(dSRM_CoM_VAF_N1_amp,pairwise~mag)
VarCorr(dSRM_CoM_VAF_N1_amp)
tmp = summary(dSRM_CoM_VAF_N1_amp)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_CoM_VAF_vs_N1_amp.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_CoM_VAF_vs_N1_amp.pdf")
ggplot(dm) + aes(x = N1_amp, y = fit_agonist_TotalDual_CoM_VAF) + geom_point(aes(color = mag, size = 10)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_CoM_VAF_vs_N1_amp.txt")
summary(dSRM_CoM_VAF_N1_amp)
emmeans(dSRM_CoM_VAF_N1_amp,pairwise~mag)
sink()



####### mSRM dSRM comparisons #######
## mSRM dSRM (beta) Recon Compare ####
# VAF
df = melt(dm, id = c("Participant", "mag"), measure.vars = c("fit_agonist_VAF", "fit_agonist_TotalDual_beta_VAF"))
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) + 
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
# lmer
mSRM_dSRM_beta_VAF_lmer = lmer(value ~ variable*mag + (1|Participant), data = df)
print(mSRM_dSRM_beta_VAF_lmer)
summary(mSRM_dSRM_beta_VAF_lmer)
emmeans(mSRM_dSRM_beta_VAF_lmer,pairwise~variable)
VarCorr(mSRM_dSRM_beta_VAF_lmer)
# save plot
jpeg("mSRM_dSRM_beta_VAF_compare.jpg",width = 450, height = 450)
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) + # geom_point(aes(color = Participant, size = I(5)))
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
dev.off()
pdf("mSRM_dSRM_beta_VAF_compare.pdf")
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) + 
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
dev.off()
sink("mSRM_dSRM_beta_VAF_compare.txt")
summary(mSRM_dSRM_beta_VAF_lmer)
emmeans(mSRM_dSRM_beta_VAF_lmer,pairwise~variable)
sink()

# R2
dr = melt(dm, id = c("Participant", "mag"), measure.vars = c("fit_agonist_R2", "fit_agonist_TotalDual_beta_R2"))
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
# lmer
mSRM_dSRM_beta_R2_lmer = lmer(value ~ variable*mag + (1|Participant), data = dr)
print(mSRM_dSRM_beta_R2_lmer)
summary(mSRM_dSRM_beta_R2_lmer)
emmeans(mSRM_dSRM_beta_R2_lmer,pairwise~variable)
VarCorr(mSRM_dSRM_beta_R2_lmer)
# save plot
jpeg("mSRM_dSRM_beta_R2_compare.jpg",width = 450, height = 450)
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
dev.off()
pdf("mSRM_dSRM_beta_R2_compare.pdf")
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
dev.off()
sink("mSRM_dSRM_beta_R2_compare.txt")
summary(mSRM_dSRM_beta_R2_lmer)
emmeans(mSRM_dSRM_beta_R2_lmer,pairwise~variable)
sink()

## mSRM dSRM (Cz) Recon Compare ####
# VAF
df = melt(dm, id = c("Participant", "mag"), measure.vars = c("fit_agonist_VAF", "fit_agonist_TotalDual_Cz_VAF"))
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
# lmer
mSRM_dSRM_Cz_VAF_lmer = lmer(value ~ variable*mag + (1|Participant), data = df)
print(mSRM_dSRM_Cz_VAF_lmer)
summary(mSRM_dSRM_Cz_VAF_lmer)
emmeans(mSRM_dSRM_Cz_VAF_lmer,pairwise~variable)
VarCorr(mSRM_dSRM_Cz_VAF_lmer)
# save plot
jpeg("mSRM_dSRM_Cz_VAF_compare.jpg",width = 450, height = 450)
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
dev.off()
pdf("mSRM_dSRM_Cz_VAF_compare.pdf")
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
dev.off()
sink("mSRM_dSRM_Cz_VAF_compare.txt")
summary(mSRM_dSRM_Cz_VAF_lmer)
emmeans(mSRM_dSRM_Cz_VAF_lmer,pairwise~variable)
sink()

# R2
dr = melt(dm, id = c("Participant", "mag"), measure.vars = c("fit_agonist_R2", "fit_agonist_TotalDual_Cz_R2"))
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
# lmer
mSRM_dSRM_Cz_R2_lmer = lmer(value ~ variable*mag + (1|Participant), data = dr)
print(mSRM_dSRM_Cz_R2_lmer)
summary(mSRM_dSRM_Cz_R2_lmer)
emmeans(mSRM_dSRM_Cz_R2_lmer,pairwise~variable)
VarCorr(mSRM_dSRM_Cz_R2_lmer)
# save plot
jpeg("mSRM_dSRM_Cz_R2_compare.jpg",width = 450, height = 450)
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
dev.off()
pdf("mSRM_dSRM_Cz_R2_compare.pdf")
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
dev.off()
sink("mSRM_dSRM_Cz_R2_compare.txt")
summary(mSRM_dSRM_Cz_R2_lmer)
emmeans(mSRM_dSRM_Cz_R2_lmer,pairwise~variable)
sink()

## mSRM dSRM (CoM) Recon Compare ####
# VAF
df = melt(dm, id = c("Participant", "mag"), measure.vars = c("fit_agonist_VAF", "fit_agonist_TotalDual_CoM_VAF"))
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
# lmer
mSRM_dSRM_CoM_VAF_lmer = lmer(value ~ variable*mag + (1|Participant), data = df)
print(mSRM_dSRM_CoM_VAF_lmer)
summary(mSRM_dSRM_CoM_VAF_lmer)
emmeans(mSRM_dSRM_CoM_VAF_lmer,pairwise~variable)
VarCorr(mSRM_dSRM_CoM_VAF_lmer)
# save plot
jpeg("mSRM_dSRM_CoM_VAF_compare.jpg",width = 450, height = 450)
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
dev.off()
pdf("mSRM_dSRM_CoM_VAF_compare.pdf")
ggplot(df) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "VAF") + ylim(0,1)
dev.off()
sink("mSRM_dSRM_CoM_VAF_compare.txt")
summary(mSRM_dSRM_CoM_VAF_lmer)
emmeans(mSRM_dSRM_CoM_VAF_lmer,pairwise~variable)
sink()


# R2
dr = melt(dm, id = c("Participant", "mag"), measure.vars = c("fit_agonist_R2", "fit_agonist_TotalDual_CoM_R2"))
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
# lmer
mSRM_dSRM_CoM_R2_lmer = lmer(value ~ variable*mag + (1|Participant), data = dr)
print(mSRM_dSRM_CoM_R2_lmer)
summary(mSRM_dSRM_CoM_R2_lmer)
emmeans(mSRM_dSRM_CoM_R2_lmer,pairwise~variable)
VarCorr(mSRM_dSRM_CoM_R2_lmer)
# save plot
jpeg("mSRM_dSRM_CoM_R2_compare.jpg",width = 450, height = 450)
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
dev.off()
pdf("mSRM_dSRM_CoM_R2_compare.pdf")
ggplot(dr) + geom_boxplot() + aes(x = variable, y = value) + geom_point(aes(size = I(2))) +
  geom_line(aes(group = Participant)) + facet_wrap(vars(mag)) + theme_classic() +
  labs(x = "Model", y = "R2") + ylim(0,1)
dev.off()
sink("mSRM_dSRM_CoM_R2_compare.txt")
summary(mSRM_dSRM_CoM_R2_lmer)
emmeans(mSRM_dSRM_CoM_R2_lmer,pairwise~variable)
sink()

###### SRM Recon Accuracy vs Pert Mag ######
## cSRM (beta) Recon Accuracy vs Perturbation Magnitude ####
# R2
cSRM_beta_R2_pert_mag = lmer(fit_beta_R2 ~ mag + (1|Participant), data = dm)
print(cSRM_beta_R2_pert_mag)
summary(cSRM_beta_R2_pert_mag)
emmeans(cSRM_beta_R2_pert_mag,pairwise~mag)
VarCorr(cSRM_beta_R2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_beta_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("cSRM_beta_R2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_beta_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("cSRM_beta_R2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_beta_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("cSRM_beta_R2_vs_pert_mag.txt")
summary(cSRM_beta_R2_pert_mag)
emmeans(cSRM_beta_R2_pert_mag,pairwise~mag)
sink()

# ANOVA
cSRM_beta_R2_pert_mag_aov_car = aov_car(fit_beta_R2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_beta_R2_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_beta_R2_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_beta_R2_pert_mag_aov_car, x = "mag")
print(cSRM_beta_R2_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(cSRM_beta_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_R2_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_beta_R2_pert_mag_aov_car.txt")
emmeans(cSRM_beta_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_R2_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# VAF
cSRM_beta_VAF_pert_mag = lmer(fit_beta_VAF ~ mag + (1|Participant), data = dm)
print(cSRM_beta_VAF_pert_mag)
summary(cSRM_beta_VAF_pert_mag)
emmeans(cSRM_beta_VAF_pert_mag,pairwise~mag)
VarCorr(cSRM_beta_VAF_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_beta_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("cSRM_beta_VAF_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_beta_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("cSRM_beta_VAF_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_beta_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("cSRM_beta_VAF_vs_pert_mag.txt")
summary(cSRM_beta_VAF_pert_mag)
emmeans(cSRM_beta_VAF_pert_mag,pairwise~mag)
sink()

# ANOVA
cSRM_beta_VAF_pert_mag_aov_car = aov_car(fit_beta_VAF ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_beta_VAF_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_beta_VAF_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_beta_VAF_pert_mag_aov_car, x = "mag")
print(cSRM_beta_VAF_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(cSRM_beta_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_VAF_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_beta_VAF_pert_mag_aov_car.txt")
emmeans(cSRM_beta_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_VAF_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## cSRM (Cz) Recon Accuracy vs Perturbation Magnitude ####
# R2
cSRM_Cz_R2_pert_mag = lmer(fit_Cz_R2 ~ mag + (1|Participant), data = dm)
print(cSRM_Cz_R2_pert_mag)
summary(cSRM_Cz_R2_pert_mag)
emmeans(cSRM_Cz_R2_pert_mag,pairwise~mag)
VarCorr(cSRM_Cz_R2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_Cz_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("cSRM_Cz_R2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_Cz_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("cSRM_Cz_R2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_Cz_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("cSRM_Cz_R2_vs_pert_mag.txt")
summary(cSRM_Cz_R2_pert_mag)
emmeans(cSRM_Cz_R2_pert_mag,pairwise~mag)
sink()

# ANOVA
cSRM_Cz_R2_pert_mag_aov_car = aov_car(fit_Cz_R2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_Cz_R2_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_Cz_R2_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_Cz_R2_pert_mag_aov_car, x = "mag")
print(cSRM_Cz_R2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_Cz_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_R2_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_Cz_R2_pert_mag_aov_car.txt")
emmeans(cSRM_Cz_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_R2_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# VAF
cSRM_Cz_VAF_pert_mag = lmer(fit_Cz_VAF ~ mag + (1|Participant), data = dm)
print(cSRM_Cz_VAF_pert_mag)
summary(cSRM_Cz_VAF_pert_mag)
emmeans(cSRM_Cz_VAF_pert_mag,pairwise~mag)
VarCorr(cSRM_Cz_VAF_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_Cz_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("cSRM_Cz_VAF_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_Cz_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("cSRM_Cz_VAF_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_Cz_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("cSRM_Cz_VAF_vs_pert_mag.txt")
summary(cSRM_Cz_VAF_pert_mag)
emmeans(cSRM_Cz_VAF_pert_mag,pairwise~mag)
sink()

# ANOVA
cSRM_Cz_VAF_pert_mag_aov_car = aov_car(fit_Cz_VAF ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_Cz_VAF_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_Cz_VAF_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_Cz_VAF_pert_mag_aov_car, x = "mag")
print(cSRM_Cz_VAF_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_Cz_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_VAF_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_Cz_VAF_pert_mag_aov_car.txt")
emmeans(cSRM_Cz_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_VAF_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## mSRM Recon Accuracy vs Perturbation Magnitude ####
# R2
mSRM_R2_pert_mag = lmer(fit_agonist_R2 ~ mag + (1|Participant), data = dm)
print(mSRM_R2_pert_mag)
summary(mSRM_R2_pert_mag)
emmeans(mSRM_R2_pert_mag,pairwise~mag)
VarCorr(mSRM_R2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("mSRM_R2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("mSRM_R2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("mSRM_R2_vs_pert_mag.txt")
summary(mSRM_R2_pert_mag)
emmeans(mSRM_R2_pert_mag,pairwise~mag)
sink()

# ANOVA
mSRM_R2_pert_mag_aov_car = aov_car(fit_agonist_R2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(mSRM_R2_pert_mag_aov_car$lm$residuals)
qqPlot(mSRM_R2_pert_mag_aov_car$lm$residuals)
afex_plot(mSRM_R2_pert_mag_aov_car, x = "mag")
print(mSRM_R2_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(mSRM_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_R2_pert_mag_aov_car))
pairs(emmeans(mSRM_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("mSRM_R2_vs_pert_mag._aov_car.txt")
emmeans(mSRM_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_R2_pert_mag_aov_car))
pairs(emmeans(mSRM_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# VAF
mSRM_VAF_pert_mag = lmer(fit_agonist_VAF ~ mag + (1|Participant), data = dm)
print(mSRM_VAF_pert_mag)
summary(mSRM_VAF_pert_mag)
emmeans(mSRM_VAF_pert_mag,pairwise~mag)
VarCorr(mSRM_VAF_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("mSRM_VAF_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("mSRM_VAF_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("mSRM_VAF_vs_pert_mag.txt")
summary(mSRM_VAF_pert_mag)
emmeans(mSRM_VAF_pert_mag,pairwise~mag)
sink()

# ANOVA
mSRM_VAF_pert_mag_aov_car = aov_car(fit_agonist_VAF ~ mag + Error(Participant/mag), data = dm)
shapiro.test(mSRM_VAF_pert_mag_aov_car$lm$residuals)
qqPlot(mSRM_VAF_pert_mag_aov_car$lm$residuals)
afex_plot(mSRM_VAF_pert_mag_aov_car, x = "mag")
print(mSRM_VAF_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(mSRM_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_VAF_pert_mag_aov_car))
pairs(emmeans(mSRM_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("mSRM_VAF_vs_pert_mag._aov_car.txt")
emmeans(mSRM_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_VAF_pert_mag_aov_car))
pairs(emmeans(mSRM_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


## dSRM (beta) Recon Accuracy vs Perturbation Magnitude ####
# R2
dSRM_beta_R2_pert_mag = lmer(fit_agonist_TotalDual_beta_R2 ~ mag + (1|Participant), data = dm)
print(dSRM_beta_R2_pert_mag)
summary(dSRM_beta_R2_pert_mag)
emmeans(dSRM_beta_R2_pert_mag,pairwise~mag)
VarCorr(dSRM_beta_R2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_beta_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("dSRM_beta_R2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_beta_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("dSRM_beta_R2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_beta_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("dSRM_beta_R2_vs_pert_mag.txt")
summary(dSRM_beta_R2_pert_mag)
emmeans(dSRM_beta_R2_pert_mag,pairwise~mag)
sink()

# VAF
dSRM_beta_VAF_pert_mag = lmer(fit_agonist_TotalDual_beta_VAF ~ mag + (1|Participant), data = dm)
print(dSRM_beta_VAF_pert_mag)
summary(dSRM_beta_VAF_pert_mag)
emmeans(dSRM_beta_VAF_pert_mag,pairwise~mag)
VarCorr(dSRM_beta_VAF_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_beta_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("dSRM_beta_VAF_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_beta_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("dSRM_beta_VAF_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_beta_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("dSRM_beta_VAF_vs_pert_mag.txt")
summary(dSRM_beta_VAF_pert_mag)
emmeans(dSRM_beta_VAF_pert_mag,pairwise~mag)
sink()

## dSRM (Cz) Recon Accuracy vs Perturbation Magnitude ####
# R2
dSRM_Cz_R2_pert_mag = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_R2_pert_mag)
summary(dSRM_Cz_R2_pert_mag)
emmeans(dSRM_Cz_R2_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_R2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_Cz_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("dSRM_Cz_R2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_Cz_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("dSRM_Cz_R2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_Cz_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("dSRM_Cz_R2_vs_pert_mag.txt")
summary(dSRM_Cz_R2_pert_mag)
emmeans(dSRM_Cz_R2_pert_mag,pairwise~mag)
sink()

# VAF
dSRM_Cz_VAF_pert_mag = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_VAF_pert_mag)
summary(dSRM_Cz_VAF_pert_mag)
emmeans(dSRM_Cz_VAF_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_VAF_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_Cz_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("dSRM_Cz_VAF_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_Cz_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("dSRM_Cz_VAF_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_Cz_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("dSRM_Cz_VAF_vs_pert_mag.txt")
summary(dSRM_Cz_VAF_pert_mag)
emmeans(dSRM_Cz_VAF_pert_mag,pairwise~mag)
sink()



## dSRM (CoM) Recon Accuracy vs Perturbation Magnitude ####
# R2
dSRM_CoM_R2_pert_mag = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_R2_pert_mag)
summary(dSRM_CoM_R2_pert_mag)
emmeans(dSRM_CoM_R2_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_R2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_CoM_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("dSRM_CoM_R2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_CoM_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("dSRM_CoM_R2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_CoM_R2) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("dSRM_CoM_R2_vs_pert_mag.txt")
summary(dSRM_CoM_R2_pert_mag)
emmeans(dSRM_CoM_R2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_R2_pert_mag_aov_car = aov_car(fit_agonist_TotalDual_CoM_R2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_R2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_R2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_R2_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_R2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_R2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_R2_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_R2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_R2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_R2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# VAF
dSRM_CoM_VAF_pert_mag = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_VAF_pert_mag)
summary(dSRM_CoM_VAF_pert_mag)
emmeans(dSRM_CoM_VAF_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_VAF_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_CoM_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("dSRM_CoM_VAF_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_CoM_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("dSRM_CoM_VAF_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = fit_agonist_TotalDual_CoM_VAF) + ylim(0, 1) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("dSRM_CoM_VAF_vs_pert_mag.txt")
summary(dSRM_CoM_VAF_pert_mag)
emmeans(dSRM_CoM_VAF_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_VAF_pert_mag_aov_car = aov_car(fit_agonist_TotalDual_CoM_VAF ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_VAF_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_VAF_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_VAF_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_VAF_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_VAF_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_VAF_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_VAF_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_VAF_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_VAF_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


####### SRM Gains vs Perturbation Magnitude #######
## mSRM Gains vs Perturbation Magnitude ####
# ka
mSRM_ka_pert_mag = lmer(Ag_Gains_ka ~ mag + (1|Participant), data = dm)
print(mSRM_ka_pert_mag)
summary(mSRM_ka_pert_mag)
emmeans(mSRM_ka_pert_mag,pairwise~mag)
VarCorr(mSRM_ka_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("mSRM_ka_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("mSRM_ka_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("mSRM_ka_vs_pert_mag.txt")
summary(mSRM_ka_pert_mag)
emmeans(mSRM_ka_pert_mag,pairwise~mag)
sink()
# ANOVA
mSRM_ka_pert_mag_aov_car = aov_car(Ag_Gains_ka ~ mag + Error(Participant/mag), data = dm)
shapiro.test(mSRM_ka_pert_mag_aov_car$lm$residuals)
qqPlot(mSRM_ka_pert_mag_aov_car$lm$residuals)
afex_plot(mSRM_ka_pert_mag_aov_car, x = "mag")
print(mSRM_ka_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(mSRM_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_ka_pert_mag_aov_car))
pairs(emmeans(mSRM_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("mSRM_ka_pert_mag_aov_car.txt")
emmeans(mSRM_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_ka_pert_mag_aov_car))
pairs(emmeans(mSRM_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kv
mSRM_kv_pert_mag = lmer(Ag_Gains_kv ~ mag + (1|Participant), data = dm)
print(mSRM_kv_pert_mag)
summary(mSRM_kv_pert_mag)
emmeans(mSRM_kv_pert_mag,pairwise~mag)
VarCorr(mSRM_kv_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("mSRM_kv_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("mSRM_kv_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("mSRM_kv_vs_pert_mag.txt")
summary(mSRM_kv_pert_mag)
emmeans(mSRM_kv_pert_mag,pairwise~mag)
sink()
# ANOVA
mSRM_kv_pert_mag_aov_car = aov_car(Ag_Gains_kv ~ mag + Error(Participant/mag), data = dm)
shapiro.test(mSRM_kv_pert_mag_aov_car$lm$residuals)
qqPlot(mSRM_kv_pert_mag_aov_car$lm$residuals)
afex_plot(mSRM_kv_pert_mag_aov_car, x = "mag")
print(mSRM_kv_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(mSRM_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_kv_pert_mag_aov_car))
pairs(emmeans(mSRM_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("mSRM_kv_pert_mag_aov_car.txt")
emmeans(mSRM_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_kv_pert_mag_aov_car))
pairs(emmeans(mSRM_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd
mSRM_kd_pert_mag = lmer(Ag_Gains_kd ~ mag + (1|Participant), data = dm)
print(mSRM_kd_pert_mag)
summary(mSRM_kd_pert_mag)
emmeans(mSRM_kd_pert_mag,pairwise~mag)
VarCorr(mSRM_kd_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("mSRM_kd_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("mSRM_kd_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("mSRM_kd_vs_pert_mag.txt")
summary(mSRM_kd_pert_mag)
emmeans(mSRM_kd_pert_mag,pairwise~mag)
sink()
# ANOVA
mSRM_kd_pert_mag_aov_car = aov_car(Ag_Gains_kd ~ mag + Error(Participant/mag), data = dm)
shapiro.test(mSRM_kd_pert_mag_aov_car$lm$residuals)
qqPlot(mSRM_kd_pert_mag_aov_car$lm$residuals)
afex_plot(mSRM_kd_pert_mag_aov_car, x = "mag")
print(mSRM_kd_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(mSRM_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_kd_pert_mag_aov_car))
pairs(emmeans(mSRM_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("mSRM_kd_pert_mag_aov_car.txt")
emmeans(mSRM_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_kd_pert_mag_aov_car))
pairs(emmeans(mSRM_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda
mSRM_lambda_pert_mag = lmer(Ag_Gains_lambda ~ mag + (1|Participant), data = dm)
print(mSRM_lambda_pert_mag)
summary(mSRM_lambda_pert_mag)
emmeans(mSRM_lambda_pert_mag,pairwise~mag)
VarCorr(mSRM_lambda_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_lambda) + geom_point() +  ylim(0,0.2) +
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("mSRM_lambda_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_lambda) + geom_point() + ylim(0,0.2) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("mSRM_lambda_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_lambda) + geom_point() + ylim(0,0.2) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("mSRM_lambda_vs_pert_mag.txt")
summary(mSRM_lambda_pert_mag)
emmeans(mSRM_lambda_pert_mag,pairwise~mag)
sink()
# ANOVA
mSRM_lambda_pert_mag_aov_car = aov_car(Ag_Gains_lambda ~ mag + Error(Participant/mag), data = dm)
shapiro.test(mSRM_lambda_pert_mag_aov_car$lm$residuals)
qqPlot(mSRM_lambda_pert_mag_aov_car$lm$residuals)
afex_plot(mSRM_lambda_pert_mag_aov_car, x = "mag")
print(mSRM_lambda_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(mSRM_lambda_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_lambda_pert_mag_aov_car))
pairs(emmeans(mSRM_lambda_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("mSRM_lambda_pert_mag_aov_car.txt")
emmeans(mSRM_lambda_pert_mag_aov_car,~mag)
knitr::kable(nice(mSRM_lambda_pert_mag_aov_car))
pairs(emmeans(mSRM_lambda_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## cSRM (beta) Gains vs Perturbation Magnitude ####
# ka
cSRM_beta_ka_pert_mag = lmer(Beta_Gains_ka ~ mag + (1|Participant), data = dm)
print(cSRM_beta_ka_pert_mag)
summary(cSRM_beta_ka_pert_mag)
emmeans(cSRM_beta_ka_pert_mag,pairwise~mag)
VarCorr(cSRM_beta_ka_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_ka) + geom_point() + ylim(0,5) +
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_beta_ka_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_ka) + geom_point() + ylim(0,5) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_beta_ka_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_ka) + geom_point() + ylim(0,5) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_beta_ka_vs_pert_mag.txt")
summary(cSRM_beta_ka_pert_mag)
emmeans(cSRM_beta_ka_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_beta_ka_pert_mag_aov_car = aov_car(Beta_Gains_ka ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_beta_ka_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_beta_ka_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_beta_ka_pert_mag_aov_car, x = "mag")
print(cSRM_beta_ka_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_beta_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_ka_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_beta_ka_pert_mag_aov_car.txt")
emmeans(cSRM_beta_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_ka_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kv
cSRM_beta_kv_pert_mag = lmer(Beta_Gains_kv ~ mag + (1|Participant), data = dm)
print(cSRM_beta_kv_pert_mag)
summary(cSRM_beta_kv_pert_mag)
emmeans(cSRM_beta_kv_pert_mag,pairwise~mag)
VarCorr(cSRM_beta_kv_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_beta_kv_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_beta_kv_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_beta_kv_vs_pert_mag.txt")
summary(cSRM_beta_kv_pert_mag)
emmeans(cSRM_beta_kv_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_beta_kv_pert_mag_aov_car = aov_car(Beta_Gains_kv ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_beta_kv_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_beta_kv_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_beta_kv_pert_mag_aov_car, x = "mag")
print(cSRM_beta_kv_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_beta_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_kv_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_beta_kv_pert_mag_aov_car.txt")
emmeans(cSRM_beta_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_kv_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd
cSRM_beta_kd_pert_mag = lmer(Beta_Gains_kd ~ mag + (1|Participant), data = dm)
print(cSRM_beta_kd_pert_mag)
summary(cSRM_beta_kd_pert_mag)
emmeans(cSRM_beta_kd_pert_mag,pairwise~mag)
VarCorr(cSRM_beta_kd_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_beta_kd_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_beta_kd_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_beta_kd_vs_pert_mag.txt")
summary(cSRM_beta_kd_pert_mag)
emmeans(cSRM_beta_kd_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_beta_kd_pert_mag_aov_car = aov_car(Beta_Gains_kd ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_beta_kd_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_beta_kd_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_beta_kd_pert_mag_aov_car, x = "mag")
print(cSRM_beta_kd_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_beta_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_kd_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_beta_kd_pert_mag_aov_car.txt")
emmeans(cSRM_beta_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_kd_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda
cSRM_beta_lambda_pert_mag = lmer(Beta_Gains_lambda ~ mag + (1|Participant), data = dm)
print(cSRM_beta_lambda_pert_mag)
summary(cSRM_beta_lambda_pert_mag)
emmeans(cSRM_beta_lambda_pert_mag,pairwise~mag)
VarCorr(cSRM_beta_lambda_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_lambda) + geom_point() +  ylim(0,0.1) +
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_beta_lambda_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_lambda) + geom_point() +  ylim(0,0.1) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_beta_lambda_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Beta_Gains_lambda) + geom_point() +  ylim(0,0.1) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_beta_lambda_vs_pert_mag.txt")
summary(cSRM_beta_lambda_pert_mag)
emmeans(cSRM_beta_lambda_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_beta_lambda_pert_mag_aov_car = aov_car(Beta_Gains_lambda ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_beta_lambda_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_beta_lambda_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_beta_lambda_pert_mag_aov_car, x = "mag")
print(cSRM_beta_lambda_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_beta_lambda_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_lambda_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_lambda_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_beta_lambda_pert_mag_aov_car.txt")
emmeans(cSRM_beta_lambda_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_beta_lambda_pert_mag_aov_car))
pairs(emmeans(cSRM_beta_lambda_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## cSRM (Cz) Gains vs Perturbation Magnitude ####
# ka
cSRM_Cz_ka_pert_mag = lmer(Cz_Gains_ka ~ mag + (1|Participant), data = dm)
print(cSRM_Cz_ka_pert_mag)
summary(cSRM_Cz_ka_pert_mag)
emmeans(cSRM_Cz_ka_pert_mag,pairwise~mag)
VarCorr(cSRM_Cz_ka_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_ka) + geom_point() + ylim(0,5) +
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_Cz_ka_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_ka) + geom_point() + ylim(0,5) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_Cz_ka_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_ka) + geom_point() + ylim(0,5) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_Cz_ka_vs_pert_mag.txt")
summary(cSRM_Cz_ka_pert_mag)
emmeans(cSRM_Cz_ka_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_Cz_ka_pert_mag_aov_car = aov_car(Cz_Gains_ka ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_Cz_ka_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_Cz_ka_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_Cz_ka_pert_mag_aov_car, x = "mag")
print(cSRM_Cz_ka_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_Cz_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_ka_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_Cz_ka_pert_mag_aov_car.txt")
emmeans(cSRM_Cz_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_ka_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kv
cSRM_Cz_kv_pert_mag = lmer(Cz_Gains_kv ~ mag + (1|Participant), data = dm)
print(cSRM_Cz_kv_pert_mag)
summary(cSRM_Cz_kv_pert_mag)
emmeans(cSRM_Cz_kv_pert_mag,pairwise~mag)
VarCorr(cSRM_Cz_kv_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_Cz_kv_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_Cz_kv_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_Cz_kv_vs_pert_mag.txt")
summary(cSRM_Cz_kv_pert_mag)
emmeans(cSRM_Cz_kv_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_Cz_kv_pert_mag_aov_car = aov_car(Cz_Gains_kv ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_Cz_kv_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_Cz_kv_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_Cz_kv_pert_mag_aov_car, x = "mag")
print(cSRM_Cz_kv_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_Cz_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_kv_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_Cz_kv_pert_mag_aov_car.txt")
emmeans(cSRM_Cz_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_kv_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd
cSRM_Cz_kd_pert_mag = lmer(Cz_Gains_kd ~ mag + (1|Participant), data = dm)
print(cSRM_Cz_kd_pert_mag)
summary(cSRM_Cz_kd_pert_mag)
emmeans(cSRM_Cz_kd_pert_mag,pairwise~mag)
VarCorr(cSRM_Cz_kd_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_Cz_kd_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_Cz_kd_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_Cz_kd_vs_pert_mag.txt")
summary(cSRM_Cz_kd_pert_mag)
emmeans(cSRM_Cz_kd_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_Cz_kd_pert_mag_aov_car = aov_car(Cz_Gains_kd ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_Cz_kd_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_Cz_kd_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_Cz_kd_pert_mag_aov_car, x = "mag")
print(cSRM_Cz_kd_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_Cz_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_kd_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_Cz_kd_pert_mag_aov_car.txt")
emmeans(cSRM_Cz_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_kd_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda
cSRM_Cz_lambda_pert_mag = lmer(Cz_Gains_lambda ~ mag + (1|Participant), data = dm)
print(cSRM_Cz_lambda_pert_mag)
summary(cSRM_Cz_lambda_pert_mag)
emmeans(cSRM_Cz_lambda_pert_mag,pairwise~mag)
VarCorr(cSRM_Cz_lambda_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_lambda) + geom_point() + ylim(0,0.1) +
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("cSRM_Cz_lambda_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_lambda) + geom_point() + ylim(0,0.1) + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("cSRM_Cz_lambda_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Cz_Gains_lambda) + geom_point() + ylim(0,0.1) + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("cSRM_Cz_lambda_vs_pert_mag.txt")
summary(cSRM_Cz_lambda_pert_mag)
emmeans(cSRM_Cz_lambda_pert_mag,pairwise~mag)
sink()
# ANOVA
cSRM_Cz_lambda_pert_mag_aov_car = aov_car(Cz_Gains_lambda ~ mag + Error(Participant/mag), data = dm)
shapiro.test(cSRM_Cz_lambda_pert_mag_aov_car$lm$residuals)
qqPlot(cSRM_Cz_lambda_pert_mag_aov_car$lm$residuals)
afex_plot(cSRM_Cz_lambda_pert_mag_aov_car, x = "mag")
print(cSRM_Cz_lambda_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(cSRM_Cz_lambda_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_lambda_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_lambda_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("cSRM_Cz_lambda_pert_mag_aov_car.txt")
emmeans(cSRM_Cz_lambda_pert_mag_aov_car,~mag)
knitr::kable(nice(cSRM_Cz_lambda_pert_mag_aov_car))
pairs(emmeans(cSRM_Cz_lambda_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## dSRM (Beta) Gains vs Perturbation Magnitude ####
# ka
dSRM_Beta_ka_pert_mag = lmer(Ag_Gains_TotalDual_beta_ka ~ mag + (1|Participant), data = dm)
print(dSRM_Beta_ka_pert_mag)
summary(dSRM_Beta_ka_pert_mag)
emmeans(dSRM_Beta_ka_pert_mag,pairwise~mag)
VarCorr(dSRM_Beta_ka_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Beta_ka_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Beta_ka_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Beta_ka_vs_pert_mag.txt")
summary(dSRM_Beta_ka_pert_mag)
emmeans(dSRM_Beta_ka_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Beta_ka_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_beta_ka ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Beta_ka_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Beta_ka_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Beta_ka_pert_mag_aov_car, x = "mag")
print(dSRM_Beta_ka_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Beta_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_ka_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Beta_ka_pert_mag_aov_car.txt")
emmeans(dSRM_Beta_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_ka_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


# kv
dSRM_Beta_kv_pert_mag = lmer(Ag_Gains_TotalDual_beta_kv ~ mag + (1|Participant), data = dm)
print(dSRM_Beta_kv_pert_mag)
summary(dSRM_Beta_kv_pert_mag)
emmeans(dSRM_Beta_kv_pert_mag,pairwise~mag)
VarCorr(dSRM_Beta_kv_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kv) + geom_point() + 
geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Beta_kv_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Beta_kv_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Beta_kv_vs_pert_mag.txt")
summary(dSRM_Beta_kv_pert_mag)
emmeans(dSRM_Beta_kv_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Beta_kv_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_beta_kv ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Beta_kv_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Beta_kv_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Beta_kv_pert_mag_aov_car, x = "mag")
print(dSRM_Beta_kv_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Beta_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_kv_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Beta_kv_pert_mag_aov_car.txt")
emmeans(dSRM_Beta_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_kv_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd
dSRM_Beta_kd_pert_mag = lmer(Ag_Gains_TotalDual_beta_kd ~ mag + (1|Participant), data = dm)
print(dSRM_Beta_kd_pert_mag)
summary(dSRM_Beta_kd_pert_mag)
emmeans(dSRM_Beta_kd_pert_mag,pairwise~mag)
VarCorr(dSRM_Beta_kd_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Beta_kd_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Beta_kd_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Beta_kd_vs_pert_mag.txt")
summary(dSRM_Beta_kd_pert_mag)
emmeans(dSRM_Beta_kd_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Beta_kd_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_beta_kd ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Beta_kd_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Beta_kd_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Beta_kd_pert_mag_aov_car, x = "mag")
print(dSRM_Beta_kd_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Beta_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_kd_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Beta_kd_pert_mag_aov_car.txt")
emmeans(dSRM_Beta_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_kd_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda1
dSRM_Beta_lambda1_pert_mag = lmer(Ag_Gains_TotalDual_beta_lambda1 ~ mag + (1|Participant), data = dm)
print(dSRM_Beta_lambda1_pert_mag)
summary(dSRM_Beta_lambda1_pert_mag)
emmeans(dSRM_Beta_lambda1_pert_mag,pairwise~mag)
VarCorr(dSRM_Beta_lambda1_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Beta_lambda1_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Beta_lambda1_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Beta_lambda1_vs_pert_mag.txt")
summary(dSRM_Beta_lambda1_pert_mag)
emmeans(dSRM_Beta_lambda1_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Beta_lambda1_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_beta_lambda1 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Beta_lambda1_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Beta_lambda1_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Beta_lambda1_pert_mag_aov_car, x = "mag")
print(dSRM_Beta_lambda1_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Beta_lambda1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_lambda1_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_lambda1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Beta_lambda1_pert_mag_aov_car.txt")
emmeans(dSRM_Beta_lambda1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_lambda1_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_lambda1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kb
dSRM_Beta_kb_pert_mag = lmer(Ag_Gains_TotalDual_beta_kb ~ mag + (1|Participant), data = dm)
print(dSRM_Beta_kb_pert_mag)
summary(dSRM_Beta_kb_pert_mag)
emmeans(dSRM_Beta_kb_pert_mag,pairwise~mag)
VarCorr(dSRM_Beta_kb_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kb) + geom_point() + ylim(0,0.6) +
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Beta_kb_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kb) + geom_point() +  ylim(0,0.6) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Beta_kb_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kb) + geom_point() +  ylim(0,0.6) +
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Beta_kb_vs_pert_mag.txt")
summary(dSRM_Beta_kb_pert_mag)
emmeans(dSRM_Beta_kb_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Beta_kb_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_beta_kb ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Beta_kb_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Beta_kb_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Beta_kb_pert_mag_aov_car, x = "mag")
print(dSRM_Beta_kb_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Beta_kb_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_kb_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_kb_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Beta_kb_pert_mag_aov_car.txt")
emmeans(dSRM_Beta_kb_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_kb_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_kb_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda2
dSRM_Beta_lambda2_pert_mag = lmer(Ag_Gains_TotalDual_beta_lambda2 ~ mag + (1|Participant), data = dm)
print(dSRM_Beta_lambda2_pert_mag)
summary(dSRM_Beta_lambda2_pert_mag)
emmeans(dSRM_Beta_lambda2_pert_mag,pairwise~mag)
VarCorr(dSRM_Beta_lambda2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Beta_lambda2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Beta_lambda2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Beta_lambda2_vs_pert_mag.txt")
summary(dSRM_Beta_lambda2_pert_mag)
emmeans(dSRM_Beta_lambda2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Beta_lambda2_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_beta_lambda2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Beta_lambda2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Beta_lambda2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Beta_lambda2_pert_mag_aov_car, x = "mag")
print(dSRM_Beta_lambda2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Beta_lambda2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_lambda2_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_lambda2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Beta_lambda2_pert_mag_aov_car.txt")
emmeans(dSRM_Beta_lambda2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Beta_lambda2_pert_mag_aov_car))
pairs(emmeans(dSRM_Beta_lambda2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## dSRM (Cz) Gains vs Perturbation Magnitude ####
# ka
dSRM_Cz_ka_pert_mag = lmer(Ag_Gains_TotalDual_Cz_ka ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_ka_pert_mag)
summary(dSRM_Cz_ka_pert_mag)
emmeans(dSRM_Cz_ka_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_ka_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Cz_ka_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Cz_ka_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_ka) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Cz_ka_vs_pert_mag.txt")
summary(dSRM_Cz_ka_pert_mag)
emmeans(dSRM_Cz_ka_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Cz_ka_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_Cz_ka ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Cz_ka_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Cz_ka_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Cz_ka_pert_mag_aov_car, x = "mag")
print(dSRM_Cz_ka_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Cz_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_ka_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Cz_ka_pert_mag_aov_car.txt")
emmeans(dSRM_Cz_ka_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_ka_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_ka_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kv
dSRM_Cz_kv_pert_mag = lmer(Ag_Gains_TotalDual_Cz_kv ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_kv_pert_mag)
summary(dSRM_Cz_kv_pert_mag)
emmeans(dSRM_Cz_kv_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_kv_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kv) + geom_point() + 
geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Cz_kv_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Cz_kv_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kv) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Cz_kv_vs_pert_mag.txt")
summary(dSRM_Cz_kv_pert_mag)
emmeans(dSRM_Cz_kv_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Cz_kv_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_Cz_kv ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Cz_kv_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Cz_kv_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Cz_kv_pert_mag_aov_car, x = "mag")
print(dSRM_Cz_kv_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Cz_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_kv_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Cz_kv_pert_mag_aov_car.txt")
emmeans(dSRM_Cz_kv_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_kv_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_kv_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd
dSRM_Cz_kd_pert_mag = lmer(Ag_Gains_TotalDual_Cz_kd ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_kd_pert_mag)
summary(dSRM_Cz_kd_pert_mag)
emmeans(dSRM_Cz_kd_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_kd_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Cz_kd_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Cz_kd_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kd) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Cz_kd_vs_pert_mag.txt")
summary(dSRM_Cz_kd_pert_mag)
emmeans(dSRM_Cz_kd_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Cz_kd_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_Cz_kd ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Cz_kd_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Cz_kd_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Cz_kd_pert_mag_aov_car, x = "mag")
print(dSRM_Cz_kd_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Cz_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_kd_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Cz_kd_pert_mag_aov_car.txt")
emmeans(dSRM_Cz_kd_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_kd_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_kd_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda1
dSRM_Cz_lambda1_pert_mag = lmer(Ag_Gains_TotalDual_Cz_lambda1 ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_lambda1_pert_mag)
summary(dSRM_Cz_lambda1_pert_mag)
emmeans(dSRM_Cz_lambda1_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_lambda1_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Cz_lambda1_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Cz_lambda1_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Cz_lambda1_vs_pert_mag.txt")
summary(dSRM_Cz_lambda1_pert_mag)
emmeans(dSRM_Cz_lambda1_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Cz_lambda1_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_Cz_lambda1 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Cz_lambda1_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Cz_lambda1_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Cz_lambda1_pert_mag_aov_car, x = "mag")
print(dSRM_Cz_lambda1_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Cz_lambda1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_lambda1_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_lambda1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Cz_lambda1_pert_mag_aov_car.txt")
emmeans(dSRM_Cz_lambda1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_lambda1_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_lambda1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kCz
dSRM_Cz_kCz_pert_mag = lmer(Ag_Gains_TotalDual_Cz_kCz ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_kCz_pert_mag)
summary(dSRM_Cz_kCz_pert_mag)
emmeans(dSRM_Cz_kCz_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_kCz_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kCz) + ylim(0,0.6) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Cz_kCz_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kCz) + geom_point() + 
geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Cz_kCz_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kCz) + ylim(0,0.6)+ geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Cz_kCz_vs_pert_mag.txt")
summary(dSRM_Cz_kCz_pert_mag)
emmeans(dSRM_Cz_kCz_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Cz_kCz_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_Cz_kCz ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Cz_kCz_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Cz_kCz_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Cz_kCz_pert_mag_aov_car, x = "mag")
print(dSRM_Cz_kCz_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Cz_kCz_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_kCz_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_kCz_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Cz_kCz_pert_mag_aov_car.txt")
emmeans(dSRM_Cz_kCz_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_kCz_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_kCz_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda2
dSRM_Cz_lambda2_pert_mag = lmer(Ag_Gains_TotalDual_Cz_lambda2 ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_lambda2_pert_mag)
summary(dSRM_Cz_lambda2_pert_mag)
emmeans(dSRM_Cz_lambda2_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_lambda2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_Cz_lambda2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_Cz_lambda2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_lambda2) + ylim(0,0.4)  + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_Cz_lambda2_vs_pert_mag.txt")
summary(dSRM_Cz_lambda2_pert_mag)
emmeans(dSRM_Cz_lambda2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_Cz_lambda2_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_Cz_lambda2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_Cz_lambda2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_Cz_lambda2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_Cz_lambda2_pert_mag_aov_car, x = "mag")
print(dSRM_Cz_lambda2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_Cz_lambda2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_lambda2_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_lambda2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_Cz_lambda2_pert_mag_aov_car.txt")
emmeans(dSRM_Cz_lambda2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_Cz_lambda2_pert_mag_aov_car))
pairs(emmeans(dSRM_Cz_lambda2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## dSRM (CoM) Gains vs Perturbation Magnitude ####
# ka1
dSRM_CoM_ka1_pert_mag = lmer(Ag_Gains_TotalDual_CoM_ka1 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_ka1_pert_mag)
summary(dSRM_CoM_ka1_pert_mag)
emmeans(dSRM_CoM_ka1_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_ka1_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_ka1_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_ka1_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_ka1_vs_pert_mag.txt")
summary(dSRM_CoM_ka1_pert_mag)
emmeans(dSRM_CoM_ka1_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_ka1_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_ka1 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_ka1_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_ka1_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_ka1_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_ka1_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_ka1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_ka1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_ka1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_ka1_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_ka1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_ka1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_ka1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kv1
dSRM_CoM_kv1_pert_mag = lmer(Ag_Gains_TotalDual_CoM_kv1 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_kv1_pert_mag)
summary(dSRM_CoM_kv1_pert_mag)
emmeans(dSRM_CoM_kv1_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_kv1_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kv1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_kv1_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kv1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_kv1_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kv1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_kv1_vs_pert_mag.txt")
summary(dSRM_CoM_kv1_pert_mag)
emmeans(dSRM_CoM_kv1_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_kv1_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_kv1 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_kv1_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_kv1_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_kv1_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_kv1_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_kv1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kv1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kv1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_kv1_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_kv1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kv1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kv1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd1
dSRM_CoM_kd1_pert_mag = lmer(Ag_Gains_TotalDual_CoM_kd1 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_kd1_pert_mag)
summary(dSRM_CoM_kd1_pert_mag)
emmeans(dSRM_CoM_kd1_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_kd1_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kd1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_kd1_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kd1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_kd1_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kd1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_kd1_vs_pert_mag.txt")
summary(dSRM_CoM_kd1_pert_mag)
emmeans(dSRM_CoM_kd1_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_kd1_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_kd1 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_kd1_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_kd1_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_kd1_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_kd1_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_kd1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kd1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kd1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_kd1_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_kd1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kd1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kd1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda1
dSRM_CoM_lambda1_pert_mag = lmer(Ag_Gains_TotalDual_CoM_lambda1 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_lambda1_pert_mag)
summary(dSRM_CoM_lambda1_pert_mag)
emmeans(dSRM_CoM_lambda1_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_lambda1_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_lambda1_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_lambda1_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_lambda1) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_lambda1_vs_pert_mag.txt")
summary(dSRM_CoM_lambda1_pert_mag)
emmeans(dSRM_CoM_lambda1_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_lambda1_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_lambda1 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_lambda1_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_lambda1_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_lambda1_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_lambda1_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_lambda1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_lambda1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_lambda1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_lambda1_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_lambda1_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_lambda1_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_lambda1_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# ka2
dSRM_CoM_ka2_pert_mag = lmer(Ag_Gains_TotalDual_CoM_ka2 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_ka2_pert_mag)
summary(dSRM_CoM_ka2_pert_mag)
emmeans(dSRM_CoM_ka2_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_ka2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka2) + ylim(0,0.6)+ geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_ka2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka2) + ylim(0,0.6) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_ka2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka2) + ylim(0,0.6) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_ka2_vs_pert_mag.txt")
summary(dSRM_CoM_ka2_pert_mag)
emmeans(dSRM_CoM_ka2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_ka2_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_ka2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_ka2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_ka2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_ka2_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_ka2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_ka2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_ka2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_ka2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_ka2_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_ka2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_ka2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_ka2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kv2
dSRM_CoM_kv2_pert_mag = lmer(Ag_Gains_TotalDual_CoM_kv2 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_kv2_pert_mag)
summary(dSRM_CoM_kv2_pert_mag)
emmeans(dSRM_CoM_kv2_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_kv2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kv2) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_kv2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kv2) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_kv2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kv2) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_kv2_vs_pert_mag.txt")
summary(dSRM_CoM_kv2_pert_mag)
emmeans(dSRM_CoM_kv2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_kv2_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_kv2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_kv2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_kv2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_kv2_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_kv2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_kv2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kv2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kv2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_kv2_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_kv2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kv2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kv2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# kd2
dSRM_CoM_kd2_pert_mag = lmer(Ag_Gains_TotalDual_CoM_kd2 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_kd2_pert_mag)
summary(dSRM_CoM_kd2_pert_mag)
emmeans(dSRM_CoM_kd2_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_kd2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kd2) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_kd2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kd2) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_kd2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_kd2) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_kd2_vs_pert_mag.txt")
summary(dSRM_CoM_kd2_pert_mag)
emmeans(dSRM_CoM_kd2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_kd2_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_kd2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_kd2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_kd2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_kd2_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_kd2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_kd2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kd2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kd2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_kd2_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_kd2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_kd2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_kd2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

# lambda2
dSRM_CoM_lambda2_pert_mag = lmer(Ag_Gains_TotalDual_CoM_lambda2 ~ mag + (1|Participant), data = dm)
print(dSRM_CoM_lambda2_pert_mag)
summary(dSRM_CoM_lambda2_pert_mag)
emmeans(dSRM_CoM_lambda2_pert_mag,pairwise~mag)
VarCorr(dSRM_CoM_lambda2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("dSRM_CoM_lambda2_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_lambda2) + ylim(0,0.4) + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("dSRM_CoM_lambda2_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_lambda2) + ylim(0,0.4) + geom_point() + 
geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("dSRM_CoM_lambda2_vs_pert_mag.txt")
summary(dSRM_CoM_lambda2_pert_mag)
emmeans(dSRM_CoM_lambda2_pert_mag,pairwise~mag)
sink()
# ANOVA
dSRM_CoM_lambda2_pert_mag_aov_car = aov_car(Ag_Gains_TotalDual_CoM_lambda2 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(dSRM_CoM_lambda2_pert_mag_aov_car$lm$residuals)
qqPlot(dSRM_CoM_lambda2_pert_mag_aov_car$lm$residuals)
afex_plot(dSRM_CoM_lambda2_pert_mag_aov_car, x = "mag")
print(dSRM_CoM_lambda2_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(dSRM_CoM_lambda2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_lambda2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_lambda2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("dSRM_CoM_lambda2_pert_mag_aov_car.txt")
emmeans(dSRM_CoM_lambda2_pert_mag_aov_car,~mag)
knitr::kable(nice(dSRM_CoM_lambda2_pert_mag_aov_car))
pairs(emmeans(dSRM_CoM_lambda2_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

####### EMG Area Under Curve vs Perturbation Magnitude #######
## MGL_AUC vs Perturbation Magnitude ####
# MGL
MGL_AUC_pert_mag = lmer(MGL_AUC ~ mag + (1|Participant), data = dm)
print(MGL_AUC_pert_mag)
summary(MGL_AUC_pert_mag)
emmeans(MGL_AUC_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("MGL_AUC_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("MGL_AUC_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("MGL_AUC_vs_pert_mag.txt")
summary(MGL_AUC_pert_mag)
emmeans(MGL_AUC_pert_mag,pairwise~mag)
sink()

## MGL_AUC_0_500 vs Perturbation Magnitude ####
# MGL
MGL_AUC_0_500_pert_mag = lmer(MGL_AUC_0_500 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_0_500_pert_mag)
summary(MGL_AUC_0_500_pert_mag)
emmeans(MGL_AUC_0_500_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_0_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("MGL_AUC_0_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("MGL_AUC_0_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("MGL_AUC_0_500_vs_pert_mag.txt")
summary(MGL_AUC_0_500_pert_mag)
emmeans(MGL_AUC_0_500_pert_mag,pairwise~mag)
sink()

## MGL_AUC_50_150 vs Perturbation Magnitude ####
# MGL
MGL_AUC_50_150_pert_mag = lmer(MGL_AUC_50_150 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_50_150_pert_mag)
summary(MGL_AUC_50_150_pert_mag)
emmeans(MGL_AUC_50_150_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_50_150_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_50_150) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("MGL_AUC_50_150_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_50_150) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("MGL_AUC_50_150_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_50_150) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("MGL_AUC_50_150_vs_pert_mag.txt")
summary(MGL_AUC_50_150_pert_mag)
emmeans(MGL_AUC_50_150_pert_mag,pairwise~mag)
sink()

# ANOVA
MGL_AUC_50_150_pert_mag_aov_car = aov_car(MGL_AUC_50_150 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(MGL_AUC_50_150_pert_mag_aov_car$lm$residuals)
qqPlot(MGL_AUC_50_150_pert_mag_aov_car$lm$residuals)
afex_plot(MGL_AUC_50_150_pert_mag_aov_car, x = "mag")
print(MGL_AUC_50_150_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(MGL_AUC_50_150_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_50_150_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_50_150_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("MGL_AUC_50_150_vs_pert_mag_aov_car.txt")
emmeans(MGL_AUC_50_150_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_50_150_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_50_150_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## MGL_AUC_75_200 vs Perturbation Magnitude ####
# MGL
MGL_AUC_75_200_pert_mag = lmer(MGL_AUC_75_200 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_75_200_pert_mag)
summary(MGL_AUC_75_200_pert_mag)
emmeans(MGL_AUC_75_200_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_75_200_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_75_200) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("MGL_AUC_75_200_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_75_200) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("MGL_AUC_75_200_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_75_200) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("MGL_AUC_75_200_vs_pert_mag.txt")
summary(MGL_AUC_75_200_pert_mag)
emmeans(MGL_AUC_75_200_pert_mag,pairwise~mag)
sink()

# ANOVA
MGL_AUC_75_200_pert_mag_aov_car = aov_car(MGL_AUC_75_200 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(MGL_AUC_75_200_pert_mag_aov_car$lm$residuals)
qqPlot(MGL_AUC_75_200_pert_mag_aov_car$lm$residuals)
afex_plot(MGL_AUC_75_200_pert_mag_aov_car, x = "mag")
print(MGL_AUC_75_200_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(MGL_AUC_75_200_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_75_200_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_75_200_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("MGL_AUC_75_200_vs_pert_mag_aov_car.txt")
emmeans(MGL_AUC_75_200_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_75_200_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_75_200_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


## MGL_AUC_150_250 vs Perturbation Magnitude ####
# MGL
MGL_AUC_150_250_pert_mag = lmer(MGL_AUC_150_250 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_150_250_pert_mag)
summary(MGL_AUC_150_250_pert_mag)
emmeans(MGL_AUC_150_250_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_150_250_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_150_250) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("MGL_AUC_150_250_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_150_250) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("MGL_AUC_150_250_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_150_250) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("MGL_AUC_150_250_vs_pert_mag.txt")
summary(MGL_AUC_150_250_pert_mag)
emmeans(MGL_AUC_150_250_pert_mag,pairwise~mag)
sink()

# ANOVA
MGL_AUC_150_250_pert_mag_aov_car = aov_car(MGL_AUC_150_250 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(MGL_AUC_150_250_pert_mag_aov_car$lm$residuals)
qqPlot(MGL_AUC_150_250_pert_mag_aov_car$lm$residuals)
afex_plot(MGL_AUC_150_250_pert_mag_aov_car, x = "mag")
print(MGL_AUC_150_250_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(MGL_AUC_150_250_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_150_250_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_150_250_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("MGL_AUC_150_250_pert_mag_aov_car.txt")
emmeans(MGL_AUC_150_250_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_150_250_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_150_250_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## MGL_AUC_200_300 vs Perturbation Magnitude ####
# MGL
MGL_AUC_200_300_pert_mag = lmer(MGL_AUC_200_300 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_200_300_pert_mag)
summary(MGL_AUC_200_300_pert_mag)
emmeans(MGL_AUC_200_300_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_200_300_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_200_300) + ylim(0, 0.09)+ 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("MGL_AUC_200_300_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_200_300) + ylim(0, 0.09)+ 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("MGL_AUC_200_300_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_200_300) + ylim(0, 0.09)+ 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("MGL_AUC_200_300_vs_pert_mag.txt")
summary(MGL_AUC_200_300_pert_mag)
emmeans(MGL_AUC_200_300_pert_mag,pairwise~mag)
sink()

# ANOVA
MGL_AUC_200_300_pert_mag_aov_car = aov_car(MGL_AUC_200_300 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(MGL_AUC_200_300_pert_mag_aov_car$lm$residuals)
qqPlot(MGL_AUC_200_300_pert_mag_aov_car$lm$residuals)
afex_plot(MGL_AUC_200_300_pert_mag_aov_car, x = "mag")
print(MGL_AUC_200_300_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(MGL_AUC_200_300_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_200_300_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_200_300_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("MGL_AUC_200_300_vs_pert_mag_aov_car.txt")
emmeans(MGL_AUC_200_300_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_200_300_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_200_300_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


## MGL_AUC_250_500 vs Perturbation Magnitude ####
# MGL
MGL_AUC_250_500_pert_mag = lmer(MGL_AUC_250_500 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_250_500_pert_mag)
summary(MGL_AUC_250_500_pert_mag)
emmeans(MGL_AUC_250_500_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_250_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_250_500) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("MGL_AUC_250_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_250_500) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("MGL_AUC_250_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_250_500) + ylim(0, 0.09) + 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("MGL_AUC_250_500_vs_pert_mag.txt")
summary(MGL_AUC_250_500_pert_mag)
emmeans(MGL_AUC_250_500_pert_mag,pairwise~mag)
sink()

# ANOVA
MGL_AUC_250_500_pert_mag_aov_car = aov_car(MGL_AUC_250_500 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(MGL_AUC_250_500_pert_mag_aov_car$lm$residuals)
qqPlot(MGL_AUC_250_500_pert_mag_aov_car$lm$residuals)
afex_plot(MGL_AUC_250_500_pert_mag_aov_car, x = "mag")
print(MGL_AUC_250_500_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(MGL_AUC_250_500_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_250_500_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_250_500_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("MGL_AUC_250_500_pert_mag_aov_car.txt")
emmeans(MGL_AUC_250_500_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_250_500_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_250_500_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## MGL_AUC_300_500 vs Perturbation Magnitude ####
# MGL
MGL_AUC_300_500_pert_mag = lmer(MGL_AUC_300_500 ~ mag + (1|Participant), data = dm)
print(MGL_AUC_300_500_pert_mag)
summary(MGL_AUC_300_500_pert_mag)
emmeans(MGL_AUC_300_500_pert_mag,pairwise~mag)
VarCorr(MGL_AUC_300_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_300_500) + ylim(0, 0.09)+ 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
# save plot
jpeg("MGL_AUC_300_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_300_500) + ylim(0, 0.09)+ 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("MGL_AUC_300_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = MGL_AUC_300_500) + ylim(0, 0.09)+ 
  geom_point() + geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("MGL_AUC_300_500_vs_pert_mag.txt")
summary(MGL_AUC_300_500_pert_mag)
emmeans(MGL_AUC_300_500_pert_mag,pairwise~mag)
sink()

# ANOVA
MGL_AUC_300_500_pert_mag_aov_car = aov_car(MGL_AUC_300_500 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(MGL_AUC_300_500_pert_mag_aov_car$lm$residuals)
qqPlot(MGL_AUC_300_500_pert_mag_aov_car$lm$residuals)
afex_plot(MGL_AUC_300_500_pert_mag_aov_car, x = "mag")
print(MGL_AUC_300_500_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(MGL_AUC_300_500_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_300_500_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_300_500_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("MGL_AUC_300_500_vs_pert_mag_aov_car.txt")
emmeans(MGL_AUC_300_500_pert_mag_aov_car,~mag)
knitr::kable(nice(MGL_AUC_300_500_pert_mag_aov_car))
pairs(emmeans(MGL_AUC_300_500_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()


## TAL_AUC vs Perturbation Magnitude ####
# TAL
TAL_AUC_pert_mag = lmer(TAL_AUC ~ mag + (1|Participant), data = dm)
print(TAL_AUC_pert_mag)
summary(TAL_AUC_pert_mag)
emmeans(TAL_AUC_pert_mag,pairwise~mag)
VarCorr(TAL_AUC_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("TAL_AUC_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("TAL_AUC_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("TAL_AUC_vs_pert_mag.txt")
summary(TAL_AUC_pert_mag)
emmeans(TAL_AUC_pert_mag,pairwise~mag)
sink()

## TAL_AUC_0_500 vs Perturbation Magnitude ####
# TAL
TAL_AUC_0_500_pert_mag = lmer(TAL_AUC_0_500 ~ mag + (1|Participant), data = dm)
print(TAL_AUC_0_500_pert_mag)
summary(TAL_AUC_0_500_pert_mag)
emmeans(TAL_AUC_0_500_pert_mag,pairwise~mag)
VarCorr(TAL_AUC_0_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("TAL_AUC_0_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("TAL_AUC_0_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_0_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("TAL_AUC_0_500_vs_pert_mag.txt")
summary(TAL_AUC_0_500_pert_mag)
emmeans(TAL_AUC_0_500_pert_mag,pairwise~mag)
sink()

## TAL_AUC_50_150 vs Perturbation Magnitude ####
# TAL
TAL_AUC_50_150_pert_mag = lmer(TAL_AUC_50_150 ~ mag + (1|Participant), data = dm)
print(TAL_AUC_50_150_pert_mag)
summary(TAL_AUC_50_150_pert_mag)
emmeans(TAL_AUC_50_150_pert_mag,pairwise~mag)
VarCorr(TAL_AUC_50_150_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_50_150) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("TAL_AUC_50_150_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_50_150) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("TAL_AUC_50_150_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_50_150) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("TAL_AUC_50_150_vs_pert_mag.txt")
summary(TAL_AUC_50_150_pert_mag)
emmeans(TAL_AUC_50_150_pert_mag,pairwise~mag)
sink()

## TAL_AUC_150_250 vs Perturbation Magnitude ####
# TAL
TAL_AUC_150_250_pert_mag = lmer(TAL_AUC_150_250 ~ mag + (1|Participant), data = dm)
print(TAL_AUC_150_250_pert_mag)
summary(TAL_AUC_150_250_pert_mag)
emmeans(TAL_AUC_150_250_pert_mag,pairwise~mag)
VarCorr(TAL_AUC_150_250_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_150_250) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("TAL_AUC_150_250_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_150_250) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("TAL_AUC_150_250_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_150_250) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("TAL_AUC_150_250_vs_pert_mag.txt")
summary(TAL_AUC_150_250_pert_mag)
emmeans(TAL_AUC_150_250_pert_mag,pairwise~mag)
sink()

## TAL_AUC_250_500 vs Perturbation Magnitude ####
# TAL
TAL_AUC_250_500_pert_mag = lmer(TAL_AUC_250_500 ~ mag + (1|Participant), data = dm)
print(TAL_AUC_250_500_pert_mag)
summary(TAL_AUC_250_500_pert_mag)
emmeans(TAL_AUC_250_500_pert_mag,pairwise~mag)
VarCorr(TAL_AUC_250_500_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_250_500) #+ geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("TAL_AUC_250_500_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_250_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("TAL_AUC_250_500_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = TAL_AUC_250_500) #+ geom_point(aes(color = Participant, size = 10))
dev.off()
sink("TAL_AUC_250_500_vs_pert_mag.txt")
summary(TAL_AUC_250_500_pert_mag)
emmeans(TAL_AUC_250_500_pert_mag,pairwise~mag)
sink()


## N1 Amp vs beta_0_500 ####
# Residual
N1_amp_beta_0_500 = lmer(N1_amp ~ beta_0_500*mag + (1|Participant), data = dm)
print(N1_amp_beta_0_500)
summary(N1_amp_beta_0_500)
emmeans(N1_amp_beta_0_500,pairwise~mag)
VarCorr(N1_amp_beta_0_500)
tmp = summary(N1_amp_beta_0_500)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = beta_0_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_beta_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_0_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_beta_0_500.pdf")
ggplot(dm) + aes(x = beta_0_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_beta_0_500.txt")
summary(N1_amp_beta_0_500)
emmeans(N1_amp_beta_0_500,pairwise~mag)
sink()

## N1 Amp vs beta_50_150 ####
# Residual
N1_amp_beta_50_150 = lmer(N1_amp ~ beta_50_150*mag + (1|Participant), data = dm)
print(N1_amp_beta_50_150)
summary(N1_amp_beta_50_150)
emmeans(N1_amp_beta_50_150,pairwise~mag)
VarCorr(N1_amp_beta_50_150)
tmp = summary(N1_amp_beta_50_150)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = beta_50_150, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_beta_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_50_150, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_beta_50_150.pdf")
ggplot(dm) + aes(x = beta_50_150, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_beta_50_150.txt")
summary(N1_amp_beta_50_150)
emmeans(N1_amp_beta_50_150,pairwise~mag)
sink()

## N1 Amp vs beta_150_250 ####
# Residual
N1_amp_beta_150_250 = lmer(N1_amp ~ beta_150_250*mag + (1|Participant), data = dm)
print(N1_amp_beta_150_250)
summary(N1_amp_beta_150_250)
emmeans(N1_amp_beta_150_250,pairwise~mag)
VarCorr(N1_amp_beta_150_250)
tmp = summary(N1_amp_beta_150_250)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = beta_150_250, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_beta_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_150_250, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_beta_150_250.pdf")
ggplot(dm) + aes(x = beta_150_250, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_beta_150_250.txt")
summary(N1_amp_beta_150_250)
emmeans(N1_amp_beta_150_250,pairwise~mag)
sink()

## N1 Amp vs beta_250_500 ####
# Residual
N1_amp_beta_250_500 = lmer(N1_amp ~ beta_250_500*mag + (1|Participant), data = dm)
print(N1_amp_beta_250_500)
summary(N1_amp_beta_250_500)
emmeans(N1_amp_beta_250_500,pairwise~mag)
VarCorr(N1_amp_beta_250_500)
tmp = summary(N1_amp_beta_250_500)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = beta_250_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_beta_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = beta_250_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_beta_250_500.pdf")
ggplot(dm) + aes(x = beta_250_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_beta_250_500.txt")
summary(N1_amp_beta_250_500)
emmeans(N1_amp_beta_250_500,pairwise~mag)
sink()



## N1 Amp vs Beta_AUC ####
# Residual
N1_amp_Beta_AUC = lmer(N1_amp ~ Beta_AUC*mag + (1|Participant), data = dm)
print(N1_amp_Beta_AUC)
summary(N1_amp_Beta_AUC)
emmeans(N1_amp_Beta_AUC,pairwise~mag)
VarCorr(N1_amp_Beta_AUC)
tmp = summary(N1_amp_Beta_AUC)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = Beta_AUC, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_Beta_AUC.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_Beta_AUC.pdf")
ggplot(dm) + aes(x = Beta_AUC, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_Beta_AUC.txt")
summary(N1_amp_Beta_AUC)
emmeans(N1_amp_Beta_AUC,pairwise~mag)
sink()

## N1 Amp vs Beta_AUC_0_500 ####
# Residual
N1_amp_Beta_AUC_0_500 = lmer(N1_amp ~ Beta_AUC_0_500*mag + (1|Participant), data = dm)
print(N1_amp_Beta_AUC_0_500)
summary(N1_amp_Beta_AUC_0_500)
emmeans(N1_amp_Beta_AUC_0_500,pairwise~mag)
VarCorr(N1_amp_Beta_AUC_0_500)
tmp = summary(N1_amp_Beta_AUC_0_500)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = Beta_AUC_0_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_Beta_AUC_0_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_0_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_Beta_AUC_0_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_0_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_Beta_AUC_0_500.txt")
summary(N1_amp_Beta_AUC_0_500)
emmeans(N1_amp_Beta_AUC_0_500,pairwise~mag)
sink()

## N1 Amp vs Beta_AUC_50_150 ####
# Residual
N1_amp_Beta_AUC_50_150 = lmer(N1_amp ~ Beta_AUC_50_150*mag + (1|Participant), data = dm)
print(N1_amp_Beta_AUC_50_150)
summary(N1_amp_Beta_AUC_50_150)
emmeans(N1_amp_Beta_AUC_50_150,pairwise~mag)
VarCorr(N1_amp_Beta_AUC_50_150)
tmp = summary(N1_amp_Beta_AUC_50_150)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = Beta_AUC_50_150, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_Beta_AUC_50_150.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_50_150, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_Beta_AUC_50_150.pdf")
ggplot(dm) + aes(x = Beta_AUC_50_150, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_Beta_AUC_50_150.txt")
summary(N1_amp_Beta_AUC_50_150)
emmeans(N1_amp_Beta_AUC_50_150,pairwise~mag)
sink()

## N1 Amp vs Beta_AUC_150_250 ####
# Residual
N1_amp_Beta_AUC_150_250 = lmer(N1_amp ~ Beta_AUC_150_250*mag + (1|Participant), data = dm)
print(N1_amp_Beta_AUC_150_250)
summary(N1_amp_Beta_AUC_150_250)
emmeans(N1_amp_Beta_AUC_150_250,pairwise~mag)
VarCorr(N1_amp_Beta_AUC_150_250)
tmp = summary(N1_amp_Beta_AUC_150_250)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = Beta_AUC_150_250, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_Beta_AUC_150_250.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_150_250, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_Beta_AUC_150_250.pdf")
ggplot(dm) + aes(x = Beta_AUC_150_250, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_Beta_AUC_150_250.txt")
summary(N1_amp_Beta_AUC_150_250)
emmeans(N1_amp_Beta_AUC_150_250,pairwise~mag)
sink()

## N1 Amp vs Beta_AUC_250_500 ####
# Residual
N1_amp_Beta_AUC_250_500 = lmer(N1_amp ~ Beta_AUC_250_500*mag + (1|Participant), data = dm)
print(N1_amp_Beta_AUC_250_500)
summary(N1_amp_Beta_AUC_250_500)
emmeans(N1_amp_Beta_AUC_250_500,pairwise~mag)
VarCorr(N1_amp_Beta_AUC_250_500)
tmp = summary(N1_amp_Beta_AUC_250_500)
# plot linear model
int = tmp$coefficients[1]
sl = tmp$coefficients[2]
ggplot(dm) + aes(x = Beta_AUC_250_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("N1_amp_vs_Beta_AUC_250_500.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Beta_AUC_250_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("N1_amp_vs_Beta_AUC_250_500.pdf")
ggplot(dm) + aes(x = Beta_AUC_250_500, y = N1_amp) + geom_point(aes(color = mag, size = 5)) + 
  geom_abline(intercept = int,slope = sl) + theme_classic() # + facet_wrap(vars(mag)) + geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("N1_amp_vs_Beta_AUC_250_500.txt")
summary(N1_amp_Beta_AUC_250_500)
emmeans(N1_amp_Beta_AUC_250_500,pairwise~mag)
sink()

## N1_amp vs Perturbation Magnitude ####
N1_amp_pert_mag = lmer(N1_amp ~ mag + (1|Participant), data = dm)
#N1_amp_pert_mag = lmer(N1_amp_150_50 ~ mag + (1|Participant), data = dm)
print(N1_amp_pert_mag)
summary(N1_amp_pert_mag)
emmeans(N1_amp_pert_mag,pairwise~mag)
VarCorr(N1_amp_pert_mag)
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = abs(N1_amp))  + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
#ggplot(dm) + geom_boxplot() + aes(x = mag, y = N1_amp_150_50) # + geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("N1_amp_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = abs(N1_amp))  + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
pdf("N1_amp_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = abs(N1_amp))  + geom_point() + 
  geom_line(aes(group = Participant)) + theme_classic()
dev.off()
sink("N1_amp_vs_pert_mag.txt")
summary(N1_amp_pert_mag)
emmeans(N1_amp_pert_mag,pairwise~mag)
sink()

# ANOVA
N1_amp_pert_mag_aov_car = aov_car(N1_amp ~ mag + Error(Participant/mag), data = dm)
#N1_amp_pert_mag_aov_car = aov_car(N1_amp_150_50 ~ mag + Error(Participant/mag), data = dm)
shapiro.test(N1_amp_pert_mag_aov_car$lm$residuals)
qqPlot(N1_amp_pert_mag_aov_car$lm$residuals)
afex_plot(N1_amp_pert_mag_aov_car, x = "mag")
print(N1_amp_pert_mag_aov_car)
# show group means for different magnitidues regardless of direction
emmeans(N1_amp_pert_mag_aov_car,~mag)
knitr::kable(nice(N1_amp_pert_mag_aov_car))
pairs(emmeans(N1_amp_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("N1_amp_pert_mag_aov_car.txt")
emmeans(N1_amp_pert_mag_aov_car,~mag)
knitr::kable(nice(N1_amp_pert_mag_aov_car))
pairs(emmeans(N1_amp_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

#### N1 Latency vs perturbation magnitude ####
# plot
ggplot(dm) + geom_boxplot() + aes(x = mag, y = N1_latency) # + geom_point(aes(color = Participant, size = 10))
# save plot
jpeg("N1_amp_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = N1_latency) # + geom_point(aes(color = Participant, size = 10))
dev.off()
pdf("N1_amp_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = N1_latency) # + geom_point(aes(color = Participant, size = 10))
dev.off()

N1_latency_pert_mag_aov_car = aov_car(N1_latency ~ mag + Error(Participant/mag), data = dm)
shapiro.test(N1_latency_pert_mag_aov_car$lm$residuals)
qqPlot(N1_latency_pert_mag_aov_car$lm$residuals)
afex_plot(N1_latency_pert_mag_aov_car, x = "mag")
print(N1_latency_pert_mag_aov_car)
# show group means for different magnitudes regardless of direction
emmeans(N1_latency_pert_mag_aov_car,~mag)
knitr::kable(nice(N1_latency_pert_mag_aov_car))
pairs(emmeans(N1_latency_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink("N1_latency_pert_mag_aov_car.txt")
emmeans(N1_latency_pert_mag_aov_car,~mag)
knitr::kable(nice(N1_latency_pert_mag_aov_car))
pairs(emmeans(N1_latency_pert_mag_aov_car,~mag)) #tells whether beta increases between mag 1 -> 2 and 2->3
sink()

## plot cortical recon gain (kBeta, kCz, and ka2) vs pert mag ####
# kbeta
dSRM_beta_kb_pert_mag = lmer(Ag_Gains_TotalDual_beta_kb ~ mag + (1|Participant), data = dm)
print(dSRM_beta_kb_pert_mag)
summary(dSRM_beta_kb_pert_mag)
emmeans(dSRM_beta_kb_pert_mag,pairwise~mag)
VarCorr(dSRM_beta_kb_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kb) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("dSRM_beta_kb_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kb) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("dSRM_beta_kb_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_beta_kb) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("dSRM_beta_kb_vs_pert_mag.txt")
summary(dSRM_beta_kb_pert_mag)
emmeans(dSRM_beta_kb_pert_mag,pairwise~mag)
sink()

# kCz
dSRM_Cz_kCz_pert_mag = lmer(Ag_Gains_TotalDual_Cz_kCz ~ mag + (1|Participant), data = dm)
print(dSRM_Cz_kCz_pert_mag)
summary(dSRM_Cz_kCz_pert_mag)
emmeans(dSRM_Cz_kCz_pert_mag,pairwise~mag)
VarCorr(dSRM_Cz_kCz_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kCz) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("dSRM_Cz_kCz_vs_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kCz) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("dSRM_Cz_kCz_vs_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_Cz_kCz) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("dSRM_Cz_kCz_vs_pert_mag.txt")
summary(dSRM_Cz_kCz_pert_mag)
emmeans(dSRM_Cz_kCz_pert_mag,pairwise~mag)
sink()

# ka2
hSRM_ka2_pert_mag = lmer(Ag_Gains_TotalDual_CoM_ka2 ~ mag + (1|Participant), data = dm)
print(hSRM_ka2_pert_mag)
summary(hSRM_ka2_pert_mag)
emmeans(hSRM_ka2_pert_mag,pairwise~mag)
VarCorr(hSRM_ka2_pert_mag)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka2) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
# save plot
jpeg("hSRM_ka2_pert_mag.jpg",width = 450, height = 450)
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka2) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
dev.off()
pdf("hSRM_ka2_pert_mag.pdf")
ggplot(dm) + geom_boxplot() + aes(x = mag, y = Ag_Gains_TotalDual_CoM_ka2) + geom_point(aes(color = Participant, size = 10)) +
  geom_line(aes(group = Participant, color = Participant))
dev.off()
sink("hSRM_ka2_pert_mag.txt")
summary(hSRM_ka2_pert_mag)
emmeans(hSRM_ka2_pert_mag,pairwise~mag)
sink()

## plot dSRM/hSRM recon accuracy vs cortical recon gains (kBeta, kCz, ka2) ####
# dSRM - beta R2
# fit linear model for beta recon
dSRM_beta_R2_kb = lmer(fit_agonist_TotalDual_beta_R2 ~ mag*Ag_Gains_TotalDual_beta_kb + (1|Participant), data = dm)
print(dSRM_beta_R2_kb)
summary(dSRM_beta_R2_kb)
emmeans(dSRM_beta_R2_kb,pairwise~mag)
VarCorr(dSRM_beta_R2_kb)
tmp = summary(dSRM_beta_R2_kb)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Ag_Gains_TotalDual_beta_kb, y = fit_agonist_TotalDual_beta_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_R2_vs_kb.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Ag_Gains_TotalDual_beta_kb, y = fit_agonist_TotalDual_beta_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_R2_vs_kb.pdf")
ggplot(dm) + aes(x = Ag_Gains_TotalDual_beta_kb, y = fit_agonist_TotalDual_beta_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_R2_vs_kb.txt")
summary(dSRM_beta_R2_kb)
emmeans(dSRM_beta_R2_kb,pairwise~mag)
sink()

# dSRM - beta VAF
# fit linear model for beta recon
dSRM_beta_VAF_kb = lmer(fit_agonist_TotalDual_beta_VAF ~ mag*Ag_Gains_TotalDual_beta_kb + (1|Participant), data = dm)
print(dSRM_beta_VAF_kb)
summary(dSRM_beta_VAF_kb)
emmeans(dSRM_beta_VAF_kb,pairwise~mag)
VarCorr(dSRM_beta_VAF_kb)
tmp = summary(dSRM_beta_VAF_kb)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(beta_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Ag_Gains_TotalDual_beta_kb, y = fit_agonist_TotalDual_beta_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_beta_VAF_vs_kb.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Ag_Gains_TotalDual_beta_kb, y = fit_agonist_TotalDual_beta_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_beta_VAF_vs_kb.pdf")
ggplot(dm) + aes(x = Ag_Gains_TotalDual_beta_kb, y = fit_agonist_TotalDual_beta_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_beta_VAF_vs_kb.txt")
summary(dSRM_beta_VAF_kb)
emmeans(dSRM_beta_VAF_kb,pairwise~mag)
sink()




# dSRM - Cz R2
# fit linear model for Cz recon
dSRM_Cz_R2_kCz = lmer(fit_agonist_TotalDual_Cz_R2 ~ mag*Ag_Gains_TotalDual_Cz_kCz + (1|Participant), data = dm)
print(dSRM_Cz_R2_kCz)
summary(dSRM_Cz_R2_kCz)
emmeans(dSRM_Cz_R2_kCz,pairwise~mag)
VarCorr(dSRM_Cz_R2_kCz)
tmp = summary(dSRM_Cz_R2_kCz)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(Cz_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Ag_Gains_TotalDual_Cz_kCz, y = fit_agonist_TotalDual_Cz_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_R2_vs_kCz.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Ag_Gains_TotalDual_Cz_kCz, y = fit_agonist_TotalDual_Cz_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_R2_vs_kCz.pdf")
ggplot(dm) + aes(x = Ag_Gains_TotalDual_Cz_kCz, y = fit_agonist_TotalDual_Cz_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_R2_vs_kCz.txt")
summary(dSRM_Cz_R2_kCz)
emmeans(dSRM_Cz_R2_kCz,pairwise~mag)
sink()

# dSRM - Cz VAF
# fit linear model for Cz recon
dSRM_Cz_VAF_kCz = lmer(fit_agonist_TotalDual_Cz_VAF ~ mag*Ag_Gains_TotalDual_Cz_kCz + (1|Participant), data = dm)
print(dSRM_Cz_VAF_kCz)
summary(dSRM_Cz_VAF_kCz)
emmeans(dSRM_Cz_VAF_kCz,pairwise~mag)
VarCorr(dSRM_Cz_VAF_kCz)
tmp = summary(dSRM_Cz_VAF_kCz)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(Cz_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Ag_Gains_TotalDual_Cz_kCz, y = fit_agonist_TotalDual_Cz_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("dSRM_Cz_VAF_vs_kCz.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Ag_Gains_TotalDual_Cz_kCz, y = fit_agonist_TotalDual_Cz_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("dSRM_Cz_VAF_vs_kCz.pdf")
ggplot(dm) + aes(x = Ag_Gains_TotalDual_Cz_kCz, y = fit_agonist_TotalDual_Cz_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("dSRM_Cz_VAF_vs_kCz.txt")
summary(dSRM_Cz_VAF_kCz)
emmeans(dSRM_Cz_VAF_kCz,pairwise~mag)
sink()




# hSRM - CoM R2
# fit linear model for CoM recon
hSRM_CoM_R2_ka2 = lmer(fit_agonist_TotalDual_CoM_R2 ~ mag*Ag_Gains_TotalDual_CoM_ka2 + (1|Participant), data = dm)
print(hSRM_CoM_R2_ka2)
summary(hSRM_CoM_R2_ka2)
emmeans(hSRM_CoM_R2_ka2,pairwise~mag)
VarCorr(hSRM_CoM_R2_ka2)
tmp = summary(hSRM_CoM_R2_ka2)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(CoM_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Ag_Gains_TotalDual_CoM_ka2, y = fit_agonist_TotalDual_CoM_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("hSRM_CoM_R2_vs_ka2.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Ag_Gains_TotalDual_CoM_ka2, y = fit_agonist_TotalDual_CoM_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("hSRM_CoM_R2_vs_ka2.pdf")
ggplot(dm) + aes(x = Ag_Gains_TotalDual_CoM_ka2, y = fit_agonist_TotalDual_CoM_R2) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("hSRM_CoM_R2_vs_ka2.txt")
summary(hSRM_CoM_R2_ka2)
emmeans(hSRM_CoM_R2_ka2,pairwise~mag)
sink()

# hSRM - CoM VAF
# fit linear model for CoM recon
hSRM_CoM_VAF_ka2 = lmer(fit_agonist_TotalDual_CoM_VAF ~ mag*Ag_Gains_TotalDual_CoM_ka2 + (1|Participant), data = dm)
print(hSRM_CoM_VAF_ka2)
summary(hSRM_CoM_VAF_ka2)
emmeans(hSRM_CoM_VAF_ka2,pairwise~mag)
VarCorr(hSRM_CoM_VAF_ka2)
tmp = summary(hSRM_CoM_VAF_ka2)
# Plot
int = tmp$coefficients[1]             # Regression values taken from summary(CoM_lme)
sl = tmp$coefficients[4]  
ggplot(dm) + aes(x = Ag_Gains_TotalDual_CoM_ka2, y = fit_agonist_TotalDual_CoM_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
# save plot
jpeg("hSRM_CoM_VAF_vs_ka2.jpg",width = 450, height = 450)
ggplot(dm) + aes(x = Ag_Gains_TotalDual_CoM_ka2, y = fit_agonist_TotalDual_CoM_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
pdf("hSRM_CoM_VAF_vs_ka2.pdf")
ggplot(dm) + aes(x = Ag_Gains_TotalDual_CoM_ka2, y = fit_agonist_TotalDual_CoM_VAF) + 
  geom_point(aes(color = mag, size = 10)) + geom_abline(intercept = int,slope = sl) + theme_classic() + ylim(0, 1)
dev.off()
sink("hSRM_CoM_VAF_vs_ka2.txt")
summary(hSRM_CoM_VAF_ka2)
emmeans(hSRM_CoM_VAF_ka2,pairwise~mag)
sink()



