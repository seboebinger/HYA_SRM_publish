%% Creates the average of all like trials for HYA step datasets

function DataAvTable = SRM_AverageLikeTrials(DataTable)
direcs = unique(DataTable.direc);
mags = unique(DataTable.mag);
Participants = unique(DataTable.Participant);

% CoM Variables
cacc = []; cvel = []; cpos_minus = []; cop = [];
% EMG Variables
MGR = []; MGL = []; TAR = []; TAL = []; STR = []; STL = [];
% Normalization variables
TAL_norm_tmp = []; TAR_norm_tmp = [];
MGL_norm_tmp = []; MGR_norm_tmp = [];
STL_norm_tmp = []; STR_norm_tmp = [];
% EEG variables
gamma_0_500 = []; gamma_50_150 = []; gamma_150_250 = []; gamma_250_500 = [];
beta_0_500  = []; beta_50_150  = []; beta_150_250  = []; beta_250_500  = [];
alpha_0_500 = []; alpha_50_150 = []; alpha_150_250 = []; alpha_250_500 = [];
theta_0_500 = []; theta_50_150 = []; theta_150_250 = []; theta_250_500 = [];
gamma_ersp = []; beta_ersp = []; alpha_ersp = []; theta_ersp = [];
gamma_norm_tmp = []; beta_norm_tmp = []; alpha_norm_tmp = []; theta_norm_tmp = [];
Cz = []; N1_amp = []; N1_latency = []; Cz_norm_tmp = [];
% Platform Variables
platAccelx = []; platAccely = []; LFy = []; RFy = []; LFz = []; RFz = [];
% time
atime = []; mtime = []; time = []; time_eeg = [];
% Identifying variables
direc_tmp = [];
mag_tmp = [];
Participant_tmp = [];

for Participant = Participants'
    ind_participant = find(DataTable.Participant == Participant);
    %Normalize EMG for each participant across all conditions
    TAL_norm = max(max(DataTable.TAL(ind_participant,find(DataTable.atime(ind_participant(1),:) > 0 & DataTable.atime(ind_participant(1),:) < 0.2)))); 
    DataTable.TAL(ind_participant,:) = DataTable.TAL(ind_participant,:)./TAL_norm;
    TAL_norm_tmp = [TAL_norm_tmp; TAL_norm*ones(3,1)];
    
    MGL_norm = max(max(DataTable.MGL(ind_participant,find(DataTable.atime(ind_participant(1),:) > 0 & DataTable.atime(ind_participant(1),:) < 0.2))));
    DataTable.MGL(ind_participant,:) = DataTable.MGL(ind_participant,:)./MGL_norm;
    MGL_norm_tmp = [MGL_norm_tmp; MGL_norm*ones(3,1)];
    
    TAR_norm = max(max(DataTable.TAR(ind_participant,find(DataTable.atime(ind_participant(1),:) > 0 & DataTable.atime(ind_participant(1),:) < 0.2))));
    DataTable.TAR(ind_participant,:) = DataTable.TAR(ind_participant,:)./TAR_norm;
    TAR_norm_tmp = [TAR_norm_tmp; TAR_norm*ones(3,1)];
    
    MGR_norm = max(max(DataTable.MGR(ind_participant,find(DataTable.atime(ind_participant(1),:) > 0 & DataTable.atime(ind_participant(1),:) < 0.2)))); 
    DataTable.MGR(ind_participant,:) = DataTable.MGR(ind_participant,:)./MGR_norm;
    MGR_norm_tmp = [MGR_norm_tmp; MGR_norm*ones(3,1)];
    
    STR_norm = max(max(DataTable.STR(ind_participant,find(DataTable.atime(ind_participant(1),:) > 0 & DataTable.atime(ind_participant(1),:) < 0.2))));
    DataTable.STR(ind_participant,:) = DataTable.STR(ind_participant,:)./STR_norm;
    STR_norm_tmp = [STR_norm_tmp; STR_norm*ones(3,1)];
    
    STL_norm = max(max(DataTable.STL(ind_participant,find(DataTable.atime(ind_participant(1),:) > 0 & DataTable.atime(ind_participant(1),:) < 0.2)))); 
    DataTable.STL(ind_participant,:) = DataTable.STL(ind_participant,:)./STL_norm;
    STL_norm_tmp = [STL_norm_tmp; STL_norm*ones(3,1)];
    
    %Normalize EEG across all conditions
    gamma_norm = max(max(DataTable.gamma_ersp(ind_participant,find(DataTable.time(ind_participant(1),:) > 0 & DataTable.time(ind_participant(1),:) < 200)))); 
    DataTable.gamma_ersp(ind_participant,:) = DataTable.gamma_ersp(ind_participant,:)./gamma_norm;
    gamma_norm_tmp = [gamma_norm_tmp; gamma_norm*ones(3,1)];
    
    beta_norm = max(max(DataTable.beta_ersp(ind_participant,find(DataTable.time(ind_participant(1),:) > 0 & DataTable.time(ind_participant(1),:) < 200)))); 
    DataTable.beta_ersp(ind_participant,:) = DataTable.beta_ersp(ind_participant,:)./beta_norm;
    beta_norm_tmp = [beta_norm_tmp; beta_norm*ones(3,1)];
    
    alpha_norm = max(max(DataTable.alpha_ersp(ind_participant,find(DataTable.time(ind_participant(1),:) > 0 & DataTable.time(ind_participant(1),:) < 200)))); 
    DataTable.alpha_ersp(ind_participant,:) = DataTable.alpha_ersp(ind_participant,:)./alpha_norm;
    alpha_norm_tmp = [alpha_norm_tmp; alpha_norm*ones(3,1)];
    
    theta_norm = max(max(DataTable.theta_ersp(ind_participant,find(DataTable.time(ind_participant(1),:) > 0 & DataTable.time(ind_participant(1),:) < 200)))); 
    DataTable.theta_ersp(ind_participant,:) = DataTable.theta_ersp(ind_participant,:)./theta_norm;
    theta_norm_tmp = [theta_norm_tmp; theta_norm*ones(3,1)];
    
    Cz_norm = abs(min(min(DataTable.Cz(ind_participant,find(DataTable.time_eeg(ind_participant(1),:) > 0 & DataTable.time_eeg(ind_participant(1),:) < 500))))); 
    DataTable.Cz(ind_participant,:) = DataTable.Cz(ind_participant,:)./Cz_norm;
    Cz_norm_tmp = [Cz_norm_tmp; Cz_norm*ones(3,1)];
    
    
    for direction = direcs'
        for magnitude = mags'
            ind_trials = find(DataTable.Participant == Participant & DataTable.direc == direction...
                & DataTable.mag == magnitude & DataTable.step == 0);
            if isempty(ind_trials) % Put NaNs if no trials for given condition
                %average CoM kinematics across like trials
                atime_NaN = nan(size(DataTable.atime(1,:)));
                cacc = [cacc; atime_NaN]; cop = [cop; atime_NaN];
                cvel = [cvel; atime_NaN]; cpos_minus = [cpos_minus; atime_NaN];
                
                %Average EEG across like trials
                gamma_0_500 =   [gamma_0_500;   NaN]; gamma_50_150 =  [gamma_50_150;  NaN]; gamma_150_250 = [gamma_150_250; NaN]; gamma_250_500 = [gamma_250_500; NaN];
                beta_0_500  =   [beta_0_500;    NaN]; beta_50_150  =  [beta_50_150;   NaN]; beta_150_250  = [beta_150_250;  NaN]; beta_250_500  = [beta_250_500;  NaN];
                alpha_0_500 =   [alpha_0_500;   NaN]; alpha_50_150 =  [alpha_50_150;  NaN]; alpha_150_250 = [alpha_150_250; NaN]; alpha_250_500 = [alpha_250_500; NaN];
                theta_0_500 =   [theta_0_500;   NaN]; theta_50_150 =  [theta_50_150;  NaN]; theta_150_250 = [theta_150_250; NaN]; theta_250_500 = [theta_250_500; NaN];
                gamma_ersp = [gamma_ersp; atime_NaN]; beta_ersp =  [beta_ersp;  atime_NaN];
                alpha_ersp = [alpha_ersp; atime_NaN]; theta_ersp = [theta_ersp; atime_NaN];
                N1_amp = [N1_amp; NaN]; N1_latency = [N1_latency; NaN]; Cz = [Cz; atime_NaN];
                
                %Average EMG across like trials
                MGR = [MGR; atime_NaN]; MGL = [MGL; atime_NaN]; TAR = [TAR; atime_NaN]; TAL = [TAL; atime_NaN];
                STR = [STR; atime_NaN]; STL = [STL; atime_NaN];
                %Average force plate
                LFz = [LFz; atime_NaN]; RFz = [RFz; atime_NaN]; LFy = [LFy; atime_NaN]; RFy = [RFy; atime_NaN];
                
                %Average platform acceleration
                platAccelx = [platAccelx; atime_NaN]; platAccely = [platAccely; atime_NaN];
                
            elseif length(ind_trials) == 1 % Don't average if only 1 trial per condition
                %average CoM kinematics across like trials
                cacc = [cacc; DataTable.cacc(ind_trials,:)]; %Average CoM acceleration
                cvel_tmp = DataTable.cvel(ind_trials,:); %Average CoM velocity
                cposminus_tmp = DataTable.cposminus(ind_trials,:); %Average CoM displacement
                cop = [cop; DataTable.cop(ind_trials,:)];
                
                %interpolate CoM vel and disp to be same size as acceleration
                cvel = [cvel; interp1(DataTable.mtime(1,:),cvel_tmp,DataTable.atime(1,:))];
                cpos_minus = [cpos_minus; interp1(DataTable.mtime(1,:),cposminus_tmp,DataTable.atime(1,:))];
                clear cvel_tmp cposminus_tmp
                
                %EEG across like trials
                gamma_0_500 =   [gamma_0_500;   DataTable.gamma_0_500(ind_trials,:)];
                gamma_50_150 =  [gamma_50_150;  DataTable.gamma_50_150(ind_trials,:)];
                gamma_150_250 = [gamma_150_250; DataTable.gamma_150_250(ind_trials,:)];
                gamma_250_500 = [gamma_250_500; DataTable.gamma_250_500(ind_trials,:)];
                beta_0_500  =   [beta_0_500;    DataTable.beta_0_500(ind_trials,:)];
                beta_50_150  =  [beta_50_150;   DataTable.beta_50_150(ind_trials,:)];
                beta_150_250  = [beta_150_250;  DataTable.beta_150_250(ind_trials,:)];
                beta_250_500  = [beta_250_500;  DataTable.beta_250_500(ind_trials,:)];
                alpha_0_500 =   [alpha_0_500;   DataTable.alpha_0_500(ind_trials,:)];
                alpha_50_150 =  [alpha_50_150;  DataTable.alpha_50_150(ind_trials,:)];
                alpha_150_250 = [alpha_150_250; DataTable.alpha_150_250(ind_trials,:)];
                alpha_250_500 = [alpha_250_500; DataTable.alpha_250_500(ind_trials,:)];
                theta_0_500 =   [theta_0_500;   DataTable.theta_0_500(ind_trials,:)];
                theta_50_150 =  [theta_50_150;  DataTable.theta_50_150(ind_trials,:)];
                theta_150_250 = [theta_150_250; DataTable.theta_150_250(ind_trials,:)];
                theta_250_500 = [theta_250_500; DataTable.theta_250_500(ind_trials,:)];
                N1_amp = [N1_amp; DataTable.N1_amp(ind_trials,:)]; 
                N1_latency = [N1_latency; DataTable.N1_latency(ind_trials,:)]; 
                                
                gamma_ersp_tmp = DataTable.gamma_ersp(ind_trials,:);
                beta_ersp_tmp =  DataTable.beta_ersp(ind_trials,:);
                alpha_ersp_tmp = DataTable.alpha_ersp(ind_trials,:);
                theta_ersp_tmp = DataTable.theta_ersp(ind_trials,:);
                Cz_tmp = DataTable.Cz(ind_trials,:);
                
                % interpolate ERSPs & Cz
                gamma_ersp = [gamma_ersp; interp1(DataTable.time(1,:)/1000, gamma_ersp_tmp, DataTable.atime(1,:))];
                beta_ersp  = [beta_ersp;  interp1(DataTable.time(1,:)/1000, beta_ersp_tmp,  DataTable.atime(1,:))];
                alpha_ersp = [alpha_ersp; interp1(DataTable.time(1,:)/1000, alpha_ersp_tmp, DataTable.atime(1,:))];
                theta_ersp = [theta_ersp; interp1(DataTable.time(1,:)/1000, theta_ersp_tmp, DataTable.atime(1,:))];
                Cz = [Cz; interp1(DataTable.time_eeg(1,:)/1000, Cz_tmp, DataTable.atime(1,:))];
                
                %Average EMG across like trials
                MGR = [MGR; DataTable.MGR(ind_trials,:)]; MGL = [MGL; DataTable.MGL(ind_trials,:)];
                TAR = [TAR; DataTable.TAR(ind_trials,:)]; TAL = [TAL; DataTable.TAL(ind_trials,:)];
                STR = [STR; DataTable.STR(ind_trials,:)]; STL = [STL; DataTable.STL(ind_trials,:)];
                
                %Average force plate
                LFz = [LFz; DataTable.LFz(ind_trials,:)]; RFz = [RFz; DataTable.RFz(ind_trials,:)];
                LFy = [LFy; DataTable.LFy(ind_trials,:)]; RFy = [RFy; DataTable.RFy(ind_trials,:)];
                
                %Average platform acceleration
                platAccelx = [platAccelx; DataTable.platAccelx(ind_trials,:)];
                platAccely = [platAccely; DataTable.platAccely(ind_trials,:)];

            else
                %average CoM kinematics across like trials
                cacc = [cacc; mean(DataTable.cacc(ind_trials,:),'omitnan')]; %Average CoM acceleration
                cvel_tmp = mean(DataTable.cvel(ind_trials,:),'omitnan'); %Average CoM velocity
                cposminus_tmp = mean(DataTable.cposminus(ind_trials,:),'omitnan'); %Average CoM displacement
                cop = [cop; mean(DataTable.cop(ind_trials,:),'omitnan')];
                
                %interpolate CoM vel and disp to be same size as acceleration
                cvel = [cvel; interp1(DataTable.mtime(1,:),cvel_tmp,DataTable.atime(1,:))];
                cpos_minus = [cpos_minus; interp1(DataTable.mtime(1,:),cposminus_tmp,DataTable.atime(1,:))];
                clear cvel_tmp cposminus_tmp
                
                %Average EEG across like trials
                gamma_0_500 =   [gamma_0_500;   mean(DataTable.gamma_0_500(ind_trials,:),'omitnan')];
                gamma_50_150 =  [gamma_50_150;  mean(DataTable.gamma_50_150(ind_trials,:),'omitnan')];
                gamma_150_250 = [gamma_150_250; mean(DataTable.gamma_150_250(ind_trials,:),'omitnan')];
                gamma_250_500 = [gamma_250_500; mean(DataTable.gamma_250_500(ind_trials,:),'omitnan')];
                beta_0_500  =   [beta_0_500;    mean(DataTable.beta_0_500(ind_trials,:),'omitnan')];
                beta_50_150  =  [beta_50_150;   mean(DataTable.beta_50_150(ind_trials,:),'omitnan')];
                beta_150_250  = [beta_150_250;  mean(DataTable.beta_150_250(ind_trials,:),'omitnan')];
                beta_250_500  = [beta_250_500;  mean(DataTable.beta_250_500(ind_trials,:),'omitnan')];
                alpha_0_500 =   [alpha_0_500;   mean(DataTable.alpha_0_500(ind_trials,:),'omitnan')];
                alpha_50_150 =  [alpha_50_150;  mean(DataTable.alpha_50_150(ind_trials,:),'omitnan')];
                alpha_150_250 = [alpha_150_250; mean(DataTable.alpha_150_250(ind_trials,:),'omitnan')];
                alpha_250_500 = [alpha_250_500; mean(DataTable.alpha_250_500(ind_trials,:),'omitnan')];
                theta_0_500 =   [theta_0_500;   mean(DataTable.theta_0_500(ind_trials,:),'omitnan')];
                theta_50_150 =  [theta_50_150;  mean(DataTable.theta_50_150(ind_trials,:),'omitnan')];
                theta_150_250 = [theta_150_250; mean(DataTable.theta_150_250(ind_trials,:),'omitnan')];
                theta_250_500 = [theta_250_500; mean(DataTable.theta_250_500(ind_trials,:),'omitnan')];
                N1_amp = [N1_amp; mean(DataTable.N1_amp(ind_trials,:),'omitnan')]; 
                N1_latency = [N1_latency; mean(DataTable.N1_latency(ind_trials,:),'omitnan')]; 
                                
                gamma_ersp_tmp = mean(DataTable.gamma_ersp(ind_trials,:),'omitnan');
                beta_ersp_tmp  = mean(DataTable.beta_ersp(ind_trials,:),'omitnan');
                alpha_ersp_tmp = mean(DataTable.alpha_ersp(ind_trials,:),'omitnan');
                theta_ersp_tmp = mean(DataTable.theta_ersp(ind_trials,:),'omitnan');
                Cz_tmp = mean(DataTable.Cz(ind_trials,:),'omitnan');
                
                % interpolate ERSPs
                gamma_ersp = [gamma_ersp; interp1(DataTable.time(1,:)/1000, gamma_ersp_tmp, DataTable.atime(1,:))];
                beta_ersp  = [beta_ersp;  interp1(DataTable.time(1,:)/1000, beta_ersp_tmp,  DataTable.atime(1,:))];
                alpha_ersp = [alpha_ersp; interp1(DataTable.time(1,:)/1000, alpha_ersp_tmp, DataTable.atime(1,:))];
                theta_ersp = [theta_ersp; interp1(DataTable.time(1,:)/1000, theta_ersp_tmp, DataTable.atime(1,:))];
                Cz = [Cz; interp1(DataTable.time_eeg(1,:)/1000, Cz_tmp, DataTable.atime(1,:))];
                
                %Average EMG across like trials
                MGR = [MGR; mean(DataTable.MGR(ind_trials,:),'omitnan')];
                MGL = [MGL; mean(DataTable.MGL(ind_trials,:),'omitnan')];
                TAR = [TAR; mean(DataTable.TAR(ind_trials,:),'omitnan')];
                TAL = [TAL; mean(DataTable.TAL(ind_trials,:),'omitnan')];
                STR = [STR; mean(DataTable.STR(ind_trials,:),'omitnan')];
                STL = [STL; mean(DataTable.STL(ind_trials,:),'omitnan')];
                
                %Average force plate
                LFz = [LFz; mean(DataTable.LFz(ind_trials,:),'omitnan')];
                RFz = [RFz; mean(DataTable.RFz(ind_trials,:),'omitnan')];
                LFy = [LFy; mean(DataTable.LFy(ind_trials,:),'omitnan')];
                RFy = [RFy; mean(DataTable.RFy(ind_trials,:),'omitnan')];
                
                %Average platform acceleration
                platAccelx = [platAccelx; mean(DataTable.platAccelx(ind_trials,:),'omitnan')];
                platAccely = [platAccely; mean(DataTable.platAccely(ind_trials,:),'omitnan')];
            end
            
            direc_tmp = [direc_tmp; direction];
            mag_tmp = [mag_tmp; magnitude];
            Participant_tmp = [Participant_tmp; Participant];
            atime = [atime; DataTable.atime(1,:)]; 
            mtime = [mtime; DataTable.mtime(1,:)];
            time = [time; DataTable.time(1,:)];
            time_eeg = [time_eeg;DataTable.time_eeg(1,:)];
            
        end
    end
end
%% create data table 
DataAvTable = table(Participant_tmp, mag_tmp, direc_tmp,...
    gamma_0_500, gamma_50_150, gamma_150_250, gamma_250_500,...
    beta_0_500 , beta_50_150 , beta_150_250 , beta_250_500,...
    alpha_0_500, alpha_50_150, alpha_150_250, alpha_250_500,...
    theta_0_500, theta_50_150, theta_150_250, theta_250_500,...
    gamma_ersp, beta_ersp, alpha_ersp, theta_ersp,...
    gamma_norm_tmp, beta_norm_tmp, alpha_norm_tmp, theta_norm_tmp,...
    cacc, cvel, cpos_minus, cop, MGR, MGL, TAR, TAL, STR, STL,...
    TAL_norm_tmp, TAR_norm_tmp, MGL_norm_tmp, MGR_norm_tmp, STL_norm_tmp, STR_norm_tmp,...
    platAccelx, platAccely, LFy, RFy, LFz, RFz, atime, mtime, time, Cz, Cz_norm_tmp, N1_amp, N1_latency, time_eeg,...
    'VariableNames', {'Participant', 'mag', 'direc',...
    'gamma_0_500', 'gamma_50_150', 'gamma_150_250', 'gamma_250_500',...
    'beta_0_500', 'beta_50_150', 'beta_150_250', 'beta_250_500',...
    'alpha_0_500', 'alpha_50_150', 'alpha_150_250', 'alpha_250_500',...
    'theta_0_500', 'theta_50_150', 'theta_150_250', 'theta_250_500',...
    'gamma_ersp', 'beta_ersp', 'alpha_ersp', 'theta_ersp',...
    'gamma_norm', 'beta_norm', 'alpha_norm', 'theta_norm',...
    'cacc', 'cvel', 'cpos_minus', 'cop', 'MGR', 'MGL', 'TAR', 'TAL', 'STR', 'STL',...
    'TAL_norm', 'TAR_norm', 'MGL_norm', 'MGR_norm', 'STL_norm', 'STR_norm',...
    'platAccelx', 'platAccely', 'LFy', 'RFy', 'LFz', 'RFz', 'atime', 'mtime', 'time','Cz', 'Cz_norm', 'N1_amp', 'N1_latency', 'time_eeg'});
end