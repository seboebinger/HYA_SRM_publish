function strmat = table2text(t,Nvars)

strfmt = '%06.3f';

Nrows = size(t,1);
if nargin<2
    Nvars = size(t,2);
end
    
strmat = [];
for i = 1:Nrows
    str = [];
    for j = 1:Nvars
        varstr = t.Properties.VariableNames{j};
        str = [str ' ' varstr ' = ' num2str(t{i,j},strfmt) ' '];
    end
    strmat = strvcat(strmat,str);
end

end