function macopen(fname)
% change spaces to "\ "
fname2 = strrep(string(fname)," ","\ ");
system("open "+fname2);
end
