function h = rightscale(ht)
yl=get(gca,'ylim');
xl=get(gca,'xlim');
if nargin==0
    ht = yl(2)-yl(1);
end

a = line(xl(2)*[1 1],yl(2)+[0 -ht]);
set(a,'color','k','linewidth',0.5);
b = text(xl(2),yl(2)+[-ht/2],num2str(ht));
set(b,'horizontalalignment','left','verticalalignment','middle');
set(b,'fontsize',8,'color','k');

if nargout
h = [a b];
end
end