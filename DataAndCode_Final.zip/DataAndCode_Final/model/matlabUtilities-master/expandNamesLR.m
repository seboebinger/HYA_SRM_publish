function out = expandNamesLR(in)
% function out = expandNamesLR(in)
% 
% append _L _R to a list of strings

in = in(:)';
out = [in' + "_L" in' + "_R"];
out = out';
out = out(:)';

end
