function out = project_onto_perturbation_direction(pertdir_deg,in_x,in_y)
% function out = project_onto_perturbation_direction(pertdir_deg,in_x,in_y)
% 
% finds projection onto perturbation direction of an x, y vector.
% 
% uses a rotation matrix assuming the coordinate frame has been rotated by
% pertdir_deg degrees.
% 
% see http://mathworld.wolfram.com/RotationMatrix.html, bottom half of the
% page, for reference.
% 
% function [x_new, y_new] = project_onto_perturbation_direction(pertdir_deg,in_x,in_y)
% second output argument provides the component perpendicular to the
% perturbation direction. 
% 
% J. Lucas McKay
% Jan 2, 2015

data = [in_x(:)'; in_y(:)'];
R = [cosd(pertdir_deg) sind(pertdir_deg); -sind(pertdir_deg) cosd(pertdir_deg)];

rotateddata = R*data;

if nargout==1
    out = rotateddata(1,:)';
elseif nargout==2
    x_new = rotateddata(1,:)';
    y_new = rotateddata(2,:)';
end

end