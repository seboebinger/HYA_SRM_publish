function tableOut = averageTable(tableIn,inputVars,matchVar)
% function tableOut = averageTable(tableIn,inputVars,matchVar)
% 
% averages over rows of table and inherits remaining variables. note:
% inherited variables with more than one value for each value of matchVar
% will be matched with the first occurrence.

allVars = string(tableIn.Properties.VariableNames);
otherVars = setdiff(allVars,[matchVar inputVars]);
nInputVars = length(inputVars);
tableOut = varfun(@(in) nanmean(in,1), tableIn,'GroupingVariables',cellstr(matchVar),'InputVariables',cellstr(inputVars));
nTableVars = length(tableOut.Properties.VariableNames);
nOtherVars = length(otherVars);

tableOut.Properties.VariableNames((nTableVars-nInputVars+1):end) = cellstr(inputVars);
tableOut = [tableOut inheritVars(tableOut,tableIn,matchVar,otherVars)];

end
