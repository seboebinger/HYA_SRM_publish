function tableOut = inheritVars(subTable,bigTable,matchVar,copyVars)
% function varsOut = inheritVars(subTable,bigTable,matchVar,copyVars)

nRows = size(subTable,1);
nVars = length(copyVars);

varsOut = [];

for v = copyVars
	% make a new column
	switch class(bigTable{:,v})
		case "string"
			newVar = repmat("",nRows,1);
		case "double"
			newVar = nan(nRows,1);
	end
	for nr = 1:nRows
		try
		newVar(nr,:) = bigTable{find(bigTable{:,matchVar}==subTable{nr,matchVar},1,'first'),v};
		catch
			disp(v+": value not found")
		end
	end
	varsOut.(v) = newVar;
end

tableOut = struct2table(varsOut);

end