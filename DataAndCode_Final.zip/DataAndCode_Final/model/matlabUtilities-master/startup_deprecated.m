% startup.m is automatically executed at startup.
cd ~/Research
beep off

set(0,'DefaultAxesNextPlot','add')
set(0,'DefaultFigureColor',[1 1 1])
set(0,'DefaultFigureClipping','off')
set(0,'defaulttextinterpreter','none')

return

set(0,'DefaultAxesLayer','top')

ScreenSize = get(0,'ScreenSize');
% Make the default figure 1/3 the screen size:
% DefaultFigurePosition = floor([686 379 golden_fraction^2*ScreenSize(3) golden_fraction^2*ScreenSize(4)]);
DefaultFigurePosition = [130 525 640 400];
set(0,'DefaultFigurePosition',DefaultFigurePosition)

set(0,'DefaultFigureToolBar','figure')
set(0,'DefaultFigureMenuBar','figure')


% % Hide the start menu
% 
% com.mathworks.mde.desk.MLDesktop.getInstance.getMainFrame.getStatusBar.getParent.setVisible(1);

try
	% Get the handle to the desktop
	desktop = com.mathworks.mde.desk.MLDesktop.getInstance;
	editor = desktop.getGroupContainer('Editor').getTopLevelAncestor;
	desktop.getMainFrame.getStatusBar.getParent.setVisible(0);
	editor.getStatusBar.getParent.setVisible(0);
catch
end

% set(0,'DefaultFigureToolBar','none')
set(0,'DefaultFigureToolBar','figure')
% set(0,'DefaultFigureMenuBar','none')
set(0,'DefaultFigureMenuBar','figure')
set(0,'DefaultFigureColor',[1 1 1])


% Default resolution is 150 dpi; therfore, pick a figure size that reflects
% this.
% set(0,'DefaultFigureUnits','inches');
% set(0,'DefaultFigurePosition',[9 5.75 5 4])
% Screen Size is specified in pixels indexed from the bottom left corner:
% [left bottom width height]

% Gelsy's color map:
GTO_Colors =[...
	1.0000         0    0.1306
    1.0000    0.7143         0
    0.6230    1.0000    0.5393
    0.2242    0.7455    1.0000
    1.0000    0.4029    0.6691];

JLM_Colors = [...
    0 0 0;
	0 1 1; ...
	1 0 1; ...
	0.5 1 0; ...
	0.302 0.302 1; ...
	1.0 0.4314 0.7804];

LBMAP_Colors = lbmap(5,'brownblue');

LineStyleOrder={'-','--','-.'};
LineStyleOrder={'-'};
set(0,'DefaultAxesColorOrder',JLM_Colors)
% set(0,'DefaultAxesColorOrder',LBMAP_Colors)
set(0,'DefaultAxesTickDir','out')
set(0,'DefaultAxesLineStyleOrder',LineStyleOrder)
set(0,'DefaultAxesLineWidth',1)
% set(0,'DefaultAxesNextPlot','replace')
set(0,'DefaultAxesNextPlot','add')
set(0,'DefaultAxesLayer','top')

% If you'd like to increase the figure fonts, for direct export:
% set(0,'DefaultAxesFontName','Century Gothic')
% set(0,'DefaultAxesFontSize',14)

% % Set the following environment variables to match the grid computations:
% setenv('JOB_ID','0');
% setenv('SGE_TASK_ID','0');
% PATH=getenv('PATH');
% setenv('PATH',['.:~/Scripts:' PATH])
% disp('Variables JOB_ID, SGE_TASK_ID, PATH modified in')
% disp(' ')
% disp([mfilename('fullpath') '.m'])
% disp(' ')

% addpath('~/Research/Cluster Home/matlab/Coordination/functions')
% addpath('~/Research/Cluster Home/matlab/Datasets/')
% addpath('~/Research/Cluster Home/matlab/FastICA_25/')
% 
% try
% 	% Get your external IP address to talk to the cluster:
% 	MyExternalIP=urlread('http://ip.dustin.li/');
% 	pctconfig('hostname',MyExternalIP)
% catch
% end

beep off

clear

cd ~/Research/

