% ca.m
% 
% calls "close all"
close all