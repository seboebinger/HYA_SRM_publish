function [] = xtick(ticks,tickstolabel)
% function [] = xtick(ticks,tickstolabel)
% 
% xtick([0:.1:1],1:10) labels at 1 and 10 and ticks from 1 to 10. behavior is
% undefined if majorticks is not within minorticks.

if isempty(minorticks)
    set(gca,'xtick',majorticks);
else
    % note that numerical comparisons of tick values are sensitive at
    % numerical precision, so logical comparisons like ismember will not
    % work in a deterministic behavior. it's really annoying. (see below)
    ticks = union(majorticks,minorticks);
    labels = num2str(ticks(:));
    
    [c,imajor,iminor] = setxor(majorticks,ticks);
    
    labels(~ismember(minorticks,majorticks),:) = ' ';
    set(gca,'xtick',ticks,'xticklabel',labels)
end

end



 
% % logicerror.m
% % 
% % J. Lucas McKay, Ph.D.
% % 
% % 15 November 2013
% 
% XTL = [0:0.2:1];
% 
% XT = [-0.2:0.1:1.4];
% 
% XTL(3)
% % ans =
% %     0.4000
% 
% XT(7)
% % ans =
% %     0.4000
% 
% XT(7) - XTL(3)
% % ans =
% %    5.5511e-17
% 
% (XT(7)-XTL(3))==0
% % ans =
% %      0
% 
% (0.4000-0.4000)==0
% 
% 
% 
% XTL = [0:0.2:1];
% 
% XT = [-0.2:0.1:1.4];
% 
% XTL(3)
% % ans =
% %     0.4000
% 
% XT(7)
% % ans =
% %     0.4000
% 
% XT(7) - XTL(3)
% % ans =
% %    5.5511e-17
% 
% (XT(7)-XTL(3))==0
% % ans =
% %      0
% 
% % However
% 0.4==0.4
% % ans =
% %      1
% 
% % And
% XT(3) - XTL(1)
% % ans =
% %      0
% 
% (XT(3)-XTL(1))==0
% % ans =
%      1
