function out = removeNamesLR(in)
% function out = removeNamesLR(in)
% 
% remove _L _R from a list of strings

in = in(:)';
in(endsWith(in,"_L")) = strrep(in(endsWith(in,"_L")),"_L","");
in(endsWith(in,"_R")) = strrep(in(endsWith(in,"_R")),"_R","");

patterns = ["_L$" "_R$"];

BROOOOKEN

for p = 1:length(patterns)
	regexp(in,patterns(p))
end


out = string;
for i = 1:length(in)
	if ~isempty(regexp(in(i),"_L$"))|~isempty(regexp(in(i),"_R$"))
		char(in(i))		
	else
		out(i) = in(i);
	end
end


		
out = [in' + "_L" in' + "_R"];
out = out';
out = out(:)';

end
