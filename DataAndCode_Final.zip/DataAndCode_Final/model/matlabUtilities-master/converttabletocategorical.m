function outtable = converttabletocategorical(intable,varargin)
% outtable = converttabletocategorical(intable,'var1','var2',...)
% 
% outtable = converttabletocategorical(intable,{'var1','var2',...})
% 
% Convert character variables in a table to categorical variables for
% easier indexing.
% 
% J. Lucas McKay
% 30 July 2015

if (length(varargin{1})>1)
    vars = varargin{1};
else
    vars = varargin;
end

% I cannot find a way to do this without resorting to an eval statement.
for i = 1:length(vars)
    eval(['intable.' vars{i} '=categorical(intable.' vars{i} ');']);
end

outtable = intable;

end

