function [mn,sd] = nanmeanNrows(in,N)
% function mn = nanmeanNrows(in,N);
% function [mn,sd] = nanmeanNrows(in,N);
% returns nanstd also

nr1 = size(in,1);
nr2 = floor(nr1/N);
nc = size(in,2);

out_mn = nan(nr2,nc);

for i = 1:nr2
    out_mn(i,:) = nanmean(in(N*(i-1)+(1:N),:),1);
end

mn = out_mn;

if nargout>1
    out_sd = nan(nr2,nc);
    
    for i = 1:nr2
        out_sd(i,:) = nanstd(in(N*(i-1)+(1:N),:),0,1);
    end
    
    sd = out_sd;
end

end