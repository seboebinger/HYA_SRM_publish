function handle = wordfigure(h,width,height,fontsize)
	% function h = wordfigure(h,width,height,fontsize);
	%
	% Opens a new figure with appropriate options for spitting directly
	% into Word.  Increases the font size, changes the shape of the
	% figure to be the appropriate aspect ratio.  The absolute size of the
	% figure is selected so that the appearance (automatic tick labeling,
	% etc.) is similar to that of the rendered figure.  This results in a
	% larger figure, in terms of screen real estate, than I'd like.  Watch
	% out, because the behavior is undefined if you make a figure larger
	% than your screen.  Also, be careful, as the screen "thinks it's
	% larger than" it actually is.
	%
	% The width and height arguments are assumed to be in inches.  Default
	% values are 6 inches wide by 4 inches tall.  fontsize is assumed to be
	% in points.  Default value is 6.
	%
	% Word figures should be printed with wordprint().

	if nargin<4
		fontsize=6;
	end
	
	if nargin<3
		height = 4;
	end
	
	if nargin<2
		width = 6;
	end
	
	if nargin<1
		h = [];
	end
	
	if isempty(h)
		h = figure;
	else
		h = figure(h);
	end

	% Positions of figures are specified as follows:
	% rect = [left, bottom, width, height]
	% Note that the full extent of the figure must be specified with the
	% "OuterPosition" property.
	
	% Note that the ScreenPixelsPerInch argument is a little off on the
	% test computer.
	ScreenSize = get(0,'ScreenSize');
	ScreenPixelsPerInch = get(0,'ScreenPixelsPerInch');
	
	dim = [0 0 0 0];
	dim(3) = floor(width*ScreenPixelsPerInch);
	dim(4) = floor(height*ScreenPixelsPerInch);
	temp = round(.5*(ScreenSize - dim));
	dim([1 2]) = temp([3 4]);
	
	set(h,'Position',dim);
	
	% Jack up the Font Size:
	set(h,'DefaultAxesFontSize',fontsize);
	set(h,'DefaultTextFontSize',fontsize);
	set(h,'DefaultLineMarkerSize',fontsize/2);
	set(h,'DefaultLineLineWidth',1);	
	set(h,'PaperUnits','inches');
	set(h,'PaperOrientation','portrait');
	set(h,'PaperSize',[width height]);
	set(h,'PaperPosition',[0 0 width height]);

	if nargout
		handle = h;
	end
end
