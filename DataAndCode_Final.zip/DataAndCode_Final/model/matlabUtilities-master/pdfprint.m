function [] = pdfprint(handle,filename)
% function [] = pdfprint(handle,filename)

if nargin<2
	filename = [];
end

if nargin<1
	handle = gcf;
elseif isempty(handle)
	handle = gcf;
end

if isempty(filename)
	filename = [filename sprintf('figure%d',handle)];
end

disp(sprintf('Printing Figure %d for Word: Ticks may change.',handle));
% Future change: move through subplots and check if they have been set
% manually.

[pathstr,name,ext] = fileparts(filename);

if isempty(pathstr)
	printname = name;
else
	printname = [pathstr filesep name];
end

print(['-f' num2str(handle)],'-loose','-depsc2',[printname '.eps']);
eval(['!open ' printname '.eps'])