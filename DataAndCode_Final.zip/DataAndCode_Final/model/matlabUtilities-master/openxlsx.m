function [] = openxlsx(fname)

eval("!open " + strrep(fname," ","\ "))

end