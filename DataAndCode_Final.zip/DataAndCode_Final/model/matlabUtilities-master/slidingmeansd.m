function [mn sd] = slidingmeansd(EMG_temp,windowwidth)
% function [mn sd] = slidingmeansd(data,windowwidth)
% 
% Calculate a moving average of the given data (a column vector) over
% windowwidth points. for 1080 Hz data, windowwidth for a 100 ms window is,
% for example, round(0.100*1080) = 108.
% 
% Note that this method symmetrically extends the data at the edges to
% reduce error. Less fancy methods just pad with zeros- this means that the
% mean goes to 0 at the start of the record!
% 
% J. Lucas McKay, Ph.D.
% 3 December, 2013

EMG_len = length(EMG_temp);
EMG_temp_ext = EMG_temp([windowwidth:-1:1 1:EMG_len EMG_len:-1:EMG_len-(windowwidth-1)]);

mnslide = nlfilter(EMG_temp_ext, [windowwidth 1], @nanmean);
sdslide = nlfilter(EMG_temp_ext, [windowwidth 1], @nanstd);

mn = mnslide(windowwidth+1:windowwidth+EMG_len);
sd = sdslide(windowwidth+1:windowwidth+EMG_len);

end
