function limits = getsubplotlimits(handle)

ax = flipud(findall(handle,'type','axes'));
XL = nan(length(ax),2);
YL = nan(length(ax),2);

for i = 1:length(ax)
    XL(i,:) = ax(i).XLim;
    YL(i,:) = ax(i).YLim;
end

limits = { ...
    XL ...
    repmat([min(XL(:,1)) max(XL(:,2))],length(ax),1) ...
    repmat([max(XL(:,1)) min(XL(:,2))],length(ax),1);
    YL ...
    repmat([min(YL(:,1)) max(YL(:,2))],length(ax),1) ...
    repmat([max(YL(:,1)) min(YL(:,2))],length(ax),1) ...
    };

limits = cell2table(limits);
limits.Properties.VariableNames = {'current' 'max' 'min'};
limits.Properties.RowNames = {'XLim' 'YLim'};

end