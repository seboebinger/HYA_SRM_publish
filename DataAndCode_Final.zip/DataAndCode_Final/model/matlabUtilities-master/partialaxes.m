function [] = partialaxes(XL,xticks,xticklabels,YL,yticks,yticklabels)
% function [] = partialaxes(xlim,xticks,xticklabels,ylim,yticks,yticklabels)
% 
% xlim is like [-5 5]
% 
% an axis is plotted from the minimum xtick value to the maximum xtick
% value.
% 
% ticks are placed at the locations xticks, labels are placed at
% xticklabels
% 
% axis labels are copied and reapplied. however, the x ticks are no longer
% settable by "xtick" or other commands.
% 
% future release will have text labels possible.

hold on
set(gcf,'color',[1 1 1]);
set(gca,'xlim',XL,'ylim',YL);

% turn off axes, but retain labels.
xlabh = get(gca,'xlabel');
ylabh = get(gca,'ylabel');
axis off
set(xlabh,'visible','on');
set(ylabh,'visible','on');

% measure tick length
ticklength = get(gca,'ticklength'); ticklength(2) = [];
ticklength = 3*ticklength;

% get the axis position (L B W H)
axpos = get(gca,'position');

% length of ticks to draw in the y-direction. these are in y-data units and
% will be along the x axis.
ticklength_alongy = ticklength*diff(YL);

% length of ticks to draw in the x-direction. these are in x-data units.
ticklength_alongx = ticklength_alongy*(axpos(4)/diff(YL))*(diff(XL)/axpos(3));

xax = line([min(xticks) max(xticks)],YL(1)*[1 1],'clipping','off','color',[0 0 0]);
yax = line(XL(1)*[1 1],[min(yticks) max(yticks)],'clipping','off','color',[0 0 0]);

% loop through and draw x ticks.
for i = 1:length(xticks)
    th = line(xticks(i)*[1 1],YL(1)+[0 -ticklength_alongy],'clipping','off','color',[0 0 0]);
end

% loop through and draw y ticks.
for i = 1:length(yticks)
    th = line(XL(1)+[0 -ticklength_alongx],yticks(i)*[1 1],'clipping','off','color',[0 0 0]);    
end

% loop through and draw in x tick labels.
for i = 1:length(xticklabels)
    th = text(xticklabels(i),YL(1)-2*ticklength_alongy,num2str(xticklabels(i)));
    set(th,'verticalalignment','top','horizontalalignment','center')
end

% loop through and draw in y tick labels.
for i = 1:length(yticklabels)
    th = text(XL(1)-2*ticklength_alongx,yticklabels(i),num2str(yticklabels(i)));
    set(th,'verticalalignment','middle','horizontalalignment','right')
end
