function [] = plotsubplots(varargin)
% function [] = plotsubplots(plotdata)
%
% plots a matrix of timecourse data (samples x channels) as separate
% subplots in a figure.
%
% function [] = plotsubplots(time,plotdata)
% uses the time vector time.
%
% function [] = plotsubplots(time,plotdata,plotnames)
% uses the time vector time and the cell array of plot name strings plotnames.


if nargin==1
    plotdata = varargin{1};
    nsubplots = size(plotdata,2);
    ncols = floor(nsubplots^0.5);
    nrows = ceil(nsubplots/ncols);
    
    figure
    for i = 1:nsubplots
        subplot(nrows,ncols,i)
        plot(plotdata(:,i))
    end    
elseif nargin==2
    time = varargin{1};
    plotdata = varargin{2};
    nsubplots = size(plotdata,2);
    ncols = floor(nsubplots^0.5);
    nrows = ceil(nsubplots/ncols);
    
    figure
    for i = 1:nsubplots
        subplot(nrows,ncols,i)
        plot(time,plotdata(:,i))
    end
elseif nargin==3
    time = varargin{1};
    plotdata = varargin{2};
    plotnames = varargin{3};
    nsubplots = size(plotdata,2);
    ncols = floor(nsubplots^0.5);
    nrows = ceil(nsubplots/ncols);
    
    figure
    for i = 1:nsubplots
        subplot(nrows,ncols,i)
        plot(time,plotdata(:,i))
        title(plotnames{i})
    end
end

end