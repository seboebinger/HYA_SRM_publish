function [] = plotregresswithintercept(xdata,ydata)
% function [] = plotregresswithintercept(xdata,ydata)
% 
% Plots data with regression line including intercept.
% 
% See also plotregress.m for same functionality with no intercept.
% 
% J. Lucas McKay
% 2011

[b,~,~,~,stats] = regress(ydata(:),[xdata(:) ones(size(xdata(:)))]);
p = stats(3);

r = [min(xdata) max(xdata)];
plot(xdata,ydata,'k.')
plot(r,b(1)*r+b(2),'k-')
y = get(gca,'ylim');
x = get(gca,'xlim');

% t = text(r(1),y(2),['   slope = ' num2str(b(1),3) '; intercept = ' num2str(b(2),3) '; p <= ' num2str(p,3)]);
t = text(x(1),y(2),['   slope = ' num2str(b(1),3) '; intercept = ' num2str(b(2),3) '; p <= ' num2str(p,3)]);
set(t,'horizontalalignment','left','verticalalignment','top')

