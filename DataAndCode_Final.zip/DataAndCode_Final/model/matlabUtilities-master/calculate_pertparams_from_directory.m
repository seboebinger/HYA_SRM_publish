function pertparams_out = calculate_pertparams_from_directory(varargin)
% function pertparams = calculate_pertparams_from_directory(directory)
%
% calculate_pertparams_from_directory
% uses a gui to locate the input directory, uses a gui to save output file
%
% out = calculate_pertparams_from_directory
% uses a gui to locate the input directory, returns a table
%
% calculate_pertparams_from_directory(directory)
% uses a gui to save output file
%
% J. Lucas McKay, 6 October 2015
%
% Edited 16 October 2015
% Last edit:
% Remove path supplied in argument from output filename.

if nargin==0
	directory = uigetdir('./','specify directory');
	directorycontents = dir(directory);
else
	directory = uigetdir(varargin{1},'specify directory');
	directorycontents = dir(directory);
end


% On os x, the first two items in the directory are pointers to the
% current, and the above, directory. Hence we start at i=3. This is
% admittedly a little hacky.
filename = [];
viconid = [];
trialname = [];
for i = 3:length(directorycontents)
	path_to_file = deblank([directory filesep directorycontents(i).name]);
	filename = strvcat(filename,path_to_file);
	
	try
		[viconid_temp sessionnum_temp trialname_temp trialnum_temp] = unpackviconfilename(path_to_file);
		viconid = strvcat(viconid,viconid_temp);
		sessionnum(i,1) = sessionnum_temp;
		trialname = strvcat(trialname,trialname_temp);
		trialnum(i,1) = trialnum_temp;
	catch
		viconid = strvcat(viconid,' ');
		sessionnum(i,1) = nan;
		trialname = strvcat(trialname,' ');
		trialnum(i,1) = nan;
	end
	
	try
		[pertonset_rec_s(i,1), pertonset_calc_s(i,1), pertdir_calc_deg(i,1), pertdisp_calc_cm(i,1), pertvel_calc_cm_s(i,1), pertacc_calc_g(i,1), stancewidth_calc_cm(i,1)] = calculatetrialdata(path_to_file);
	catch
		[pertonset_rec_s(i,1), pertonset_calc_s(i,1), pertdir_calc_deg(i,1), pertdisp_calc_cm(i,1), pertvel_calc_cm_s(i,1), pertacc_calc_g(i,1), stancewidth_calc_cm(i,1)] = deal(nan);
	end
end
% Add two blanks to the filename to correct for the two missing paths
filename = strvcat(' ',filename);
filename = strvcat(' ',filename);

viconid = strvcat(' ',viconid);
viconid = strvcat(' ',viconid);

trialname = strvcat(' ',trialname);
trialname = strvcat(' ',trialname);

% Remove the directory specified at the command line from the absolute file path.
if nargin>0
	pathlen = length(varargin{1});
	filename = filename(:,pathlen+1:end);
end


% Calculate the rounded perturbation direction
pertdir_calc_round_deg = findnearestpertdir(pertdir_calc_deg);

% Create placeholder columns.
[redcapid, obs, uniqueid, step, kincorrect] = deal(repmat(' ',length(pertdir_calc_deg),1));

pertparams = table(...
	uniqueid, ...
	obs, ...
	redcapid, ...
	viconid,...
	trialname,...
	trialnum,...
	pertdir_calc_round_deg,...
	step, ...
	kincorrect, ...
	sessionnum,...
	filename,...
	pertdir_calc_deg,...
	pertdisp_calc_cm,...
	pertvel_calc_cm_s,...
	pertacc_calc_g,...
	stancewidth_calc_cm);

pertparams(1:2,:) = [];

if nargout>0
	pertparams_out = pertparams;
else
	[outputfilename, outputpathname] = uiputfile('pertparams.csv','select output file');
	path_to_output_file = [outputpathname outputfilename];
	writetable(pertparams,path_to_output_file);
	eval(['!open ' path_to_output_file])
end


end


function [pertonset_rec_s, pertonset_calc_s, pertdir_calc_deg, pertdisp_calc_cm, pertvel_calc_cm_s, pertacc_calc_g, stancewidth_calc_cm] = calculatetrialdata(filename)

% Load data.
load(filename,'rawData','platonset','Accels','LVDT','atime','mtime','Velocity')

% Missing markers are set to zero. For markers numerically equal to zero,
% set to NaN. Note that the raw data markers must be used, here -
% otherwise, the filtering introduces artifacts when markers appear and
% disappear.
Markers = rawData.video.markers;
for i = 1:size(Markers,1)
	for j = 1:25
		if (Markers(i,j,1)==0)&(Markers(i,j,2)==0)&(Markers(i,j,3)==0)
			Markers(i,j,:)=nan;
		end
	end
end

% Save old perturbation onset, if any.
try
	pertonset_rec_s = platonset;
catch
	pertonset_rec_s = nan;
end

% Calculate perturbation onset time from recorded data.
try
	Accel_along_axis = (Accels(:,1).^2 + Accels(:,2).^2).^0.5;
	[pertonset_calc_s,~] = calculateperturbationonset(Accel_along_axis,atime);
catch
	pertonset_calc_s = nan;
end

% Calculate perturbation direction from recorded data.
try
	% Subtract off first sample.
	Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
	
	% Determine maximum absolute displacement to calculate perturbation
	% direction. Note that this is required because the platform may be
	% returning at the end of the trial.
	[DisplacementTH,DisplacementR] = cart2pol(Displacement(:,1),Displacement(:,2));
	DisplacementTH = DisplacementTH*180/pi;
	[peakdisp, temp] = max(DisplacementR);
	pertdir_calc_deg = DisplacementTH(temp);
	pertdir_calc_deg(pertdir_calc_deg<0) = pertdir_calc_deg(pertdir_calc_deg<0)+360;
catch
	pertdir_calc_deg = nan;
end

% Calculate peak perturbation displacement, velocity, and acceleration from recorded data.
try
	% Calculate displacement in direction of perturbation. For ease of reading,
	% the zeroing procedure is included again.
	Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
	DisplacementPD = Displacement(:,1)*cosd(pertdir_calc_deg) + Displacement(:,2)*sind(pertdir_calc_deg);
	pertdisp_calc_cm = max(DisplacementPD);
catch
	pertdisp_calc_cm = nan;
end

try
	% Calculate velocity in direction of perturbation.
	Velocity = Velocity - repmat(Velocity(1,:),size(Velocity,1),1);
	VelocityPD = Velocity(:,1)*cosd(pertdir_calc_deg) + Velocity(:,2)*sind(pertdir_calc_deg);
	pertvel_calc_cm_s = max(VelocityPD);
catch
	pertvel_calc_cm_s = nan;
end

try
	% Calculate acceleration in direction of perturbation.
	Acceleration = Accels - repmat(Accels(1,:),size(Accels,1),1);
	AccelerationPD = Acceleration(:,1)*cosd(pertdir_calc_deg) + Acceleration(:,2)*sind(pertdir_calc_deg);
	pertacc_calc_g = max(AccelerationPD);
catch
	pertacc_calc_g = nan;
end

% Calculate stance width as average distance between the heel markers
% during the first 0.25 seconds. Note that this is calculated as a vector
% norm, so should work if the subject is facing a different direction.
% Markers are in mm, so divide by 10 for cm.
try
	stancewidth_calc_cm = 0.1*norm(mean(squeeze(Markers(mtime<0.25,24,:)) - squeeze(Markers(mtime<0.25,18,:))));
catch
	stancewidth_calc_cm = nan;
end

end

function [perturbationonset,onsetind] = calculateperturbationonset(Accels,atime)
% function [perturbationonset] = calculateperturbationonset(trialdata)
%
% J. Lucas McKay, Ph.D.
% 3 April 2013
% MOdified 23 Apr, 2013 by SAC to match variable names to my data
%
% This method recalculates perturbation onset based on a threshold applied
% to acceleration magnitude. It has only been validated on A-P trials of
% certain magnitudes!
%
% JA says this code works for multidirectional perturbations 2014 9 10
% (KCL)
%
% Copied into createinterpolatedbalancedataset.m by JLM, 2014-09-26. Note
% that there is a bug in the code (uncorrected here - does not affect
% function) that bkgdsd = bkgdmn.

% calculate the sample at which the acceleration hits 6SD.
bkgdmn = nanmean(Accels(atime<0.25));
accelmag = abs(Accels(:)-bkgdmn);

bkgdmn = nanmean(accelmag(atime<0.25));
bkgdsd = nanmean(accelmag(atime<0.25));

% onsetind = find(accelmag>bkgdmn+l1*bkgdsd,1,'first');
% onsetind = find(accelmag(1:onsetind)<bkgdmn+l2*bkgdsd,1,'last');
onsetind = find(accelmag>bkgdmn+0.016,1,'first');

% add a sample offset to the identified onset sample to account for the
% average 10 ms lag between the acceleration zero crossing and the
% threshold crossing.
onsetind = onsetind - 15;
perturbationonset = atime(onsetind);

end