function C = table2arglist(T)
% function C = table2arglist(T)
% 
% Converts a table with 1 row into a cell array suitable for supplying as
% an argument list.
% 
% J. Lucas McKay
% 2017 06 07


varnames = T.Properties.VariableNames;
varvals = table2cell(T);

C = [varnames varvals];
C(1:2:end) = varnames;
C(2:2:end) = varvals;

end