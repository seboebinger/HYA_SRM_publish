function out = makesubplotnumbers(nrows,ncols)
% function out = makesubplotnumbers(nrows,ncols)

out = reshape(1:(nrows*ncols),ncols,nrows)';

end