function gle
% function gle
% go to last error
% JLM 2017 02 02

lasterr = lasterror;
message = lasterr.message;

% check and see if error contains a specific file
f = regexp(message,'File: \w+\.m','match');

if isempty(f)
    return;
else
    l = regexp(message,'Line: \d+','match');
    c = regexp(message,'Column: \d+','match');
    filename = f{1}(7:end);
    fileloc = which(filename);
    linenum = str2num(l{1}(7:end));
    colnum = str2num(c{1}(9:end));
    opentoline(fileloc,linenum,colnum)
end

end