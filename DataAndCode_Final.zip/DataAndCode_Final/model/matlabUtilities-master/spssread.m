function dataset = spssread(file)
% function dataset = spssread(spssfile)
% 
% Read an .xlsx file prepared by SPSS into a Matlab dataset.
% 
% System-missing values are retained.
% 
% J. Lucas McKay, Ph.D.
% 28 October, 2013

% Load the data
[num,txt,raw] = xlsread(file);

% Convert to dataset array
dataset = cell2dataset(raw);

end
