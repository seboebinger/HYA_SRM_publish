function out = demean(in)
% function out = demean(in)
% 
% removes the mean of dimension 1 from the input. works for vectors up to
% 3 dimensions.

s = size(in);
mn = nanmean(in,1);

if length(s)==1
    out = in - mn;
elseif length(s)==2
    out = in - repmat(mn,[s(1) 1]);
else
    out = in - repmat(mn,[s(1) 1 1]);
end

end