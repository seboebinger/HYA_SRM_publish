function ds = createinterpolatedbalancedataset(trialdatafile,emggainfile)
%
% J. Lucas McKay, Ph.D.
% 2014 09 26
%
% Usage: ds = createinterpolatedbalancedataset()
%
% ds = createinterpolatedbalancedataset(trialdatafile)
% 
% where trialdatafile is a matlab table with the variable "filename," a
% cell array of absolute file locations, or a csv/xlsx with a variable
% "filename," an array of absolute file locations.
%
% function ds = createinterpolatedbalancedataset(trialdatafile,emggainfile)
%
% NB: if you are not on os x or linux, there is a call to /usr/bin/perl at
% the bottom of the script that alters NaN to the character '.' for reading
% into SAS/SPSS. This won't work for you. Comment it out and do a find and
% replace in excel or a text editor.
%
% NB: when the output dataset is created for import into SAS/SPSS, if you
% have a short text variable as the first observation, the remaining
% observations may be truncated. You can fix this manually by adding a few
% characters to the first entry of that variable if it happens to turn up.
%
% NB: this code assumes that markers 18 and 24 are the heel kinematic
% markers. if you are using a different marker set, you should modify the
% code to match the marker name rather than the current hardcoded solution.
% I am a bit overextended to establish that functionality for now.
%
%
% Last edit: 2014-10-06
% JLM
% Allow tab delimited (.txt) and comma-delimited (.csv) input files.
%
% KCL modified 2014 10 8 to 1) have narrow_vs_wide match
% narrow0_vs_wide1_vs_SS2 header and 2) added hold on for plots and 3) have
% all narrow plots use blue
%
% 2014-12-19
% Altered to use table format
% JLM
%
% 2015-01-08
% Altered to accept "gain" file. Default is to assume 1.0 gains for all
% recorded EMG.
%
% 2015-01-11
% Added flag to reflect CoM kinematics so that displacements due to initial
% platform motion are positive.
%
% 2015-05-26
% Added behavior to accept Matlab tables rather than file locations.
% 
% 2015-06-09
% Corrected a bug where EMGraw and EMGrect were not loaded correctly. This
% is not assumed to affect behavior unless these variables were of
% interest.
% 
% 2015-07-29
% Added some code to compare CoM displacement estimates from markers and
% forces.
% 
% 2016-02-21
% Added a default value for RESCALE_EMG


% Set absolute limits on time and sample frequency here. These times are
% w.r.t. platform onset.
MINTIME_S = -0.5;
MAXTIME_S = 2;
FS_HZ = 1080;

% Set flag to load raw + rectified EMG as well as processed.
LOADRAWEMG = 1;

% Set flag to pad spaces onto character variables for import into SAS.
PADCHAR = 0;

% Set flag to reverse signs of CoM displacement, velocity, acceleration,
% jerk signals. If this flag is set, the initial acceleration of the CoM
% will be positive with respect to the ankles.
REFLECTKINEMATICS = 1;

% Interpolate all analog data to a common "analog" timebase, atime.
atime = MINTIME_S:(1/FS_HZ):MAXTIME_S-(1/FS_HZ);

% Interpolate marker data to a common "marker" timebase, mtime.
mtime = MINTIME_S:(1/FS_HZ):MAXTIME_S-(1/FS_HZ);

% Load the trial file.
if ischar(trialdatafile)
    ds = readtable(trialdatafile);
else
    ds = trialdatafile;
end

% Load the gain file
if nargin>1
    if ischar(emggainfile)
        gain_ds = readtable(emggainfile);
    else
        gain_ds = emggainfile;
    end
    gain_ds.Properties.RowNames = gain_ds.participant;
    RESCALE_EMG = 1;
else
    RESCALE_EMG = 0;
end

% instantiate the new file location variables that you will create.
fprintf(1,'loading trial information');
viconid = [];
sessionnum = [];
trialname = [];
trialname_str = [];
trialname_num = [];
trialnum = [];

for i = 1:size(ds.filename,1)
    % break the file into parts.
    [pathstr_i,name_i,ext_i] = fileparts(ds.filename{i});
    
    % skip hidden files
    if isempty(name_i)|((name_i(1)=='.')==1)
        continue
    end
    % otherwise carry on, ensuring that all variables have the same number
    % of rows.
    
    % try to identify the session number.
    try
        temp = regexpi(pathstr_i,'Session (\d+)','tokens');
        sessionnum_i = str2num(char(temp{1}));
    catch
        sessionnum_i = nan;
    end
    sessionnum = [sessionnum; sessionnum_i];
    
    % try to identify the vicon id. note that this only works on macintosh
    % platforms.
    try
        % temp = regexpi(pathstr_i,'/(\w+)/Session \d+','tokens');
        [~, tokens] = regexp(pathstr_i,'/(\w+)/Session \d+','match','tokens');
        viconid_i = char(tokens{1});
    catch
        viconid_i = ' ';
    end
    viconid = strvcat(viconid,viconid_i);
    
    % copy in the trial name (e.g., "trial,") and number
    trialname = strvcat(trialname,name_i);
    trialname_str = strvcat(trialname_str,char(regexpi(name_i,'[a-z]+','match')));
    trialname_num = strvcat(trialname_num,char(regexpi(name_i,'\d+','match')));
    trialnum = [trialnum; str2num(char(regexpi(name_i,'\d+','match')))];
end

ds = [ds table(viconid,sessionnum,trialname,trialname_str,trialname_num,trialnum)];
clear viconid sessionnum trialname trialname_str trialname_num trialnum
fprintf(1,'\nloading trial information complete\n');

% Note number of observations
Nobs = size(ds,1);

% Save the perturbation onset calculated by proc_batch and calculate a new perturbation onset from each trial
pertonset_rec_s = nan(Nobs,1);
pertonset_calc_s = nan(Nobs,1);

% Calculate perturbation direction from each trial
pertdir_calc_deg = nan(Nobs,1);

% Calculate perturbation kinetics from each trial
pertdisp_calc_cm = nan(Nobs,1);
pertvel_calc_cm_s = nan(Nobs,1);
pertacc_calc_g = nan(Nobs,1);

% Calculate stance width from each trial
stancewidth_calc_cm = nan(Nobs,1);

% Loop through trials and calculate perturbation characteristics. Print progress on
% command line.
fprintf(1,'loading perturbation characteristics');
for i = 1:Nobs
    [pertonset_rec_s(i,1), pertonset_calc_s(i,1), pertdir_calc_deg(i,1), pertdisp_calc_cm(i,1), pertvel_calc_cm_s(i,1), pertacc_calc_g(i,1), stancewidth_calc_cm(i,1)] = calculatetrialdata(deblank(ds.filename{i}));
end
fprintf(1,'\nloading perturbation characteristics complete\n');

% Append computed variables to dataset.
ds.pertonset_rec_s = pertonset_rec_s;
ds.pertonset_calc_s = pertonset_calc_s;
ds.pertdir_calc_deg = pertdir_calc_deg;
ds.pertdir_calc_round_deg = findnearestpertdir(ds.pertdir_calc_deg);
ds.pertdisp_calc_cm = pertdisp_calc_cm;
ds.pertvel_calc_cm_s = pertvel_calc_cm_s;
ds.pertacc_calc_g = pertacc_calc_g;
ds.stancewidth_calc_cm = stancewidth_calc_cm;

% Load and interpolate the EMG variables.
fprintf(1,'loading trial electromyograms');

% Loop through trials to identify which EMG records are available in the
% dataset. Then variables can be instantiated appropriately with NaN
% instead of 0 for missing values.
for i = 1:Nobs
    trialEMGID = load(deblank(ds.filename{i}),'EMGID');
    trialEMGID = trialEMGID.EMGID;
    trialEMGinds = find(cell2mat(regexpi(cellstr(trialEMGID),'EMG_\D')));
    trialEMGID = trialEMGID(trialEMGinds,:);
    
    if i==1
        EMGID = trialEMGID;
    else
        EMGID = unique([EMGID;trialEMGID],'rows');
    end
    [EMGID,~] = unique(EMGID,'rows');
end
clear trialEMGID trialEMGinds
Nmus = size(EMGID,1);

% Instantiate variables.
EMG = nan(Nobs,Nmus,length(atime));
EMGraw = nan(Nobs,Nmus,length(atime));
EMGrect = nan(Nobs,Nmus,length(atime));

for i = 1:Nobs
    % load the data from the trial, and interpolate to common timebase.
    trialdata = interpolatetrialdata(deblank(ds.filename{i}),atime,pertonset_calc_s(i));
    
    % copy recorded EMG records into the correct columns of the combined
    % EMG matrix.
    [~,trialEMGinds,combinedEMGinds] = intersect(trialdata.EMGID,EMGID,'rows');
    EMG(i,combinedEMGinds,:) = trialdata.EMG(1,trialEMGinds,:);
    EMGraw(i,combinedEMGinds,:) = trialdata.EMGraw(1,trialEMGinds,:);
    EMGrect(i,combinedEMGinds,:) = trialdata.EMGrect(1,trialEMGinds,:);
end

% Rescale EMG if gain variables were provided.

% If a gain matrix has been provided, scale all EMG to 1k gain. Note that
% gain variables are coded as 1 (1k) through 10 (10k). Gain variables coded
% as -1 correspond to empty channels.
if RESCALE_EMG
    fprintf(1,'\nrescaling electromyogram gain values\n');
    % Make a copy of the EMG.
    EMG_1k = EMG;
    EMGraw_1k = EMGraw;
    EMGrect_1k = EMGrect;
    
    % Loop through trials
    for i = 1:size(EMG,1)
        temp_viconid = deblank(ds{i,'viconid'});
        
        % Loop through muscles
        for j = 1:size(EMG,2)
            temp_emgname = strrep(deblank(EMGID(j,:)),'-','_');
            temp_gain = gain_ds{temp_viconid,lower([temp_emgname '_gain'])};
            
            % If the gain is coded as "missing," switch to nan.
            if temp_gain==-1, temp_gain=nan; end;
            
            % Rescale the muscle by the appropriate gain.
            EMG_1k(i,j,:) = EMG(i,j,:)*1/temp_gain;
            EMGraw_1k(i,j,:) = EMGraw(i,j,:)*1/temp_gain;
            EMGrect_1k(i,j,:) = EMGrect(i,j,:)*1/temp_gain;
        end
    end
    
    % Overwrite the EMG with the copy.
    EMG = EMG_1k;
    EMGraw = EMGraw_1k;
    EMGrect = EMGrect_1k;
    
    % Clear remaining variables.
    clear i j temp_viconid temp_emgname temp_gain EMG_1k EMGraw_1k EMGrect_1k
else
    fprintf(1,'\nno electromyogram gain values supplied\n');
end

% Put EMG in the table.
% Load raw and rectified EMG into the table if desired.
if LOADRAWEMG
    for i = 1:Nmus
        varName = strrep([deblank(EMGID(i,:)) '_raw'],'-','_');
        varData = table(squeeze(EMGraw(:,i,:)));
        varData.Properties.VariableNames = {varName};
        ds = [ds varData];
        clear varName varData;
    end
    
    for i = 1:Nmus
        varName = strrep([deblank(EMGID(i,:)) '_rect'],'-','_');
        varData = table(squeeze(EMGrect(:,i,:)));
        varData.Properties.VariableNames = {varName};
        ds = [ds varData];
        clear varName varData;
    end
end

% Load atime into the table.
atime_s = repmat(atime,Nobs,1);
fs_hz = repmat(1/(atime(2)-atime(1)),Nobs,1);
ds = [ds table(fs_hz) table(atime_s)];

% Load filtered EMG into the table.
for i = 1:Nmus
    varName = strrep([deblank(EMGID(i,:))],'-','_');
    varData = table(squeeze(EMG(:,i,:)));
    varData.Properties.VariableNames = {varName};
    ds = [ds varData];
    clear varName varData;
end
fprintf(1,'loading electromyograms complete\n');

% Loop through trials and calculate perturbation characteristics. Print progress on
% command line.
fprintf(1,'loading kinematics');

% Add kinematic and kinetic variables to dataset.
% Instantiate variables.
compos_cm = nan(Nobs, length(atime)); % CoM displacement along perturbation direction, cm
comvel_cm_s = nan(Nobs, length(atime)); % CoM velocity along perturbation direction, cm/s
comacc_g = nan(Nobs, length(atime)); % CoM acceleration along perturbation direction, g
comjrk_g_s = nan(Nobs, length(atime)); % CoM jerk along perturbation direction, g/s
platpos_cm = nan(Nobs, length(atime));
platvel_cm_s = nan(Nobs, length(atime));
platacc_g = nan(Nobs, length(atime));
mass_kg = nan(Nobs,1); % Mass, kg
comh_cm = nan(Nobs,1); % CoM height, cm

compos_cm_markers = nan(Nobs, length(atime)); % CoM displacement along perturbation direction, cm, calculated from markers

for i = 1:Nobs
    % load the data from the trial, and interpolate to common timebase.
    trialdata = interpolatetrialdata(deblank(ds.filename{i}),atime,pertonset_calc_s(i));
    
    % copy over variables of interest, e.g., participant mass.
    mass_kg(i) = trialdata.mass;
    comh_cm(i) = trialdata.COMh;
    
    pertdir = ds.pertdir_calc_round_deg(i);
    
    % calculate perturbation acceleration in direction of perturbation
    platpos_cm(i,:) = project_onto_perturbation_direction(pertdir,trialdata.Plate(1,1,1,:),trialdata.Plate(1,1,2,:));
    platvel_cm_s(i,:) = project_onto_perturbation_direction(pertdir,trialdata.Plate(1,2,1,:),trialdata.Plate(1,2,2,:));
    platacc_g(i,:) = project_onto_perturbation_direction(pertdir,trialdata.Plate(1,3,1,:),trialdata.Plate(1,3,2,:));
    
    % calculate CoM motion in direction of perturbation
    compos_cm_markers(i,:) = project_onto_perturbation_direction(pertdir,trialdata.COMmarkers(1,1,1,:),trialdata.COMmarkers(1,1,2,:));
    compos_cm(i,:) = project_onto_perturbation_direction(pertdir,trialdata.COMplate(1,1,1,:),trialdata.COMplate(1,1,2,:));
    comvel_cm_s(i,:) = project_onto_perturbation_direction(pertdir,trialdata.COMplate(1,2,1,:),trialdata.COMplate(1,2,2,:));
    comacc_g(i,:) = project_onto_perturbation_direction(pertdir,trialdata.COMplate(1,3,1,:),trialdata.COMplate(1,3,2,:));
    
    % zero out CoM motion at perturbation onset.
    compos_cm_markers(i,:) = compos_cm_markers(i,:)-compos_cm_markers(i,atime==0);
    compos_cm(i,:) = compos_cm(i,:)-compos_cm(i,atime==0);
    comvel_cm_s(i,:) = comvel_cm_s(i,:)-comvel_cm_s(i,atime==0);
    comacc_g(i,:) = comacc_g(i,:)-comacc_g(i,atime==0);
    
    % calculate jerk in direction of perturbation
    [~, comjrk_g_s(i,:), ~] = sgolaydiff(comacc_g(i,:),4,151);
    
    clear pertdir trialdata
end

COMPAREPOSITIONESTIMATES = false
if COMPAREPOSITIONESTIMATES
    % Compare CoM position estimates from markers and from force data
    figure
    subplot(2,2,1)
    title('CoM displacement estimates from force data')
    xlabel('time')
    ylabel('CoM displacement')
    for i = 1:Nobs
        plot(atime_s(i,:),compos_cm(i,:)+4*(i-1))
    end
    subplot(2,2,2)
    title('CoM displacement estimates from markers')
    xlabel('time')
    ylabel('CoM displacement')
    for i = 1:Nobs
        plot(atime_s(i,:),compos_cm_markers(i,:)+4*(i-1))
    end
    subplot(2,2,3)
    title('Comparison, 0<t<650 ms')
    xlabel('CoM displacement (markers)')
    ylabel('CoM displacement (forces)')
    xlim([-8 0])
    ylim([-8 0])
    axis equal
    for i = 1:Nobs
        timewindow = atime_s(i,:)<0.65 & atime_s(i,:)>0.0;
        plot(compos_cm_markers(i,timewindow),compos_cm(i,timewindow),'clipping','off');
    end
    plot(get(gca,'ylim'),get(gca,'ylim'),'k:')
    subplot(2,2,4)
    title('Comparison, whole trial')
    xlabel('CoM displacement (markers)')
    ylabel('CoM displacement (forces)')
    xlim([-8 0])
    ylim([-8 0])
    axis equal
    for i = 1:Nobs
        timewindow = 1:length(atime_s(i,:));
        plot(compos_cm_markers(i,timewindow),compos_cm(i,timewindow),'clipping','off');
    end
    plot(get(gca,'ylim'),get(gca,'ylim'),'k:')
    
    % Calculate R2 for the first 650 ms or the whole trial.
    for i = 1:Nobs
        timewindow = atime_s(i,:)<0.65 & atime_s(i,:)>0.0;
        
        x = compos_cm_markers(i,timewindow);
        y = compos_cm(i,timewindow);
        x = x(:);
        y = y(:);
        
        timewindow = {'0.000<t<0.650'};
        
        if all(isnan(x)) == false
            
            [b,~,residuals,~,stats] = regress(y,[x ones(size(x))]);
            slope = b(1);
            intercept = b(2);
            % calculate pearson's rho
            [rho,pval] = corr(x,y,'rows','complete');
            p = stats(3);
        else
            slope = nan;
            intercept = nan;
            rho = nan;
            p = nan;
        end
        if exist('outputtable','var')
            outputtable = [outputtable;table(timewindow,slope,intercept,rho,p)];
        else
            outputtable = table(timewindow,slope,intercept,rho,p);
        end
    end
    
    for i = 1:Nobs
        timewindow = 1:length(atime_s(i,:));
        
        x = compos_cm_markers(i,timewindow);
        y = compos_cm(i,timewindow);
        x = x(:);
        y = y(:);
        
        timewindow = {'all t'};
        
        if all(isnan(x)) == false
            
            [b,~,residuals,~,stats] = regress(y,[x ones(size(x))]);
            slope = b(1);
            intercept = b(2);
            % calculate pearson's rho
            [rho,pval] = corr(x,y,'rows','complete');
            p = stats(3);
        else
            slope = nan;
            intercept = nan;
            rho = nan;
            p = nan;
        end
        if exist('outputtable','var')
            outputtable = [outputtable;table(timewindow,slope,intercept,rho,p)];
        else
            outputtable = table(timewindow,slope,intercept,rho,p);
        end
    end
    outputtable.timewindow = categorical(outputtable.timewindow);
    summary(outputtable(outputtable.timewindow~='all t',2:end))
    summary(outputtable(outputtable.timewindow=='all t',2:end))
end

if REFLECTKINEMATICS == 1
    compos_cm = -1*compos_cm;
    comvel_cm_s = -1*comvel_cm_s;
    comacc_g = -1*comacc_g;
    comjrk_g_s = -1*comjrk_g_s;
end

% add variables to the table.
ds = [ds table(platpos_cm,platvel_cm_s,platacc_g,compos_cm,comvel_cm_s,comacc_g,comjrk_g_s)];
fprintf(1,'\nloading kinematics complete\n');

return




% plot 270� perturbations, just right leg, off, and on
rowvars = {'EMG_MGAS_L' 'EMG_TA_L' 'comjrk_g_s' 'comacc_g' 'comvel_cm_s' 'compos_cm' 'platpos_cm'}';
colvars = {...
    strcmpi(ds.id,'larry')&(ds.pertdir_calc_round_deg==270)&strcmpi(ds.sw,'n')&strcmpi(ds.condition,'off')...
    strcmpi(ds.id,'larry')&(ds.pertdir_calc_round_deg==270)&strcmpi(ds.sw,'n')&strcmpi(ds.condition,'on')...
    strcmpi(ds.id,'larry')&(ds.pertdir_calc_round_deg==270)&strcmpi(ds.sw,'w')&strcmpi(ds.condition,'off')...
    strcmpi(ds.id,'larry')&(ds.pertdir_calc_round_deg==270)&strcmpi(ds.sw,'w')&strcmpi(ds.condition,'on')...
    };

coltitles = {'larry, 270, N, off','larry, 270, N, on','larry, 270, W, off','larry, 270, W, on'};
flipvars = [0 1 0 0 0 0 0];
agonist = [1 0 0 0 0 0 0];
antagonist = [0 1 0 0 0 0 0];

xl = [-0.2 0.8];
yl = {...
    [0 0.4];
    [0 0.4];
    [-0.002 0.002];
    [-0.2 0.2];
    [-15 15];
    [-5 5];
    [0 10];}

plotbalancedataset(ds,rowvars,colvars,coltitles,flipvars,xl,yl)






% plot 270� perturbations, just right leg, off, and on
rowvars = {'EMG_MGAS_L' 'EMG_TA_L' 'comjrk_g_s' 'comacc_g' 'comvel_cm_s' 'compos_cm' 'platpos_cm'}';
colvars = {...
    strcmpi(ds.id,'larry')&(ds.pertdir_calc_round_deg==270)&strcmpi(ds.sw,'n')&strcmpi(ds.condition,'off')...
    strcmpi(ds.id,'larry')&(ds.pertdir_calc_round_deg==270)&strcmpi(ds.sw,'n')&strcmpi(ds.condition,'on')...
    };

coltitles = {'larry, 270, N, off','larry, 270, N, on'};
flipvars = [0 1 0 0 0 0 0];
agonist = [1 0 0 0 0 0 0];
antagonist = [0 1 0 0 0 0 0];

xl = [-0.2 0.8];
yl = {...
    [0 0.4];
    [0 0.4];
    [-0.002 0.002];
    [-0.2 0.2];
    [-15 15];
    [-5 5];
    [0 10];}

plotbalancedataset(ds,rowvars,colvars,coltitles,flipvars,xl,yl)




%
%
%
% rowvars = {'EMG_MGAS_R' 'EMG_TA_R' 'comjrk_g_s' 'comacc_g' 'comvel_cm_s' 'compos_cm' 'platpos_cm'}';
% colvars = {[strcmpi(ds.id,'alix')&ds.pertdir_calc_round_deg==270] [strcmpi(ds.id,'gina')&ds.pertdir_calc_round_deg==270] [strcmpi(ds.id,'laura')&ds.pertdir_calc_round_deg==270] [strcmpi(ds.id,'lee')&ds.pertdir_calc_round_deg==270]};
% coltitles = {'alix, 270','gina, 270','laura, 270','lee, 270'};
% flipvars = [0 1 0 0 0 0 0 ];
%
% xl = [-0.2 0.8];
% yl = {...
%     [0 0.15];
%     [0 0.15];
%     [0 0.15];
%     [-0.002 0.002];
%     [-0.2 0.2];
%     [-15 15];
%     [-5 5];
%     [0 10];}
%
% plotbalancedataset(ds,rowvars,colvars,coltitles,flipvars,xl,yl)
%
% plotij(7,4,1,3)
% ylim([0 0.5])
% plotij(7,4,2,3)
% ylim([-0.5 0])



%
% rownum = 5;
% XL = [-0.2 0.8]
% YL = [-5 5]
% plotij(nrows,ncols,rownum,1)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'alix')&ds.pertdir_calc_round_deg==90,:))
% xlim(XL); ylim(YL)
% plotij(nrows,ncols,rownum,2)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'gina')&ds.pertdir_calc_round_deg==90,:))
% xlim(XL); ylim(YL)
% plotij(nrows,ncols,rownum,2)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'lee')&ds.pertdir_calc_round_deg==90,:))
% xlim(XL); ylim(YL)
%
%
% XL = [-0.2 0.8]
% YL = [-5 5]
% rownum = 8;
% plotij(nrows,ncols,rownum,1)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'alix')&ds.pertdir_calc_round_deg==90,:))
% xlim(XL); ylim(YL)
% plotij(nrows,ncols,rownum,2)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'gina')&ds.pertdir_calc_round_deg==90,:))
% xlim(XL); ylim(YL)
% plotij(nrows,ncols,rownum,2)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'lee')&ds.pertdir_calc_round_deg==90,:))
% xlim(XL); ylim(YL)
%
%
%
%
% subplot(1,5,4)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'larry')&strcmpi(ds.condition,'off'),:))
% xlim(XL); ylim(YL)
% subplot(1,5,5)
% plot(atime,ds.compos_cm(strcmpi(ds.id,'larry')&strcmpi(ds.condition,'on'),:))
% xlim(XL); ylim(YL)
%
%
% figure
% plot(atime,ds.compos_cm(strcmpi(ds.id,'larry')&strcmpi(ds.condition,'off'),:));
% figure
% plot(atime,ds.compos_cm(strcmpi(ds.id,'larry')&strcmpi(ds.condition,'on'),:));
%

% Add platform to dataset. Note that this is displacement along the
% direction of platform motion.

% Add CoM to dataset. Note that this is expressed along the direction of
% platform motion.

% Calculate feedback gains for each trial / muscle.

% Export or save.

%
%
%
%
%
% 7+3
%
% %%%%%KIM ADD VARIABLES HERE
% % Compute additional variables, e.g., EMG onset times, EMG magnitudes.
% % Remove background levels
% EMG_bak = squeeze(nanmean(EMG(:,:,atime<0),3));
% EMG_100_450 = squeeze(nanmean(EMG(:,:,(atime>0.1)&(atime<0.450)),3));
% EMG_100_200 = squeeze(nanmean(EMG(:,:,(atime>0.1)&(atime<0.2)),3));
% EMG_200_300 = squeeze(nanmean(EMG(:,:,(atime>0.2)&(atime<0.3)),3));
% EMG_300_400 = squeeze(nanmean(EMG(:,:,(atime>0.3)&(atime<0.4)),3));
%
% EMG_bakID = strcat(cellstr(EMGID),{'_bak'});
% EMG_100_450ID = strcat(cellstr(EMGID),{'_100_450_ms'});
% EMG_100_200ID = strcat(cellstr(EMGID),{'_100_200_ms'});
% EMG_200_300ID = strcat(cellstr(EMGID),{'_200_300_ms'});
% EMG_300_400ID = strcat(cellstr(EMGID),{'_300_400_ms'});
%
% dstemp1 = mat2dataset(EMG_bak,'VarNames',EMG_bakID);
% dstemp2 = mat2dataset(EMG_100_450,'VarNames',EMG_100_450ID);
% dstemp3 = mat2dataset(EMG_100_200,'VarNames',EMG_100_200ID);
% dstemp4 = mat2dataset(EMG_200_300,'VarNames',EMG_200_300ID);
% dstemp5 = mat2dataset(EMG_300_400,'VarNames',EMG_300_400ID);
%
% % Append EMG variables to dataset.
% ds = [ds dstemp1 dstemp2 dstemp3 dstemp4 dstemp5];
%
% %%%%%%KIM STOP


% append platform variables here.

if PADCHAR
    % Concatenate blanks to char variables so that they are all the same length
    % string. This is necessary for import into SAS without clipping.
    ds.filename = char(ds.filename);
    ds.viconid = char(ds.viconid);
end

% Export the inputted and computed variables to a dataset for SPSS or SAS.
fprintf(1,'\nsaving output file\n');
% [outputdatafile,outputdatapath] = uiputfile('*.csv','Save Trial Data As','sasinputs.csv');
% export(ds,'file',[outputdatapath,outputdatafile],'delimiter',',');
[outputdatafile,outputdatapath] = uiputfile('*.tsv','Save Trial Data As','sasinputs.tsv');
export(ds,'file',[outputdatapath,outputdatafile],'delimiter','\t');
fprintf(1,'\nsaving output file complete\n');

% Strip NaN characters from the file, replace with SAS-friendly '.'
% character. Note that this checks for the existence of the program "perl"
% on your machine.
fprintf(1,'\nchecking for NaN characters in %s\n',outputdatafile);
if exist('/usr/bin/perl','file')==0
    fprintf(1,'\nwarning: /usr/bin/perl not found.\n%s may contain NaN characters.\nmanual find and replace necessary\n',outputdatafile);
else
    eval(sprintf('!/usr/bin/perl -p -i -e "s/NaN/./g" "%s"',[outputdatapath,outputdatafile]))
    fprintf(1,'\nNaN characters in %s replaced with "."\n',outputdatafile);
end





end





%
% % Remove background from EMG.
% EMG_nobak = EMG - repmat(EMG_bak,1,1,size(EMG,3));
% EMG_nobak_100_450 = squeeze(nanmean(EMG_nobak(:,:,(atime>0.1)&(atime<0.450)),3));
% EMG_nobak_100_200 = squeeze(nanmean(EMG_nobak(:,:,(atime>0.1)&(atime<0.200)),3));
%
%
% % Perform statistical test.
%
% for jj = 1:5
%     % 100-450, demeaned
%     EMG_var_all = [];
%     subject_var_all = [];
%     obs_var_all = [];
%     sw_var_all = [];
%     mus_var_all = [];
%
%     wordfigure([],11,17,8)
%     for i = 1:size(EMGID,1)
%         % Check for right leg muscle
%         if regexpi(EMGID(i,:),'-R')
%             pd = 180;
%         else
%             pd = 0;
%         end
%
%         % Filter by perturbation direction and stance width.
%         lookup = (direction==pd)&~isnan(sw_scale_n0_w1);
%
%         % Change this line to use a different set of EMG.
%         if jj==1
%             EMG_var = EMG_nobak_100_450(lookup,i);
%             t1 = sprintf('%s, %d�, demean, 100-450 ms',deblank(EMGID(i,:)),pd);
%             t2 = 'All muscles, demean, 100-450 ms';
%             fprintf(1,'EMG_nobak_100_450');
%         elseif jj==2
%             EMG_var = EMG_100_450(lookup,i);
%             t1 = sprintf('%s, %d�, 100-450 ms',deblank(EMGID(i,:)),pd);
%             t2 = 'All muscles, 100-450 ms';
%             fprintf(1,'EMG_100_450');
%         elseif jj==3
%             EMG_var = EMG_nobak_100_200(lookup,i);
%             t1 = sprintf('%s, %d�, demean, 100-200 ms',deblank(EMGID(i,:)),pd);
%             t2 = 'All muscles, demean, 100-200 ms';
%             fprintf(1,'EMG_nobak_100_200');
%         elseif jj==4
%             EMG_var = EMG_100_200(lookup,i);
%             t1 = sprintf('%s, %d�, 100-200 ms',deblank(EMGID(i,:)),pd);
%             t2 = 'All muscles, 100-200 ms';
%             fprintf(1,'EMG_100_200');
%         elseif jj==5
%             EMG_var = EMG_bak(lookup,i);
%             t1 = sprintf('%s, %d�, background',deblank(EMGID(i,:)),pd);
%             t2 = 'All muscles, background';
%             fprintf(1,'EMG_bak');
%         end
%
%         subject_var = subject(lookup);
%         obs_var = obs(lookup);
%         sw_var = sw_scale_n0_w1(lookup);
%
%         % Average.
%         pre_n_mn = nanmean(EMG_var(obs_var==1&sw_var==0));
%         pre_n_sd = nanstd(EMG_var(obs_var==1&sw_var==0));
%         post_n_mn = nanmean(EMG_var(obs_var==2&sw_var==0));
%         post_n_sd = nanstd(EMG_var(obs_var==2&sw_var==0));
%
%         pre_w_mn = nanmean(EMG_var(obs_var==1&sw_var==1));
%         pre_w_sd = nanstd(EMG_var(obs_var==1&sw_var==1));
%         post_w_mn = nanmean(EMG_var(obs_var==2&sw_var==1));
%         post_w_sd = nanstd(EMG_var(obs_var==2&sw_var==1));
%
%         % Plot.
%         cmap = get(0,'defaultaxescolororder');
%         plotsep = 0.025;
%         plotij(16,2,i,1)
%         xlim([0 3])
%         set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%         title(t1);
%
%         p1 = plot([1 2]',[pre_n_mn post_n_mn; pre_w_mn post_w_mn]','marker','.','markersize',8);
%         transobj(p1(1),-plotsep,0);
%         transobj(p1(2),plotsep,0);
%         p2 = plot([1 1]',pre_n_mn+pre_n_sd*[-1 1],'color',cmap(1,:));
%         transobj(p2,-plotsep,0);
%         p2 = plot([1 1]',pre_w_mn+pre_w_sd*[-1 1],'color',cmap(2,:));
%         transobj(p2,plotsep,0);
%         p3 = plot([2 2]',post_n_mn+post_n_sd*[-1 1],'color',cmap(1,:));
%         transobj(p3,-plotsep,0);
%         p3 = plot([2 2]',post_w_mn+post_w_sd*[-1 1],'color',cmap(2,:));
%         transobj(p3,plotsep,0);
%
%         plotij(16,2,i,2)
%         [p,anovatab,stats] = anovan(EMG_var,{obs_var sw_var subject_var},'model',[1 1 0; 1 0 0; 0 1 0; 0 0 1],'varnames',{'prevspost' 'narrowvswide' 'subject'},'display','off');
%         %[comparison,means,H,gnames]=multcompare(stats,'display','off')
%         xlim([0 1])
%         ylim([0 1])
%         axis off
%         t = text(0,1,sprintf('%1.6f\n',p));
%
%         % Save the EMG variables for an overall analysis.
%         EMG_var_all = [EMG_var_all; EMG_var];
%         subject_var_all = [subject_var_all; subject_var];
%         obs_var_all = [obs_var_all; obs_var];
%         sw_var_all = [sw_var_all; sw_var];
%         mus_var_all = [mus_var_all; i*ones(size(EMG_var))];
%     end
%
%     % Plot the overall analysis
%     pre_n_mn = nanmean(EMG_var_all(obs_var_all==1&sw_var_all==0))
%     pre_n_sd = nanstd(EMG_var_all(obs_var_all==1&sw_var_all==0))
%     post_n_mn = nanmean(EMG_var_all(obs_var_all==2&sw_var_all==0))
%     post_n_sd = nanstd(EMG_var_all(obs_var_all==2&sw_var_all==0))
%
%     pre_w_mn = nanmean(EMG_var_all(obs_var_all==1&sw_var_all==1))
%     pre_w_sd = nanstd(EMG_var_all(obs_var_all==1&sw_var_all==1))
%     post_w_mn = nanmean(EMG_var_all(obs_var_all==2&sw_var_all==1))
%     post_w_sd = nanstd(EMG_var_all(obs_var_all==2&sw_var_all==1))
%
%     % Plot.
%     wordfigure([],11,17,8)
%     cmap = get(0,'defaultaxescolororder');
%     plotsep = 0.025;
%     plotij(2,2,1,1)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(t2);
%
%     p1 = plot([1 2]',[pre_n_mn post_n_mn; pre_w_mn post_w_mn]','marker','.','markersize',8);
%     transobj(p1(1),-plotsep,0);
%     transobj(p1(2),plotsep,0);
%     p2 = plot([1 1]',pre_n_mn+pre_n_sd*[-1 1],'color',cmap(1,:));
%     transobj(p2,-plotsep,0);
%     p2 = plot([1 1]',pre_w_mn+pre_w_sd*[-1 1],'color',cmap(2,:));
%     transobj(p2,plotsep,0);
%     p3 = plot([2 2]',post_n_mn+post_n_sd*[-1 1],'color',cmap(1,:));
%     transobj(p3,-plotsep,0);
%     p3 = plot([2 2]',post_w_mn+post_w_sd*[-1 1],'color',cmap(2,:));
%     transobj(p3,plotsep,0);
%
%     plotij(2,2,1,2)
%     [p,anovatab,stats] = anovan(EMG_var_all,{obs_var_all sw_var_all subject_var_all mus_var_all},'model',[1 1 0 0; 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1],'varnames',{'prevspost' 'narrowvswide' 'subject' 'muscle'},'display','off');
%     %[comparison,means,H,gnames]=multcompare(stats,'display','off')
%     xlim([0 1])
%     ylim([0 1])
%     axis off
%     t = text(0,1,sprintf('%1.6f\n',p));
%
%     plotij(2,2,2,1)
%     mnsdplot([pre_n_mn pre_n_sd; pre_w_mn pre_w_sd; post_n_mn post_n_sd; post_w_mn post_w_sd])
%     axis([0 5 -.1 .4])
%
% end
%
%
%
% % Plot
% for ii = 1:2
%     if ii==1
%         EMG_to_use = EMG_nobak;
%         EMG_100_450_to_use = EMG_nobak_100_450;
%         EMG_100_200_to_use = EMG_nobak_100_200;
%     else
%         EMG_to_use = EMG;
%         EMG_100_450_to_use = EMG_100_450;
%         EMG_100_200_to_use = EMG_100_200;
%     end
%
%     % Examine right leg muscles for 180��perturbations, left leg muscles for 0�
%     % perturbations. Make an identical plot assuming background removal and no
%     % background removal.
%     wordfigure([],11,17,8)
%     XL = [-0.1 0.6];
%     YL = [0 1];
%     t = (atime>=min(XL))&(atime<max(XL));
%     cmap = get(0,'defaultaxescolororder');
%     for i = 1:size(EMGID,1)
%
%         % Check for right leg muscle
%         if regexpi(EMGID(i,:),'-R')
%             pd = 180;
%         else
%             pd = 0;
%         end
%
%
%         plotij(16,4,i,1)
%         xlim(XL);
%         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,t))),'color',cmap(1,:),'clipping','off');
% %         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,t)))+squeeze(nanstd(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,t))),'linewidth','0.25','color',cmap(1,:),'clipping','off');
% %         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,t)))-squeeze(nanstd(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,t))),'linewidth','0.25','color',cmap(1,:),'clipping','off');
%         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,t))),'color',cmap(2,:),'clipping','off');
% %         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,t)))+squeeze(nanstd(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,t))),'linewidth','0.25','color',cmap(2,:),'clipping','off');
% %         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,t)))-squeeze(nanstd(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,t))),'linewidth','0.25','color',cmap(2,:),'clipping','off');
%         title(sprintf('%s, %d�, pretest',deblank(EMGID(i,:)),pd));
%         set(gca,'ylim',[0 max(get(gca,'ylim'))]);
%
%         plotij(16,4,i,2)
%         xlim(XL);
%         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==2)&(sw_scale_n0_w1==0),i,t))),'color',cmap(1,:),'clipping','off');
%         plot(atime(t),squeeze(nanmean(EMG_to_use((direction==pd)&(obs==2)&(sw_scale_n0_w1==1),i,t))),'color',cmap(2,:),'clipping','off');
%         title(sprintf('%s, %d�, posttest',deblank(EMGID(i,:)),pd));
%         set(gca,'ylim',[0 max(get(gca,'ylim'))]);
%
%         plotij(16,4,i,3)
%         xlim([0 3])
%         set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%         title(sprintf('%s, %d�, 100-450 ms',deblank(EMGID(i,:)),pd));
%
%         narrowpreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,atime>0.1&atime<0.45),3)),1));
%         narrowpostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG_to_use((direction==pd)&(obs==2)&(sw_scale_n0_w1==0),i,atime>0.1&atime<0.45),3)),1));
%         widepreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG_to_use((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,atime>0.1&atime<0.45),3)),1));
%         widepostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG_to_use((direction==pd)&(obs==2)&(sw_scale_n0_w1==1),i,atime>0.1&atime<0.45),3)),1));
%         plot(1:2,[narrowpreEMG_100_450 narrowpostEMG_100_450],'color',cmap(1,:));
%         plot(1:2,[widepreEMG_100_450 widepostEMG_100_450],'color',cmap(2,:));
%
%         plotij(16,4,i,4)
%         xlim([0 3])
%         %     ylim([0 100])
%         set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%         title(sprintf('%s, %d deg, 100-450 ms, % Narrow',deblank(EMGID(i,:)),pd));
%
%         plot(1:2,100*[narrowpreEMG_100_450 narrowpostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'color',cmap(1,:));
%         plot(1:2,100*[widepreEMG_100_450 widepostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'color',cmap(2,:));
%     end
% end
%
%
%
%
% return
%
%
% % Examine right leg muscles for 180��perturbations, left leg muscles for 0�
% % perturbations.
% wordfigure([],11,17,8)
% XL = [0 1];
% YL = [0 1];
% for i = 1:size(EMGID,1)
%
%     % Check for right leg muscle
%     if regexpi(EMGID(i,:),'-R')
%         pd = 180;
%     else
%         pd = 0;
%     end
%
% %     % Isolate EMG.
% %     narrow_pre_trials = (direction==pd)&(obs==1)&(sw_scale_n0_w1==0);
% %     wide_pre_trials = (direction==pd)&(obs==1)&(sw_scale_n0_w1==1);
% %
% %     narrow_post_trials = (direction==pd)&(obs==2)&(sw_scale_n0_w1==0);
% %     wide_post_trials = (direction==pd)&(obs==2)&(sw_scale_n0_w1==1);
% %
% %     % Normalize EMG.
% %     narrow_pre_EMG = squeeze(EMG_nobak(narrow_pre_trials,i,:));
% %     narrow_post_EMG = squeeze(EMG_nobak(narrow_post_trials,i,:));
% %     wide_pre_EMG = squeeze(EMG_nobak(wide_pre_trials,i,:));
% %     wide_post_EMG = squeeze(EMG_nobak(wide_post_trials,i,:));
% %
% %     narrow_pre_EMG = narrow_pre_EMG./max(nanmean(narrow_pre_EMG));
% %     narrow_post_EMG = narrow_post_EMG./max(nanmean(narrow_post_EMG));
% %     wide_pre_EMG = wide_pre_EMG./max(nanmean(narrow_pre_EMG));
% %     wide_post_EMG = wide_post_EMG./max(nanmean(narrow_post_EMG));
% %
% %     plotij(16,3,i,1)
% %     xlim(XL);
% %     ylim(YL);
% %     plot(atime,[nanmean(narrow_pre_EMG);nanmean(wide_pre_EMG)]);
% %
% %     plotij(16,3,i,2)
% %     xlim(XL);
% %     ylim(YL);
% %     plot(atime,[nanmean(narrow_post_EMG);nanmean(wide_post_EMG)]);
% %
%     plotij(16,3,i,2)
%
%     % Watch out - remove the background removal code, etc.
%
%     plotij(16,3,i,1)
%     xlim(XL);
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,:))));
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,:))),'r');
%     title(sprintf('%s, %d deg, pretest',deblank(EMGID(i,:)),pd));
%     plotij(16,3,i,2)
%     xlim(XL);
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==2)&(sw_scale_n0_w1==0),i,:))));
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==2)&(sw_scale_n0_w1==1),i,:))),'r');
%     title(sprintf('%s, %d deg, posttest',deblank(EMGID(i,:)),pd));
%
%     plotij(16,3,i,3)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-450 ms',deblank(EMGID(i,:)),pd));
%
%     narrowpreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(sw_scale_n0_w1==0),i,atime>0.1&atime<0.45),3)),1));
%     narrowpostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(sw_scale_n0_w1==0),i,atime>0.1&atime<0.45),3)),1));
%     widepreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(sw_scale_n0_w1==1),i,atime>0.1&atime<0.45),3)),1));
%     widepostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(sw_scale_n0_w1==1),i,atime>0.1&atime<0.45),3)),1));
%     plot(1:2,[narrowpreEMG_100_450 narrowpostEMG_100_450],'k');
%     plot(1:2,[widepreEMG_100_450 widepostEMG_100_450],'r');
%
%     plotij(16,3,i,3)
%     xlim([0 3])
%     ylim([0 100])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-450 ms, % Narrow',deblank(EMGID(i,:)),pd));
%
%     plot(1:2,100*[narrowpreEMG_100_450 narrowpostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'k');
%     plot(1:2,100*[widepreEMG_100_450 widepostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'r');
%
% end
%
%
%
%
%
%
%
%
%
% 7+3
%
% % Examine right leg muscles for 180��perturbations, left leg muscles for 0�
% % perturbations, pretest.
% wordfigure([],11,17,6)
% XL = [0 1];
% YL = [0 0.8];
% for i = 1:size(EMGID,1)
%
%     % Check for right leg muscle
%     if regexpi(EMGID(i,:),'-R')
%         pd = 180;
%     else
%         pd = 0;
%     end
%
%     for j = 1:4
%         triallookup = (direction==pd)&(obs==1)&(sw_n1_m2_ss3_w4==j);
%         plotij(16,4,i,j)
%         xlim(XL);
%         ylim(YL);
%         plot(atime,squeeze(nanmean(EMG(triallookup,i,:))));
%         title(sprintf('%s, %d deg, %2.2f cm, pretest',deblank(EMGID(i,:)),pd,nanmean(stancewidth_calc_cm(triallookup))));
%     end
% end
%
%
%
% wordfigure([],11,17,6)
% XL = [0 1];
% YL = [0 0.8];
% for i = 1:size(EMGID,1)
%
%     % Check for right leg muscle
%     if regexpi(EMGID(i,:),'-R')
%         pd = 180;
%     else
%         pd = 0;
%     end
%
%     for j = 1:4
%         triallookup = (direction==pd)&(obs==2)&(sw_n1_m2_ss3_w4==j);
%         plotij(16,4,i,j)
%         xlim(XL);
%         ylim(YL);
%         plot(atime,squeeze(nanmean(EMG(triallookup,i,:))));
%         title(sprintf('%s, %d deg, %2.2f cm, posttest',deblank(EMGID(i,:)),pd,nanmean(stancewidth_calc_cm(triallookup))));
%     end
% end
%
%
%
%
% % Examine right leg muscles for 180��perturbations, left leg muscles for 0�
% % perturbations.
% wordfigure([],11,17,8)
% XL = [0 1];
% for i = 1:size(EMGID,1)
%
%     % Check for right leg muscle
%     if regexpi(EMGID(i,:),'-R')
%         pd = 180;
%     else
%         pd = 0;
%     end
%     plotij(16,4,i,1)
%     xlim(XL);
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow_vs_wide==0),i,:))));
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow_vs_wide==1),i,:))),'r');
%     title(sprintf('%s, %d deg, pretest',deblank(EMGID(i,:)),pd));
%     plotij(16,4,i,2)
%     xlim(XL);
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow_vs_wide==0),i,:))));
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow_vs_wide==1),i,:))),'r');
%     title(sprintf('%s, %d deg, posttest',deblank(EMGID(i,:)),pd));
%
%     plotij(16,4,i,3)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-450 ms',deblank(EMGID(i,:)),pd));
%
%     narrowpreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow_vs_wide==0),i,atime>0.1&atime<0.45),3)),1));
%     narrowpostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow_vs_wide==0),i,atime>0.1&atime<0.45),3)),1));
%     widepreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow_vs_wide==1),i,atime>0.1&atime<0.45),3)),1));
%     widepostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow_vs_wide==1),i,atime>0.1&atime<0.45),3)),1));
%     plot(1:2,[narrowpreEMG_100_450 narrowpostEMG_100_450],'k');
%     plot(1:2,[widepreEMG_100_450 widepostEMG_100_450],'r');
%
%     plotij(16,4,i,4)
%     xlim([0 3])
%     ylim([0 100])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-450 ms, % Narrow',deblank(EMGID(i,:)),pd));
%
%     plot(1:2,100*[narrowpreEMG_100_450 narrowpostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'k');
%     plot(1:2,100*[widepreEMG_100_450 widepostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'r');
%
% end
%
%
%
%
% XL = [0 1];
% for i = 1:size(EMGID,1)
%
%     % Check for right leg muscle
%     if regexpi(EMGID(i,:),'-R')
%         pd = 180;
%     else
%         pd = 0;
%     end
%
%     plotij(16,10,i,1)
%     xlim(XL);
%     hold on
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==0),i,:))));
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==1),i,:))),'r');
%     title(sprintf('%s, %d deg, pretest',deblank(EMGID(i,:)),pd));
%     hold on
%     plotij(16,10,i,2)
%     xlim(XL);
%     hold on
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==0),i,:))));
%     plot(atime,squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==1),i,:))),'r');
%     title(sprintf('%s, %d deg, posttest',deblank(EMGID(i,:)),pd));
%     hold on
%
%     plotij(16,10,i,3)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-450 ms',deblank(EMGID(i,:)),pd));
%     hold on
%
%     narrowpreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.1&atime<0.45),3)),1));
%     narrowpostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.1&atime<0.45),3)),1));
%     widepreEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.1&atime<0.45),3)),1));
%     widepostEMG_100_450 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.1&atime<0.45),3)),1));
%     plot(1:2,[narrowpreEMG_100_450 narrowpostEMG_100_450],'b');
%     plot(1:2,[widepreEMG_100_450 widepostEMG_100_450],'r');
%
%     plotij(16,10,i,4)
%     xlim([0 3])
%     ylim([0 100])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-450 ms, % Narrow',deblank(EMGID(i,:)),pd));
%     hold on
%     plot(1:2,100*[narrowpreEMG_100_450 narrowpostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'b');
%     plot(1:2,100*[widepreEMG_100_450 widepostEMG_100_450]./[narrowpreEMG_100_450 narrowpostEMG_100_450],'r');
%
%     %KCL additions below
%     plotij(16,10,i,5)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-200 ms',deblank(EMGID(i,:)),pd));
%     hold on
%     narrowpreEMG_100_200 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.1&atime<0.2),3)),1));
%     narrowpostEMG_100_200 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.1&atime<0.2),3)),1));
%     widepreEMG_100_200 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.1&atime<0.2),3)),1));
%     widepostEMG_100_200 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.1&atime<0.2),3)),1));
%     plot(1:2,[narrowpreEMG_100_200 narrowpostEMG_100_200],'b');
%     plot(1:2,[widepreEMG_100_200 widepostEMG_100_200],'r');
%
%     plotij(16,10,i,6)
%     xlim([0 3])
%     ylim([0 100])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 100-200 ms, % Narrow',deblank(EMGID(i,:)),pd));
%     hold on
%     plot(1:2,100*[narrowpreEMG_100_200 narrowpostEMG_100_200]./[narrowpreEMG_100_200 narrowpostEMG_100_200],'b');
%     plot(1:2,100*[widepreEMG_100_200 widepostEMG_100_200]./[narrowpreEMG_100_200 narrowpostEMG_100_200],'r');
%
%
%     plotij(16,10,i,7)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 200-300 ms',deblank(EMGID(i,:)),pd));
%     hold on
%     narrowpreEMG_200_300 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.2&atime<0.3),3)),1));
%     narrowpostEMG_200_300 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.2&atime<0.3),3)),1));
%     widepreEMG_200_300 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.2&atime<0.3),3)),1));
%     widepostEMG_200_300 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.2&atime<0.3),3)),1));
%     plot(1:2,[narrowpreEMG_200_300 narrowpostEMG_200_300],'b');
%     plot(1:2,[widepreEMG_200_300 widepostEMG_200_300],'r');
%
%     plotij(16,10,i,8)
%     xlim([0 3])
%     ylim([0 100])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 200-300 ms, % Narrow',deblank(EMGID(i,:)),pd));
%     hold on
%     plot(1:2,100*[narrowpreEMG_200_300 narrowpostEMG_200_300]./[narrowpreEMG_200_300 narrowpostEMG_200_300],'b');
%     plot(1:2,100*[widepreEMG_200_300 widepostEMG_200_300]./[narrowpreEMG_200_300 narrowpostEMG_200_300],'r');
%
%
%     plotij(16,10,i,9)
%     xlim([0 3])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 200-300 ms',deblank(EMGID(i,:)),pd));
%     hold on
%     narrowpreEMG_300_400 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.3&atime<0.4),3)),1));
%     narrowpostEMG_300_400 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==0),i,atime>0.3&atime<0.4),3)),1));
%     widepreEMG_300_400 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==1)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.3&atime<0.4),3)),1));
%     widepostEMG_300_400 = squeeze(nanmean(squeeze(nanmean(EMG((direction==pd)&(obs==2)&(narrow0_vs_wide1_vs_SS2==1),i,atime>0.3&atime<0.4),3)),1));
%     plot(1:2,[narrowpreEMG_300_400 narrowpostEMG_300_400],'b');
%     plot(1:2,[widepreEMG_300_400 widepostEMG_300_400],'r');
%
%     plotij(16,10,i,10)
%     xlim([0 3])
%     ylim([0 100])
%     set(gca,'xtick',[1 2],'xticklabel',{'pretest','posttest'})
%     title(sprintf('%s, %d deg, 300-400 ms, % Narrow',deblank(EMGID(i,:)),pd));
%     hold on
%     plot(1:2,100*[narrowpreEMG_300_400 narrowpostEMG_300_400]./[narrowpreEMG_300_400 narrowpostEMG_300_400],'b');
%     plot(1:2,100*[widepreEMG_300_400 widepostEMG_300_400]./[narrowpreEMG_300_400 narrowpostEMG_300_400],'r');
% end
%
%
% 7+3
%
% % Calculate narrow-wide over narrow over a 100-450 ms window. These should
% % be repeated in a SAS PROC SORT step, or appended to a separate dataset,
% % because the number of observations is changing. SAS would treat this as a
% % seperate dataset, therefore.
% for obs_i = 1:2
%     for subject_i = 1:9
%         for mus_i = 1:16
%             EMG_Narrow_100_450 = nan(18,Nmus);
%             EMG_Wide_100_450 = nan(18,Nmus);
%             EMG_Scaling_100_450 = nan(18,Nmus);
%         end
%     end
% end
%
%
%
% % Copy these additional variables to the output dataset.
%
%
%
%
%
%
%
%
%
% % Load Platform kinematics from each trial.
%
% % Load CoM kinematics from each trial.
%
%
% % Load EMG from each trial and append as a unique variable.
%
%
%
%
%
%
%
%
%
%
%
%
%
% 7+3
%
%
%
%
%
%
%
%
% %STOP HERE
%
%
%
% % Interpolate all analog data to a common "analog" timebase, atime.
% atime = -0.5:(1/1080):2-(1/1080);
%
% % Interpolate marker data to a common "marker" timebase, mtime.
% mtime = -0.5:(1/1080):2-(1/1080);
%
%
% % Load Platform kinematics from each trial.
%
% % Load CoM kinematics from each trial.
%
%
% % Load EMG from each trial and append as a unique variable.
%
%
%
% % Load each file.
%
% % Timestamp dataset creation
% datecreated = clock();
%
% end
%
%
%
%
%










function [pertonset_rec_s, pertonset_calc_s, pertdir_calc_deg, pertdisp_calc_cm, pertvel_calc_cm_s, pertacc_calc_g, stancewidth_calc_cm] = calculatetrialdata(filename)

% Load data.
load(filename,'rawData','platonset','Accels','LVDT','atime','mtime','Velocity')

% Missing markers are set to zero. For markers numerically equal to zero,
% set to NaN. Note that the raw data markers must be used, here -
% otherwise, the filtering introduces artifacts when markers appear and
% disappear.
Markers = rawData.video.markers;
for i = 1:size(Markers,1)
    for j = 1:25
        if (Markers(i,j,1)==0)&(Markers(i,j,2)==0)&(Markers(i,j,3)==0)
            Markers(i,j,:)=nan;
        end
    end
end

% Save old perturbation onset, if any.
try
    pertonset_rec_s = platonset;
catch
    pertonset_rec_s = nan;
end

% Calculate perturbation onset time from recorded data.
try
    Accel_along_axis = (Accels(:,1).^2 + Accels(:,2).^2).^0.5;
    [pertonset_calc_s,~] = calculateperturbationonset(Accel_along_axis,atime);
catch
    pertonset_calc_s = nan;
end

% Calculate perturbation direction from recorded data.
try
    % Subtract off first sample.
    Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
    
    % Determine maximum absolute displacement to calculate perturbation
    % direction. Note that this is required because the platform may be
    % returning at the end of the trial.
    [DisplacementTH,DisplacementR] = cart2pol(Displacement(:,1),Displacement(:,2));
    DisplacementTH = DisplacementTH*180/pi;
    [peakdisp, temp] = max(DisplacementR);
    pertdir_calc_deg = DisplacementTH(temp);
    pertdir_calc_deg(pertdir_calc_deg<0) = pertdir_calc_deg(pertdir_calc_deg<0)+360;
catch
    pertdir_calc_deg = nan;
end

% Calculate peak perturbation displacement, velocity, and acceleration from recorded data.
try
    % Calculate displacement in direction of perturbation. For ease of reading,
    % the zeroing procedure is included again.
    Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
    DisplacementPD = Displacement(:,1)*cosd(pertdir_calc_deg) + Displacement(:,2)*sind(pertdir_calc_deg);
    pertdisp_calc_cm = max(DisplacementPD);
catch
    pertdisp_calc_cm = nan;
end

try
    % Calculate velocity in direction of perturbation.
    Velocity = Velocity - repmat(Velocity(1,:),size(Velocity,1),1);
    VelocityPD = Velocity(:,1)*cosd(pertdir_calc_deg) + Velocity(:,2)*sind(pertdir_calc_deg);
    pertvel_calc_cm_s = max(VelocityPD);
catch
    pertvel_calc_cm_s = nan;
end

try
    % Calculate acceleration in direction of perturbation.
    Acceleration = Accels - repmat(Accels(1,:),size(Accels,1),1);
    AccelerationPD = Acceleration(:,1)*cosd(pertdir_calc_deg) + Acceleration(:,2)*sind(pertdir_calc_deg);
    pertacc_calc_g = max(AccelerationPD);
catch
    pertacc_calc_g = nan;
end

% Calculate stance width as average distance between the heel markers
% during the first 0.25 seconds. Note that this is calculated as a vector
% norm, so should work if the subject is facing a different direction.
% Markers are in mm, so divide by 10 for cm.
try
    stancewidth_calc_cm = 0.1*norm(mean(squeeze(Markers(mtime<0.25,24,:)) - squeeze(Markers(mtime<0.25,18,:))));
catch
    stancewidth_calc_cm = nan;
end

end

function [perturbationonset,onsetind] = calculateperturbationonset(Accels,atime)
% function [perturbationonset] = calculateperturbationonset(trialdata)
%
% J. Lucas McKay, Ph.D.
% 3 April 2013
% MOdified 23 Apr, 2013 by SAC to match variable names to my data
%
% This method recalculates perturbation onset based on a threshold applied
% to acceleration magnitude. It has only been validated on A-P trials of
% certain magnitudes!
%
% JA says this code works for multidirectional perturbations 2014 9 10
% (KCL)
%
% Copied into createinterpolatedbalancedataset.m by JLM, 2014-09-26. Note
% that there is a bug in the code (uncorrected here - does not affect
% function) that bkgdsd = bkgdmn.

% calculate the sample at which the acceleration hits 6SD.
bkgdmn = nanmean(Accels(atime<0.25));
accelmag = abs(Accels(:)-bkgdmn);

bkgdmn = nanmean(accelmag(atime<0.25));
bkgdsd = nanmean(accelmag(atime<0.25));

% onsetind = find(accelmag>bkgdmn+l1*bkgdsd,1,'first');
% onsetind = find(accelmag(1:onsetind)<bkgdmn+l2*bkgdsd,1,'last');
onsetind = find(accelmag>bkgdmn+0.016,1,'first');

% add a sample offset to the identified onset sample to account for the
% average 10 ms lag between the acceleration zero crossing and the
% threshold crossing.
onsetind = onsetind - 15;
perturbationonset = atime(onsetind);

end

function out = interpolatetrialdata(filename,interptime_s,perturbation_onset_s)
% function data = interpolatetrialdata(filename,interptime_s,perturbation_onset_s)
%
% This function interpolates the time basis of a given trial onto the
% timepoints given in interptime_s.
%
% modified and simplifed from interpolatetrial.m
%
% J. Lucas McKay, Ph.D.
% 2014 09 29

% Load trial file to identify number of EMG records.
load(filename);

% Load anything that you'd like to directly transfer over.
out.mass = mass;

% Pick EMG data to load; e.g., EMG records that have names coded as EMG_X,
% where X is a character, not a number.
EMGinds = find(cell2mat(regexpi(cellstr(EMGID),'EMG_\D')));
out.EMGID = EMGID(EMGinds,:);

% Express all time samples wrt calculated platform onset.
atimewrtplat = atime-perturbation_onset_s;
mtimewrtplat = mtime-perturbation_onset_s;

% Interpolate the recorded EMG signals to the appropriate times.
out.EMG = nan(1,length(EMGinds),length(interptime_s));
out.EMGraw = out.EMG;
out.EMGrect = out.EMG;

for i = 1:length(EMGinds)
    out.EMG(1,i,:) = interp1(atimewrtplat,EMG(:,EMGinds(i)),interptime_s,'linear');
    out.EMGraw(1,i,:) = interp1(atimewrtplat,rawData.analog.emg(:,EMGinds(i)),interptime_s,'linear');
    tempEMGrect = highpassrectifyEMG(rawData.analog.emg(:,EMGinds(i)));
    out.EMGrect(1,i,:) = interp1(atimewrtplat,tempEMGrect,interptime_s,'linear');
end

% Interpolate plate data. This data is arranged as trials by pos/vel/accel
% by xy by samples. pos is in units of cm, vel is in units of cm/s, and
% accel is in units of g.
out.Plate = nan(1,3,2,length(interptime_s));
out.PlateID = PlateID;
for k = 1:2
    out.Plate(1,1,k,:) = interp1(atimewrtplat,LVDT(:,k),interptime_s,'linear');
    out.Plate(1,2,k,:) = interp1(atimewrtplat,Velocity(:,k),interptime_s,'linear');
    out.Plate(1,3,k,:) = interp1(atimewrtplat,Accels(:,k),interptime_s,'linear');
end

% Interpolate GRF data. This data is arranged as trials by dimension (RT
% Fx, RT Fy, RT Fz, RT Mx, RT My, RT Mz, LF Fx, LF Fy, LF Fz, LF Mx, LF My,
% LF Mz) by (singleton) by samples. It is in units of N and (assumed) N-m.
% Note that the units of moments are not typically examined and are therefore
% unknown.
out.GRF = nan(1,12,1,length(interptime_s));
out.GRFID = ForcesID;
for j = 1:12
    out.GRF(1,j,1,:) = interp1(atimewrtplat,GRF(:,j),interptime_s,'linear');
end

% Interpolate COM estimates from markers. Data are trials by pos/vel/accel
% by x-y-z by time samples. Units are cm, cm/s, and g, according to the
% proc_batch trial files. All estimates are with respect to the platform.
out.COMmarkers = nan(1,3,3,length(interptime_s));
out.COMunits = data.calculated.com.units;
for k = 1:3
    out.COMmarkers(1,1,k,:) = interp1(mtimewrtplat,data.calculated.com.markers.relative.pos(:,k),interptime_s,'linear');
    out.COMmarkers(1,2,k,:) = interp1(mtimewrtplat,data.calculated.com.markers.relative.vel(:,k),interptime_s,'linear');
    out.COMmarkers(1,3,k,:) = interp1(mtimewrtplat,data.calculated.com.markers.relative.acc(:,k),interptime_s,'linear');
end

% Interpolate COM estimates from force plate data. Organization is the same
% as in COMplate. All estimates are with respect to the platform.
out.COMplate = nan(1,3,3,length(interptime_s));
for k = 1:3
    out.COMplate(1,1,k,:) = interp1(atimewrtplat,data.calculated.com.plate.relative.pos(:,k),interptime_s,'linear');
    out.COMplate(1,2,k,:) = interp1(atimewrtplat,data.calculated.com.plate.relative.vel(:,k),interptime_s,'linear');
    out.COMplate(1,3,k,:) = interp1(atimewrtplat,data.calculated.com.plate.relative.acc(:,k),interptime_s,'linear');
end

% % Output a copy of the COM kinematics you'd like to use.
% out.COMpos = nan(3,length(interptime_s));
% out.COMvel = nan(3,length(interptime_s));
% out.COMacc = nan(3,length(interptime_s));
% for k = 1:3
%     out.COMpos(k,:) = interp1(atimewrtplat,data.calculated.com.plate.relative.pos(:,k),interptime_s,'linear');
%     out.COMvel(k,:) = interp1(atimewrtplat,data.calculated.com.plate.relative.vel(:,k),interptime_s,'linear');
%     out.COMacc(k,:) = interp1(atimewrtplat,data.calculated.com.plate.relative.acc(:,k),interptime_s,'linear');
% end

% Interpolate COP data. This data is arranged as trials by dimension by
% (singleton) by samples. It is units of mm.
out.COP = nan(1,6,1,length(interptime_s));
out.COPID = COPID;
for k = 1:6
    out.COP(1,1,k,:) = interp1(atimewrtplat,COP(:,k),interptime_s,'linear');
end

% Pull the COM height from the output of proc_batch. Note that this is with
% respect to a frame on the platform - I have not checked whether it is
% at the level of the floor or at a different place on the calibration
% object. I need to do this (Jan 2, 2015).
out.COMh = data.calculated.com.markers.relative.offset(3);

end




function [EMG,EMGraw,EMGrect,COP,GRF,Plate,COMmarkers,COMplate] = interpolatetrial(filename,atime,mtime,perturbation_onset_s)
% function [EMG,EMGraw,EMGrect,COP,GRF,Plate,COMrelativemarkers,COMrelativeplate] = interpolatetrial(filename,atime,mtime,perturbation_onset_s)
%
% This function interpolates the time basis of a given trial onto the
% timepoints given in atime and mtime. Assuming sample rates of 1080 Hz for
% analog, and 120 Hz for video, if the desire is to record 2.5 second
% trials with 0.5 seconds before perturbation onset, examples would be:
%
% atime = -0.5:(1/1080):2-(1/1080);
%
% mtime = -0.5:(1/120):2-(1/120);
%
% Note that the LVDT, Velocity, and Acceleration signals from the platform
% are grouped into the variable "Plate," which is samples by pos/vel/accl
% by xy.
%
% Note that COMrelativemarkers and COMrelativeplate are both relative to
% the platform. However, COMrelativemarkers is calculated from kinematics,
% and COMrelativeplate is calculated from ground reaction forces. These
% variables are saved in individual trial files as
% data.calculated.com.markers.relative and
% data.calculated.com.plate.relative
%
% In each case, data are time samples by pos/vel/accel by x-y-z.
%
% In each case, data are in units of cm, cm/s, and g.
%
% If multiple trials are supplied in a cell array, they are concatenated
% along the first dimension.
%
% J. Lucas McKay, Ph.D.
% 19 December, 2012
%
% Last modified 3 April 2013
% Last modification: added custom calculation of perturbation onset. Unset
% with RECALCULATEPERTURBATIONONSET flag
%
% Last modified 29 September 2014
% Last modification: altered to process 1 trial at a time with
% externally-specified perturbation onset, for use in
% createinterpolatedbalancedataset.m

% Load trial file to identify number of EMG records.
load(filename);

% Make space for EMG data in the output.
out.EMG = nan(1,32,1,length(atime));
out.EMGraw = nan(1,32,1,length(atime));
out.EMGrect = nan(1,32,1,length(atime));



% The number of trials:
Ntrials = 1;

% Interpolate EMG. This data is arranged as trials by muscles by
% (singleton) by samples.
EMG = nan(Ntrials,16,1,length(atime));
EMGraw = nan(Ntrials,16,1,length(atime));
EMGrect = nan(Ntrials,16,1,length(atime));

% Interpolate plate data. This data is arranged as trials by pos/vel/accel
% by xy by samples. pos is in units of cm, vel is in units of cm/s, and
% accel is in units of g.
Plate = nan(Ntrials,3,2,length(atime));

% Interpolate GRF data. This data is arranged as trials by dimension (RT
% Fx, RT Fy, RT Fz, RT Mx, RT My, RT Mz, LF Fx, LF Fy, LF Fz, LF Mx, LF My,
% LF Mz) by (singleton) by samples. It is in units of N and (assumed) N-m.
% Note that the units of moments are not typically examined and are therefore
% unknown.
GRF = nan(Ntrials,12,1,length(atime));

% Interpolate COP data. This data is arranged as trials by dimension by
% (singleton) by samples. It is units of mm.
COP = nan(Ntrials,6,1,length(atime));

% Interpolate COM estimates from markers. Data are trials by pos/vel/accel
% by x-y-z by time samples. Units are cm, cm/s, and g, according to the
% proc_batch trial files.
COMmarkers = nan(Ntrials,3,3,length(mtime));

% Interpolate COM estimates from force plate data. Organization is the same
% as in COMplate.
COMplate = nan(Ntrials,3,3,length(atime));


% Loop through, interpolate, and concatenate.
for i = 1:Ntrials
    
    % Load trial data.
    trialdata = load(filename);
    
    trialdata.platonset = perturbation_onset_s;
    
    % Express all time samples wrt calculated platform onset.
    atimewrtplat = trialdata.atime-trialdata.platonset;
    mtimewrtplat = trialdata.mtime-trialdata.platonset;
    
    for j = 1:16
        EMG(i,j,1,:) = interp1(atimewrtplat,trialdata.EMG(:,j),atime,'linear');
        EMGraw(i,j,1,:) = interp1(atimewrtplat,trialdata.rawData.analog.emg(:,j),atime,'linear');
        tempEMGrect = highpassrectifyEMG(trialdata.rawData.analog.emg(:,j));
        EMGrect(i,j,1,:) = interp1(atimewrtplat,tempEMGrect,atime,'linear');
    end
    
    for k = 1:2
        Plate(i,1,k,:) = interp1(atimewrtplat,trialdata.LVDT(:,k),atime,'linear');
        Plate(i,2,k,:) = interp1(atimewrtplat,trialdata.Velocity(:,k),atime,'linear');
        Plate(i,3,k,:) = interp1(atimewrtplat,trialdata.Accels(:,k),atime,'linear');
    end
    
    for j = 1:12
        GRF(i,j,1,:) = interp1(atimewrtplat,trialdata.GRF(:,j),atime,'linear');
    end
    
    for k = 1:3
        COMmarkers(i,1,k,:) = interp1(mtimewrtplat,trialdata.data.calculated.com.markers.relative.pos(:,k),mtime,'linear');
        COMmarkers(i,2,k,:) = interp1(mtimewrtplat,trialdata.data.calculated.com.markers.relative.vel(:,k),mtime,'linear');
        COMmarkers(i,3,k,:) = interp1(mtimewrtplat,trialdata.data.calculated.com.markers.relative.acc(:,k),mtime,'linear');
    end
    
    for k = 1:3
        COMplate(i,1,k,:) = interp1(atimewrtplat,trialdata.data.calculated.com.plate.relative.pos(:,k),atime,'linear');
        COMplate(i,2,k,:) = interp1(atimewrtplat,trialdata.data.calculated.com.plate.relative.vel(:,k),atime,'linear');
        COMplate(i,3,k,:) = interp1(atimewrtplat,trialdata.data.calculated.com.plate.relative.acc(:,k),atime,'linear');
    end
    
    for k = 1:6
        COP(i,1,k,:) = interp1(atimewrtplat,trialdata.COP(:,k),atime,'linear');
    end
    
    EMGID = trialdata.EMGID;
    PlateID = trialdata.PlateID;
    COPID = trialdata.COPID;
    GRFID = trialdata.ForcesID;
    COMID = 7;
    mass = trialdata.mass;
    % com_h_cm = nanmean(trialdata.data.calculated.com.markers.relative.pos(:,3));
    
end


end

function emg = highpassrectifyEMG(EMG)

SampleRate = 1080;

nyquist_frequency = SampleRate/2;

%%% Create filters
% High pass filter at 35 Hz
[filt_high_B,filt_high_A] = butter(3,35/nyquist_frequency,'high');
% Low pass filter at 40 Hz
[filt_low_B,filt_low_A] = butter(3,40/nyquist_frequency,'low');

%%% Filter EMG signals

% High pass filter at 35 Hz
emg = filtfilt(filt_high_B, filt_high_A,EMG);

% Demean and rectify
emg = abs(demean(emg));

end





