function []=transobj(h,xtrans,ytrans)
% function []=transobj(h,xtrans,ytrans)
% This functioon translates the graphics in the vector of handles h by the
% translations (in units of the current figure) in xtrans and ytrans.

h=h(:);

for hand=1:length(h)
	try
	temp=get(h(hand),'XData');
	set(h(hand),'XData',temp+xtrans);
	temp=get(h(hand),'YData');
	set(h(hand),'YData',temp+ytrans);
	catch
	temp=get(h(hand),'Position');
	set(h(hand),'Position',temp+[xtrans ytrans 0]);
	end
end

