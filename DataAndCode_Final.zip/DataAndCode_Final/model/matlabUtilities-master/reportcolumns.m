function out = reportcolumns(in,validn)
% function out = reportcolumns(in,validn)
% 
% reports (N) mean�sd for each column of the matrix in. 

if nargin<2
    validn = 0;
end

[nobs,nvars] = size(in);

N = nan(1,nvars);
mn = nan(1,nvars);
sd = nan(1,nvars);

out = nan(1,3*nvars);
for i = 1:nvars
    N(i) = sum(~isnan(in(:,i)));
    mn(i) = nanmean(in(:,i));
    sd(i) = nanstd(in(:,i));
end

out(1:3:end) = N;
out(2:3:end) = mn;
out(3:3:end) = sd;

end