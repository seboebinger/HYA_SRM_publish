function [dataout, indsout, logicalout] = subsection(datain,numsections,whichsection)
% function [dataout, indsout, logicalout] = subsection(datain,numsections,whichsection)
% 
% divide a data vector (a column) into "numsections" approximately equal subsections.

datalen = length(datain);
sectionlen = ceil(datalen/numsections);

sectionnum = nan(numsections*sectionlen,1);

for i = 1:numsections
	sectionnum((1:sectionlen)+(i-1)*sectionlen) = i;
end

logicalout = sectionnum==whichsection;
logicalout = logicalout(1:datalen);

dataout = datain(logicalout);
indsout = find(logicalout);

end