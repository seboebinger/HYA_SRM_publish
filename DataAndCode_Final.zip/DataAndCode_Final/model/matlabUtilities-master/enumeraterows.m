function output = enumeraterows(in)
% function out = enumeraterows(in)
%
% Displays a stack of string labels with row number enumerated, e.g.,
% enumeraterows(MarkerID)
% enumeraterows(EMGID)
%
% J. Lucas McKay, Ph.D.
% 5 April 2014
%
% Edit 2014-12-10
% If a matrix is supplied, it enumerates that, e.g., enumeraterows([vector1 vector2])

out = [];

if isnumeric(in)
    out = [(1:size(in,1))', in];
else
    
    for i = 1:size(in,1)
        out = strvcat(out,sprintf('%03d\t%s',i,deblank(in(i,:))));
    end
end

out

if nargout
    output = out;
end

end