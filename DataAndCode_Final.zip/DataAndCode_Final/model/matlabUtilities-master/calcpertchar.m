function [pertdirout,peakdispout,peakvelout,peakaccout,stancewout,filenameout] = calcpertchar(datadir,trialname,alltrials)
% function [pertdir, peakdisp, peakvel, peakacc, stancew, filenames] = calcpertchar(datadir,trialname,alltrials)
%
% This function calculates perturbation direction, peak displacement, peak
% velocity, peak acceleration, and an approximation of stance width (norm
% distance between heel markers) from recorded data.
%
% J. Lucas McKay, Ph.D.
% 30 November 2012

pertdirout = [];
peakdispout = [];
peakvelout = [];
peakaccout = [];
stancewout = [];
filenameout = [];

for trialcount = alltrials
    
    trial = [ensuretrailingfilesep(datadir) trialname num2str(trialcount,'%02d') '.mat'];
    filename = [trialname num2str(trialcount,'%02d') '.mat'];
    
    % Load the trial
    load(trial);
    
    % Code to preprocess plot data
    
    % Missing markers are set to zero. For markers numerically equal to zero,
    % set to NaN. Note that the raw data markers must be used, here -
    % otherwise, the filtering introduces artifacts when markers appear and
    % disappear.
    Markers = rawData.video.markers;
    for i = 1:size(Markers,1)
        for j = 1:25
            if (Markers(i,j,1)==0)&(Markers(i,j,2)==0)&(Markers(i,j,3)==0)
                Markers(i,j,:)=nan;
            end
        end
    end
    
    
    % Calculate perturbation direction from recorded data.
    
    % Subtract off first sample.
    Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
    
    % Determine maximum absolute displacement to calculate perturbation
    % direction. Note that this is required because the platform may be
    % returning at the end of the trial.
    [DisplacementTH,DisplacementR] = cart2pol(Displacement(:,1),Displacement(:,2));
    DisplacementTH = DisplacementTH*180/pi;
    [peakdisp, temp] = max(DisplacementR);
    pertdir = DisplacementTH(temp);
    pertdir(pertdir<0) = pertdir(pertdir<0)+360;
    
    % Calculate peak perturbation displacement, velocity, and acceleration from recorded data.
    
    % Calculate displacement in direction of perturbation. For ease of reading,
    % the zeroing procedure is included again.
    Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
    DisplacementPD = Displacement(:,1)*cosd(pertdir) + Displacement(:,2)*sind(pertdir);
    peakdisp = max(DisplacementPD);
    
    % Calculate velocity in direction of perturbation.
    Velocity = Velocity - repmat(Velocity(1,:),size(Velocity,1),1);
    VelocityPD = Velocity(:,1)*cosd(pertdir) + Velocity(:,2)*sind(pertdir);
    peakvel = max(VelocityPD);
    
    % Calculate acceleration in direction of perturbation.
    Acceleration = Accels - repmat(Accels(1,:),size(Accels,1),1);
    AccelerationPD = Acceleration(:,1)*cosd(pertdir) + Acceleration(:,2)*sind(pertdir);
    peakacc = max(AccelerationPD);
    
    
    % Calculate stance width as average distance between the heel markers
    % during the first 0.25 seconds. Note that this is calculated as a vector
    % norm, so should work if the subject is facing a different direction.
    % Markers are in mm, so divide by 10 for cm.
    stancewidth = 0.1*norm(nanmean(squeeze(Markers(mtime<0.25,24,:)) - squeeze(Markers(mtime<0.25,18,:))));
    
    pertdirout(end+1) = pertdir;
    peakdispout(end+1) = peakdisp;
    peakvelout(end+1) = peakvel;
    peakaccout(end+1) = peakacc;
    stancewout(end+1) = stancewidth;
    filenameout = strvcat(filenameout,trial);
end

end
