function [emgout,filenameout] = calcemgwindow(datadir,trialname,alltrials,window)
% function [emgout, filenames] = calcemgwindow(datadir,trialname,alltrials,window)
%
% This function calculates the average EMG magnitude in the given trials in
% the given window with respect to perturbation onset (in seconds). Output
% matrices are in units of recorded emg, # trials by # muscles.
%  
% J. Lucas McKay, Ph.D.
% 11 December 2012

emgout = [];
filenameout = [];

for trialcount = alltrials
    
    trial = [ensuretrailingfilesep(datadir) trialname num2str(trialcount,'%02d') '.mat'];
    filename = [trialname num2str(trialcount,'%02d') '.mat'];
    
    % Load the trial
    load(trial);

    % Calculate window w.r.t. platform onset
    windowonset = window+platonset;
    averageemg = nanmean(EMG(atime>=windowonset(1)&(atime<windowonset(2)),1:16));
    emgout(end+1,:) = averageemg;
    filenameout = strvcat(filenameout,[trial filename]);
end

end


%     % Code to preprocess plot data
%     
%     % Missing markers are set to zero. For markers numerically equal to zero,
%     % set to NaN. Note that the raw data markers must be used, here -
%     % otherwise, the filtering introduces artifacts when markers appear and
%     % disappear.
%     Markers = rawData.video.markers;
%     for i = 1:size(Markers,1)
%         for j = 1:25
%             if (Markers(i,j,1)==0)&(Markers(i,j,2)==0)&(Markers(i,j,3)==0)
%                 Markers(i,j,:)=nan;
%             end
%         end
%     end
%     
%     
%     % Calculate perturbation direction from recorded data.
%     
%     % Subtract off first sample.
%     Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
%     
%     % Determine maximum absolute displacement to calculate perturbation
%     % direction. Note that this is required because the platform may be
%     % returning at the end of the trial.
%     [DisplacementTH,DisplacementR] = cart2pol(Displacement(:,1),Displacement(:,2));
%     DisplacementTH = DisplacementTH*180/pi;
%     [peakdisp, temp] = max(DisplacementR);
%     pertdir = DisplacementTH(temp);
%     pertdir(pertdir<0) = pertdir(pertdir<0)+360;
%     
%     % Calculate peak perturbation displacement, velocity, and acceleration from recorded data.
%     
%     % Calculate displacement in direction of perturbation. For ease of reading,
%     % the zeroing procedure is included again.
%     Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
%     DisplacementPD = Displacement(:,1)*cosd(pertdir) + Displacement(:,2)*sind(pertdir);
%     peakdisp = max(DisplacementPD);
%     
%     % Calculate velocity in direction of perturbation.
%     Velocity = Velocity - repmat(Velocity(1,:),size(Velocity,1),1);
%     VelocityPD = Velocity(:,1)*cosd(pertdir) + Velocity(:,2)*sind(pertdir);
%     peakvel = max(VelocityPD);
%     
%     % Calculate acceleration in direction of perturbation.
%     Acceleration = Accels - repmat(Accels(1,:),size(Accels,1),1);
%     AccelerationPD = Acceleration(:,1)*cosd(pertdir) + Acceleration(:,2)*sind(pertdir);
%     peakacc = max(AccelerationPD);
%     
%     
%     % Calculate stance width as average distance between the heel markers
%     % during the first 0.25 seconds. Note that this is calculated as a vector
%     % norm, so should work if the subject is facing a different direction.
%     % Markers are in mm, so divide by 10 for cm.
%     stancewidth = 0.1*norm(nanmean(squeeze(Markers(mtime<0.25,24,:)) - squeeze(Markers(mtime<0.25,18,:))));
    
%     pertdirout(end+1) = pertdir;
%     peakdispout(end+1) = peakdisp;
%     peakvelout(end+1) = peakvel;
%     peakaccout(end+1) = peakacc;
%     stancewout(end+1) = stancewidth;
%     filenameout = strvcat(filenameout,trial);
