function h = hline(times)
% function h = hline(values)

handle = nan(length(times),1);
for i = 1:length(times)
	handle(i) = plot(get(gca,'xlim'),times(i)*[1 1],'k-');
end

if nargout
	h = handle;
end
end