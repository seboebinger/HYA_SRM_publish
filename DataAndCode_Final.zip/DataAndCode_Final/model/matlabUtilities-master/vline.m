function h = vline(times)
% function h = vline(times)

handle = nan(length(times),1);
for i = 1:length(times)
	handle(i) = plot(times(i)*[1 1],get(gca,'ylim'),'k-');
end

if nargout
	h = handle;
end
end