function out = thresh(in,t)
if nargin<2
    t=0;
end
out = in;
out(out<t) = t;
end