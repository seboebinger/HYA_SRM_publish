function [] = dispCommas(in,N)
% function [] = dispCommas(in,N)
% 
% Display the 2D matrix in as a comma-separated text file.

if nargin<2
	N = 3;
end

[ni,nj] = size(in);

out = [];

for i = 1:ni
	tempStr = [];

	for j = 1:nj
		if iscell(in)
			if isnumeric(in{i,j})
				tempStr = [tempStr,num2str(in{i,j},N)];
			else
				tempStr = [tempStr,in{i,j}];
			end
		else
			if ~isnan(in(i,j))
				tempStr = [tempStr,num2str(in(i,j),N)];
			else
				tempStr = [tempStr,' '];
			end
		end
		
		if j<nj
			tempStr = [tempStr,','];
		end
	end
	
	out = strvcat(out,tempStr);
end

disp(out)
end
