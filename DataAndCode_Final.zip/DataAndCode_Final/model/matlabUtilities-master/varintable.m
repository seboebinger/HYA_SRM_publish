function out = varintable(varname,inputtable)
out = any(strcmp(varname,inputtable.Properties.VariableNames));
end