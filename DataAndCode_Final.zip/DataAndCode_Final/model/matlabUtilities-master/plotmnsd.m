function h = plotmnsd(varargin)

if nargin==1
    data = varargin{1};
    mn = nanmean(data);
    sd = nanstd(data);
elseif nargin==2
    mn = varargin{1};
    sd = varargin{2};
end

b = bar(1:size(mn,2),mn);
set(b,'facecolor',0.5*[1 1 1]);
set(b,'barwidth',0.6);

l = [];
for i = 1:size(mn,2)
    l(end+1) = line(i*[1 1],mn(i)+sd(i)*[-1 1],'clipping','off');
    set(l(end),'color',[0 0 0])
end

if nargout
    h = [b(:); l(:)];
end
end