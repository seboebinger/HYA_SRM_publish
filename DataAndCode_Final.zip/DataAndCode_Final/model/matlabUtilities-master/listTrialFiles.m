function files = listTrialFiles(varargin)

p = inputParser;
addOptional(p,'folder',[]);
addOptional(p,'fileName',"Trial");
addOptional(p,'fileExtension',".mat");
parse(p,varargin{:});

folder = string(p.Results.folder);
fileName = string(p.Results.fileName);
fileExtension = string(p.Results.fileExtension);

% check for empty folder
if isempty(folder)
	folder = string(uigetdir());
end

% check for trailing file separator
if ~endsWith(folder,"+")
	folder = folder+filesep;
end

% check for leading dot
if ~startsWith(fileExtension,".")
	fileExtension = "."+fileExtension;
end

% list files that match spec
dirList = dir(folder+fileName+"*"+fileExtension);
files = sortrows(struct2table(dirList),'datenum');
files(files.isdir,:) = [];
files.isdir = [];
end
