function [out,uniquevalues,uniqueflags] = minacrossliketrials(in,flags)
% function [out,uniquevalues,uniqueflags] = minacrossliketrials(in,flags)
% 
% this is a very unique method. given some data in (with trials along the
% rows) and a matrix of flags flags, it performs the min operation across
% like trials and returns a matrix the size of the data in.
% 
% NB: behavior is only determined for 1 variable. If you supply something
% like [mn sd] for "in," nanmin will probably give you the minimum mn and
% the minimum sd across like trials, not the minimum mn and the sd
% corresponding to the minimum mn.

[uniqueflags, ~, ~] = unique(flags,'rows');

Nobs = size(in,1);
Nvars = size(in,2);
Nflags = size(flags,2);
Nunique = size(uniqueflags,1);

out = nan(size(in));
uniquevalues = nan(Nunique,Nvars);

for i = 1:Nunique

    % isolate the rows matching this unique set
    LIA = ismember(flags,uniqueflags(i,:),'rows');
    
    tempdata = in(LIA,:);
    tempout = nanmin(tempdata,[],1);
    
    uniquevalues(i,:) = tempout;
    
    out(LIA,:) = tempout;   
    
end

end