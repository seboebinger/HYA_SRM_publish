function [prefix,out1,out2] = removesuffix(combined,suffix)
% function uniqueprefix = removesuffix(combined,suffix)
% 
% function [uniqueprefix, extractedprefix, extractedsuffix] = removesuffix(combined,suffix)

if ischar(suffix)
	suffix = {suffix};
end

lc = length(combined);
ls = length(suffix);

extractedprefix = cell(1,lc);
extractedsuffix = cell(1,lc);

% find each suffix (note performance is only guaranteed for the last suffix
% in the chain)
for i = 1:ls
	extractedsuffix(endsWith(combined,suffix(i))) = suffix(i);
end

% extract the rest of the prefix using a cell function for speed
extractedprefix = cellfun(@(in1,in2) in1(1:end-length(in2)),combined,extractedsuffix,'UniformOutput',false);

% return only the unique prefixes, return in order of appearance.
prefix = unique(extractedprefix,'stable');

if nargout>1
	out1 = extractedprefix;
end
if nargout>2
	out2 = extracedsuffix;
end


end
 