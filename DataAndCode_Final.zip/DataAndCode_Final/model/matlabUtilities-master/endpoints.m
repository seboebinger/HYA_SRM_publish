function out = endpoints(in)
out = in([find(in,1) find(in,1,'last')]);
end