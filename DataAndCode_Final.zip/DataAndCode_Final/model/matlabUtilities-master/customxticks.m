function [] = customxticks(xt,labelvals)
% function [] = customxticks(tickvals,labelvals)
% 
% usage: customxticks([1:10],[1 5 10])


xtl = cell(size(xt));
for i = 1:length(labelvals)
    xtl(xt==labelvals(i))={num2str(labelvals(i))};
end
set(gca,'xtick',xt,'xticklabel',xtl)

end
