function table_out = averagetablerows(table_in,varstoaverageover,varstoaverage)
% function table_out = averagetablerows(table_in,varstoaverageover,varstoaverage)
% JLM, 2016-05-27

% average across unique values of variables listed in "varstoaverageover"
table_out = grpstats(table_in,varstoaverageover,'mean','DataVars',varstoaverage);

% record the number of rows
Nrows_in = size(table_in,1);
Nrows_out = size(table_out,1);

% delete the count variable if the counts are high enough to average.
if min(table_out.GroupCount)<3
    warning('averaging across table rows: minimum number of observations < 3')
else
    table_out.GroupCount = [];
end

% delete the row names
table_out.Properties.RowNames={};

% rename the variables that were averaged over
outnames = table_out.Properties.VariableNames(end-length(varstoaverage)+1:end);

for i = 1:length(varstoaverage)
   table_out.Properties.VariableNames{outnames{i}}=varstoaverage{i}; 
end




