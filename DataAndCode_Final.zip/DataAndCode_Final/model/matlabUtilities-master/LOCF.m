function LOCFdata = LOCF(data)


[nsubs,nobs] = size(data);

for i = 2:nobs
    data(:,[i-1 i]) = locf_sub(data(:,[i-1 i]));
end

LOCFdata = data;

end

function out = locf_sub(in)

out = in;
out(isnan(out(:,2)),2) = out(isnan(out(:,2)),1);

end
