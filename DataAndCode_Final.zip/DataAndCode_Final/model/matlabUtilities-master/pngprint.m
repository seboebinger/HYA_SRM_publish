function [] = pngprint(handle,filename)
% function [] = pngprint(handle,filename)
% 
% prints the figure to a png file, suitable for websites.

if nargin<3
	width = 500;
end

if nargin<2
	filename = [];
end

if nargin<1
	handle = gcf;
elseif isempty(handle)
	handle = gcf;
end

if isempty(filename)
	filename = [filename sprintf('figure%d',handle)];
end

disp(sprintf('Printing Figure %d to .png: Ticks may change.',handle));

[pathstr,name,ext] = fileparts(filename);

if isempty(pathstr)
	printname = name;
else
	printname = [pathstr filesep name];
end

print(['-f' num2str(handle)],'-loose','-dpng',[printname '.png']);
eval(['!open ' printname '.png'])
