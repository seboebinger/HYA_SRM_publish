function [magnitude_dB, frequency_Hz] = psd_welch(atime_s,signals)
% function [magnitude_dB, frequency_Hz] = psd_welch(atime_s,signals)
% function [magnitude_dB, frequency_Hz] = psd_welch(fs_Hz,signals)

if length(atime_s)>1
    fs_Hz = 1./(atime_s(2)-atime_s(1));
else
    atime_s = 0:1/fs_Hz:5-1/fs_Hz;
end

% default parameters based on those provided for a 1 second 1000 Hz signal
% at https://www.mathworks.com/help/signal/ref/pwelch.html
seglen = round(length(atime_s)*0.5);
overlaplen = round(length(atime_s)*0.3);
dftlen = round(length(atime_s)*0.3);

[pxx,frequency_Hz] = pwelch(signals,seglen,overlaplen,dftlen,fs_Hz);
magnitude_dB = 10*log10(pxx);

% figure
% plot(f,10*log10(pxx))
% 
% xlabel('Frequency (Hz)')
% ylabel('Magnitude (dB)')
