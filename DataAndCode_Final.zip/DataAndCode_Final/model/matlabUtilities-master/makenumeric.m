function datasetout = makenumeric(datasetin,varnames)
% function datasetout = makenumeric(datasetin,varnames)
%
% Make the given variables in the dataset datasetin numeric, replacing any
% missing values with nan.
%
% J. Lucas McKay, Ph.D.
% 28 October, 2013


% if nargin<3
%    sysmisscode = '#NULL!'
% end

% copy all of the variables in the old dataset over to the new dataset.
datasetout = datasetin;

for i = 1:length(varnames)
    data = datasetin.(varnames{i});
    if iscell(data)
        % if the variable is a cell, overwrite it with nan. when there is a
        % numeric value available, use it; otherwise impute nan.
        newdata = nan(length(data),1);
        for j = 1:length(data)
            if isnumeric(data{j})
                newdata(j) = data{j};
            end
        end
        datasetout.(varnames{i}) = newdata;
    end
end

end