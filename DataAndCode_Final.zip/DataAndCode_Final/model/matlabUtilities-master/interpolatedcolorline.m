function h = interpolatedcolorline(x,y,cmap)
% function h = interpolatedcolorline(x,y)
% 
% plots a line with color proportional to x-value.
% 
% function h = interpolatedcolorline(x,y,cmapstr)
% 
% specify the color map, e.g., 'bone','pink', etc.


if isempty(x)
    x = 0:.05:2*pi;
end
if isempty(y)
    y = sin(x);
end

if nargin<3
    cmap = 'bone';
end

if isempty(cmap)
    cmap = 'bone';
end

x = x(:)';
y = y(:)';

z = zeros(size(x));
col = x;  % This is the color, vary with x in this case.

handle = surface([x;x],[y;y],[z;z],[col;col],...
    'facecol','no',...
    'edgecol','interp',...
    'linew',2);

colormap(cmap);

if nargout
    h = handle;
end
end