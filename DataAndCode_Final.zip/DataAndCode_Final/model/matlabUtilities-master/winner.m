function out = winner(in,randflag)
if nargin<2
    randflag=0;
end
out = find(in==max(in));

if randflag
    if length(out)>1
        out = pickone(out);
    end
end
end