function out = halfwave(in)

out = in;
out(out<0) = 0;
end