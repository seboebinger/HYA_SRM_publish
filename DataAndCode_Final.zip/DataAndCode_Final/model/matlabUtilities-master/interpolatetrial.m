function [EMG,EMGraw,EMGrect,COP,GRF,Plate,COMmarkers,COMplate] = interpolatetrial(filename,atime,mtime)
% function [EMG,EMGraw,EMGrect,COP,GRF,Plate,COMrelativemarkers,COMrelativeplate] = interpolatetrial(filename,atime,mtime)
% 
% This function interpolates the time basis of a given trial onto the
% timepoints given in atime and mtime. Assuming sample rates of 1080 Hz for
% analog, and 120 Hz for video, if the desire is to record 2.5 second
% trials with 0.5 seconds before perturbation onset, examples would be:
% 
% atime = -0.5:(1/1080):2-(1/1080);
% 
% mtime = -0.5:(1/120):2-(1/120);
% 
% Note that the LVDT, Velocity, and Acceleration signals from the platform
% are grouped into the variable "Plate," which is samples by pos/vel/accl
% by xy.
% 
% Note that COMrelativemarkers and COMrelativeplate are both relative to
% the platform. However, COMrelativemarkers is calculated from kinematics,
% and COMrelativeplate is calculated from ground reaction forces. These
% variables are saved in individual trial files as
% data.calculated.com.markers.relative and
% data.calculated.com.plate.relative
% 
% In each case, data are time samples by pos/vel/accel by x-y-z.
% 
% In each case, data are in units of cm, cm/s, and g. 
% 
% If multiple trials are supplied in a cell array, they are concatenated
% along the first dimension.
% 
% J. Lucas McKay, Ph.D.
% 19 December, 2012
% 
% Last modified 3 April 2013
% Last modification: added custom calculation of perturbation onset. Unset
% with RECALCULATEPERTURBATIONONSET flag


% The number of trials:
Ntrials = size(filename,1);

% Interpolate EMG. This data is arranged as trials by muscles by
% (singleton) by samples.
EMG = nan(Ntrials,16,1,length(atime));
EMGraw = nan(Ntrials,16,1,length(atime));
EMGrect = nan(Ntrials,16,1,length(atime));

% Interpolate plate data. This data is arranged as trials by pos/vel/accel
% by xy by samples. pos is in units of cm, vel is in units of cm/s, and
% accel is in units of g.
Plate = nan(Ntrials,3,2,length(atime));

% Interpolate GRF data. This data is arranged as trials by dimension (RT
% Fx, RT Fy, RT Fz, RT Mx, RT My, RT Mz, LF Fx, LF Fy, LF Fz, LF Mx, LF My,
% LF Mz) by (singleton) by samples. It is in units of N and (assumed) N-m.
% Note that the units of moments are not typically examined and are therefore
% unknown.
GRF = nan(Ntrials,12,1,length(atime));

% Interpolate COP data. This data is arranged as trials by dimension by
% (singleton) by samples. It is units of mm.
COP = nan(Ntrials,6,1,length(atime));

% Interpolate COM estimates from markers. Data are trials by pos/vel/accel
% by x-y-z by time samples. Units are cm, cm/s, and g, according to the
% proc_batch trial files.
COMmarkers = nan(Ntrials,3,3,length(mtime));

% Interpolate COM estimates from force plate data. Organization is the same
% as in COMplate.
COMplate = nan(Ntrials,3,3,length(atime));


RECALCULATEPERTURBATIONONSET = 0;

% Loop through, interpolate, and concatenate.
for i = 1:Ntrials

    % Load trial data.
    trialdata = load(filename{i,1});
    
    if RECALCULATEPERTURBATIONONSET
        trialdata.platonset = calculateperturbationonset(trialdata);
    end
    
    % Express all time samples wrt calculated platform onset.
    atimewrtplat = trialdata.atime-trialdata.platonset;
    mtimewrtplat = trialdata.mtime-trialdata.platonset;    
    
    for j = 1:16
        EMG(i,j,1,:) = interp1(atimewrtplat,trialdata.EMG(:,j),atime,'linear');
        EMGraw(i,j,1,:) = interp1(atimewrtplat,trialdata.rawData.analog.emg(:,j),atime,'linear');
        tempEMGrect = highpassrectifyEMG(trialdata.rawData.analog.emg(:,j));
        EMGrect(i,j,1,:) = interp1(atimewrtplat,tempEMGrect,atime,'linear');
    end
    
    for k = 1:2
        Plate(i,1,k,:) = interp1(atimewrtplat,trialdata.LVDT(:,k),atime,'linear');
        Plate(i,2,k,:) = interp1(atimewrtplat,trialdata.Velocity(:,k),atime,'linear');
        Plate(i,3,k,:) = interp1(atimewrtplat,trialdata.Accels(:,k),atime,'linear');
    end

    for j = 1:12
        GRF(i,j,1,:) = interp1(atimewrtplat,trialdata.GRF(:,j),atime,'linear');
    end
    
    for k = 1:3
       COMmarkers(i,1,k,:) = interp1(mtimewrtplat,trialdata.data.calculated.com.markers.relative.pos(:,k),mtime,'linear');
       COMmarkers(i,2,k,:) = interp1(mtimewrtplat,trialdata.data.calculated.com.markers.relative.vel(:,k),mtime,'linear');
       COMmarkers(i,3,k,:) = interp1(mtimewrtplat,trialdata.data.calculated.com.markers.relative.acc(:,k),mtime,'linear');
    end
    
    for k = 1:3
       COMplate(i,1,k,:) = interp1(atimewrtplat,trialdata.data.calculated.com.plate.relative.pos(:,k),atime,'linear');
       COMplate(i,2,k,:) = interp1(atimewrtplat,trialdata.data.calculated.com.plate.relative.vel(:,k),atime,'linear');
       COMplate(i,3,k,:) = interp1(atimewrtplat,trialdata.data.calculated.com.plate.relative.acc(:,k),atime,'linear');
    end
    
end

end