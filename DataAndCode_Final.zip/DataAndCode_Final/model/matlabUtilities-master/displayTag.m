function displayTag(src,~)

if src.UserData.DisplayTag
    delete(src.UserData.TagHandle);
	src.UserData.DisplayTag = false;
	return
else
	src.UserData.DisplayTag = true;
end

% identify the tag of the selected line
tag = src.UserData.Tag;

% identify the "parent" axis
ax = src.Parent;

% find the current point on the axis
cp = ax.CurrentPoint(1,1:2);

% create a text tag
t = text(cp(1),cp(2),char(tag));
t.Color = src.Color;
t.FontSize = 12;
t.UserData.side = 'right';
t.ButtonDownFcn = @deleteYourself;
if isfield(src.UserData,'DisplayTagFontSize')
	if ~isempty(src.UserData.DisplayTagFontSize);
		t.FontSize = src.UserData.DisplayTagFontSize;
	end
end

end

function deleteYourself(src,~)

delete(src);

end