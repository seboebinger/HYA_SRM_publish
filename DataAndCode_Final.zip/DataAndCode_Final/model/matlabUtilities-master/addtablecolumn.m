function tableout = addtablecolumn(tablein,varargin);
%
% function tableout = addtablecolumn(tablein,varname,varvalue);
%
% function tableout = addtablecolumn(tablein,varname1,varvalue1,varname2,varvalue2, etc.);
%
% add singleton column to a matlab table.
%
% one good usage is default values for fixed-width string variables:
% newtable = addtablecolumn(oldtable,'newstringvar1','   null   ')
%
% this is archaic but prevents a lot of casting between string, cell,
% categorical later, and 10 is the widest string width that will display at
% the command line.
%
% J. Lucas McKay, Ph.D., M.S.C.R.
% 2016 06 23

nrows = size(tablein,1);

for i = 1:2:length(varargin)
    
    tablein(:,end+1) = table(repmat(varargin{i+1},nrows,1));
    
    tablein.Properties.VariableNames{end} = varargin{i};
    
end


tableout = tablein;

end



