function sorted = sortby(unsorted,thingtosortby)
% function sorted = sortby(unsorted,thingtosortby)
% j. lucas mckay, ph.d., m.s.c.r.
% 2016 05 03

[~,i] = sort(thingtosortby);
sorted = unsorted(i,:);
end
