function varargout = dealcolumns(in)
% function [out1, out2, out3, ...] = dealcolumns(in)
% 
% deal each column of the matrix in to an output out1, out2, etc.
% 
% J. Lucas McKay, Ph.D.
% 
% 25 September 2012

for i = 1:nargout
    varargout{i} = in(:,i);
end

end


