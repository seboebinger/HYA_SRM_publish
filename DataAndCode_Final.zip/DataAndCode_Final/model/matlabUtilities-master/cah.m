% cah.m
% 
% calls "close all hidden"
close all hidden