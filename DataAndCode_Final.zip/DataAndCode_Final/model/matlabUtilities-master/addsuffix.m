function combined = addsuffix(prefix,suffix)
% function combined = addsuffix(prefix,suffix)
% 
% last edit: allow single string arguments to be cast as cell

if ischar(prefix)
	prefix = {prefix};
end
if ischar(suffix)
	suffix = {suffix};
end

lp = length(prefix);
ls = length(suffix);

combined = cell(1,lp*ls);
i = 0;
for s = 1:ls
	for p = 1:lp
		i = i+1;
		combined{i} = [prefix{p} suffix{s}];
	end
end

end
 