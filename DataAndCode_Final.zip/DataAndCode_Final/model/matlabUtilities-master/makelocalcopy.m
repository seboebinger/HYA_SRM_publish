function localnames = makelocalcopy(filenames)
% function localnames = makelocalcopy(filenames)
% 
% copies a stack of filenames from the server onto the local machine.
% 
% 
% filenames should be a cell array with each entry as follows:
% '/Volumes/ting/ting-data/neuromechanics-lab/rectus/RectusF/ProcessedData/NeuroLab/ParkinsonDisease/PDP04/Session 1/Trial35.mat'

srcdir = '/Volumes/ting/ting-data/neuromechanics-lab/rectus/RectusF/ProcessedData/NeuroLab/';
dstdir = '/Users/jlmckay/Research/Rectus/F/ProcessedData/Neurolab/';

localnames = cell(size(filenames));
for i = 1:length(filenames)
   srcfile = filenames{i};
   dstfile = [dstdir srcfile(length(srcdir)+1:end)];
   localnames(i) = {dstfile};
   % create a call to rsync
   evalstr = ['!rsync -avuz ' srcfile ' ' dstfile];
   % fix a bug wherein the "Session 1" folders should be specified as
   % "Session\ 1"
   evalstr = strrep(evalstr,'Session ','Session\ ');
   eval(evalstr)
end
