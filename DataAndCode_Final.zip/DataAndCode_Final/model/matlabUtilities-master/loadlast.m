function out = loadlast(name)

files = dir;
names = string({files.name}');
names = sort(names(contains(names,name)));

if isempty(names)
	disp(char(join(["File" q(string(name)) "not found in directory" q(string(pwd))])))
	return
end

file = names(end);

if nargout
	out = load(file);
else
	evalin('caller',char("load " + file));
end
end


function out = q(in)
	out = "'"+in+"'";
end