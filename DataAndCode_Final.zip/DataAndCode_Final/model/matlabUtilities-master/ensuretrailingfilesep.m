function out = ensuretrailingfilesep(in)
% function out = ensuretrailingfilesep(in)
% 
% This small function checks whether the last character of a file path
% matches the file separator on the system. If it doesn't, it adds one and
% returns it. Otherwise, it just returns the input argument.
% 
% J. Lucas McKay, Ph.D.
% 2 November 2012

% check whether last character matches the file sep. if it does, do
% nothing. if it doesn't, add it.
if strcmp(in(end),filesep)
    out = in;
else
    out = [in filesep];
end

end