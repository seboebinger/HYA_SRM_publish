function [] = dataplot(data,dataname,varargin)
% function [] = dataplot(data,dataname,factor1,factor1name,factor2,factor2name,...)

ndata = length(data(:));

switch (nargin)
    case 6
        % two factors with names
        factor1 = varargin{1};
        factor1name = varargin{2};
        factor2 = varargin{3};
        factor2name = varargin{4};
        nmarkers = length(unique(factor2));
    case 4
        % one factor with name
        factor1 = varargin{1};
        factor1name = varargin{2};
        nmarkers = 1;
    case 3
        % one factor, no name
        factor1 = varargin{1};
        factor1name = 'factor1';
        nmarkers = 1;
end

% Build the marker set
markerorder = {'x';'o';'s';'d';'^';'v'};
markers = cell(size(data));

if nmarkers == 1
    markers([1:ndata])={markerorder{1}};
else
    uniquef2 = unique(factor2)
    for j = 1:nmarkers
        markers(logical(factor2==uniquef2(j)))={markerorder{j}};
    end
end

if nmarkers == 1
    for i = 1:ndata
        p = line(factor1(i),data(i),'clipping','off');
        set(p,'linestyle','none','marker',markers{i},'color',[0 0 0]);
    end
else
    handles = [];
    xshift = 0.1;
    xoff = -xshift*((nmarkers-1)/2);
    
    for i = 1:ndata
        p = line(factor1(i)+xoff+xshift*(factor2(i)-1),data(i),'clipping','off');
        set(p,'linestyle','none','marker',markers{i},'color',[0 0 0]);
        handles(i) = p;
    end
    h = [];
    for j = 1:nmarkers
        h(j) = handles(find(factor2==uniquef2(j),1,'first'));
    end
end
xlim([min(factor1)-1 max(factor1)+1])
set(gca,'xtick',unique(factor1))
xlabel(factor1name)
ylabel(dataname)

if nmarkers>1
    legstr = cell(nmarkers,1);
    for j = 1:nmarkers
        legstr{j} = [factor2name ' = ' num2str(uniquef2(j))];
    end
    l = legend(h,legstr);
    set(l,'box','off')
end
 
% if nmarkers>1
%     for j = 1:nmarkers
%         markers(logical(factor2==uniquef2(j)))={markerorder{j}};
%     end    
% end

end