function out = pickone(in)
    numberofchoices = length(in);
    out = in(randi(numberofchoices));
end