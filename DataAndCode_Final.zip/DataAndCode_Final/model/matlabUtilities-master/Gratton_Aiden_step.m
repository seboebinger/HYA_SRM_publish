function [ceeg] = Gratton_Aiden_step(eeg,eog,flags)
% Gratton and Coles 1983 for Aiden's Cortical Activity in Balance EEG data.
    % take the raw (or filtered EEG) and make a list of trial starts 
    % shifted by and platform onset and a corresponding list of event
    % codes.
      
    crit = 20; win = 200;
    yl = [-70 50];
    
   % flags = temp_flags;
    %eeg = temp_eeg;
    %eog = temp_eog;
    neeg = eeg;
    neog = eog;
% (a) Raw averaging
    % sort ERPs starting at each trial start, sorted by each event code
    [r, c]= size(flags);
    for x = 1:r
        if c==4
            inds = find(flags(:,1) == flags(x,1) & flags(:,2) == flags(x,2) & flags(:,3) == flags(x,3) & flags(:,4) == flags(x,4));
        elseif c==3
            inds = find(flags(:,1) == flags(x,1) & flags(:,2) == flags(x,2) & flags(:,3) == flags(x,3) );
         elseif c==2
            inds = find(flags(:,1) == flags(x,1) & flags(:,2) == flags(x,2) );
        elseif c==1
            inds = find(flags(:,1) == flags(x,1));       
        end
       % take each trial, and subtract from it the mean of that condition
       neeg(x,:) = neeg(x,:) - mean(eeg(inds,:));
       neog(x,:) = neog(x,:) - mean(eog(inds,:));
       % and subtract the mean within the trial
       % (b) Subtraction of the raw average from the single trial data
            %for each condition, subtract the mean from the individual trials
       neeg(x,:) = neeg(x,:) - mean(neeg(x,:));
       neog(x,:) = neog(x,:) - mean(neog(x,:));
       eeg(x,:) = eeg(x,:) - mean(eeg(x,:));
       eog(x,:) = eog(x,:) - mean(eog(x,:));
    end
    
 
% (c) Correction factor
    % consider EEG data as a dependent variable in a regression computation
    % in which teh EOG data is the independent variable
 
    %just going to run the gratton function on the data from the step after
    %raw averaging and subtracting the mean
    
%    ceeg = gratton(eeg,eog,20, 20);
    
% (d) Separation of blinks and eye movements
 
 
% (e) Averaging
 
 
 
%function ceeg = gratton( eeg, eog, crit, win );
 
%if nargin < 2
%   help gratton;
%   return;
%end;
 
[ times trials] = size(eeg);
el = 1;
ceeg = eeg;
assert(all([times trials] == size(eog)), 'bad input data dimensions');
 
% I have already subtracted the condition mean from each trial
%avg = mean(eeg, 3); % avg trials
%neeg = eeg - repmat(avg, [1 1 trials]);
%neog = eog - repmat(mean(eog, 2), [1 trials]);
 
% detect blinks
winhalf = round(win/2);
blinks = logical(zeros(size(eog)));
%blinks(winhalf+1:end-winhalf,:) = ((2*eog(winhalf+1:end-winhalf,:)-(eog(1:end-win,:)+eog(win+1:end,:)))>crit);
blinks(:,winhalf+1:end-winhalf) = ((2*eog(:,winhalf+1:end-winhalf)-(eog(:,1:end-win)+eog(:,win+1:end)))>crit); %aiden
% blinks = ((eog-circshift(eog, [winhalf 0]))+...
%     (eog-circshift(eog, [-winhalf 0])))>crit;
disp(sprintf('  gratton(): Found blinks in %i points', length(find(blinks>0))));
 
% loop through electrodes and get the K's
Kblinks = []; % coefficients within blinks
K = [];       % coefficients outside blinks
x = neog(:);
b = logical(blinks(:));
 
% correction within blinks if appropriate
if any(any(blinks))
    % only doing one electrode
    y = neeg(:);
    Kblinks = [Kblinks regress(y(b), x(b))];
%     for e = 1:el
%         y = reshape(neeg(e,:,:), [times trials]);
%         y = y(:);
%         Kblinks = [Kblinks regress(y(b), x(b))];
%     end;
    disp(' gratton(): Coefficients within blinks:');
    disp(Kblinks);
    minus = Kblinks.*neog;
    ceeg(blinks) = eeg(blinks)-minus(blinks);
    %minus = (repmat(Kblinks', [1 times trials]).*shiftdim(repmat(eog, [1 1 el]), 2));
    %ceeg(blinks) = eeg(blinks) - minus(blinks);
    %avg = mean(ceeg, 3); % avg trials
    %neeg = ceeg - repmat(avg, [1 1 trials]);
    
    for xx = 1:length(flags)
       % and subtract the mean within the trial
       neeg(xx,:) = ceeg(xx,:) - mean(ceeg(xx,:));
       %neog(x,:) = neog(x,:) - mean(neog(x,:));
    end
    
    disp(' gratton(): Corrected EEG within blinks');
end;
 
% correction outside of blinks
% only one electrode
    y = neeg(:);
    K = [K regress(y, x)];
% for e = 1:el
%     y = reshape(neeg(e,:,:), [times trials]);
%     y = y(:);
%     K = [K regress(y, x)];
% end;
 
disp(' gratton(): Coefficients outside of blinks:');
disp(K);
ceeg = ceeg -K.*neog; % because only one electrode, only one K
%ceeg = ceeg - (repmat(K', [1 times trials]).*shiftdim(repmat(eog, [1 1 el]), 2));
disp(' gratton(): Corrected EEG outside of blinks');
 
end

