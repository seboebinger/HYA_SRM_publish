function gaincheck(Folder,Filename,nTrans)
% GainCheck:     Creates scaled graphs of EMG signals for each transmitter for proper gain verification
%
% Syntax: gaincheck(Folder,Filename,Trial)
%
% Input:
% Folder        String      Name of folder that contains C3D file to be examined
% Filename      String      Full file name of C3D file to be read 
% nTrans        Integer     number of transmitters to check (optional,
%                           default = 4)
%
% Calls:
% procanalog.m      This file processes C3D data and saves in a MAT file
%
% Output:       Displays two graphs -- one for each transmitter -- with EMG signals for gain verification
%
% Created: August 3, 2004 (Ting group)
% Modified: February 18, 2005 (Torrence Welch)
%                modified for compatibility with new procc3d.m routine
%           June 17, 2013 (Jessica Allen)
%               modified for compatibility with proc_read (in proc20130125)
%               changed ylim on plots to be min/max of channel data
%               added EMG names to plot
%           June 24, 2013 (Jessica Allen)
%               added functionality to plot more than 32 channels (e.g. in
%               case non-emg is innappropriately placed in to
%               rawData.analog.emg)
%               added option to specify how many transmitters were used
%               (default is 4)

if nargin < 3
    nTrans = 4;
end


% READ IN C3D FILE (added, JLA 6/17/13)
fname = ['D:\ViconData\NeuroLab\' Folder, '\', Filename];
rawData = proc_read([fname '.c3d']);

for j=1:nTrans
    figure('units','inches','position',[j-1 0 5 10]);
    for i=1:8
        subplot(8,1,i)
        hold on
        plot(rawData.analog.emg(:,i+(j-1)*8));
        if strmatch('EMG',rawData.analog.emgid(i+(j-1)*8,:))
            ylabel(rawData.analog.emgid(i+(j-1)*8,5:end),'interpreter','none');
        else
            ylabel(rawData.analog.emgid(i+(j-1)*8,:),'interpreter','none');
        end
        ylim([min(rawData.analog.emg(:,i+(j-1)*8)) max(rawData.analog.emg(:,i+(j-1)*8))]);
    end
end

% figure('units','inches','position',[1 0 5 10]);
% for j=1:8
%     subplot(8,1,j)
%     hold on
%     plot(rawData.analog.emg(:,8+j));
%     ylabel(rawData.analog.emgid(8+j,5:end),'interpreter','none');
%     ylim([min(rawData.analog.emg(:,8+j)) max(rawData.analog.emg(:,8+j))]);
% end
% 
% if nTrans > 2
% figure('units','inches','position',[3 0 5 10]);
% for j=1:8
%     subplot(8,1,j)
%     hold on
%     plot(rawData.analog.emg(:,16+j));    
%     ylabel(rawData.analog.emgid(16+j,5:end),'interpreter','none');
%     ylim([min(rawData.analog.emg(:,16+j)) max(rawData.analog.emg(:,16+j))]);
% end
% 
% figure('units','inches','position',[4 0 5 10]);
% for j=1:8
%     subplot(8,1,j)
%     hold on
%     plot(rawData.analog.emg(:,24+j));
%     ylabel(rawData.analog.emgid(24+j,5:end),'interpreter','none');
%     ylim([min(rawData.analog.emg(:,24+j)) max(rawData.analog.emg(:,24+j))]);
% end

if size(rawData.analog.emg,2) > (nTrans*8)

    figure('units','inches','position',[4 0 5 10]);
    for j=1:size(rawData.analog.emg,2)-(nTrans*8)
        subplot(8,1,j)
        hold on
        plot(rawData.analog.emg(:,(nTrans*8)+j));
        if strmatch('EMG',rawData.analog.emgid((nTrans*8)+j,:))
            ylabel(rawData.analog.emgid((nTrans*8)+j,5:end),'interpreter','none');
        else
            ylabel(rawData.analog.emgid((nTrans*8)+j,:),'interpreter','none');
        end            
        ylim([min(rawData.analog.emg(:,(nTrans*8)+j)) max(rawData.analog.emg(:,(nTrans*8)+j))]);
    end

end
    
    

