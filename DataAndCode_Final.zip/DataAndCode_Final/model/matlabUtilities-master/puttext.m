function h = puttext(location,str)
% function h = puttext(location,string)

xl = get(gca,'xlim');
yl = get(gca,'ylim');
switch location
	case 1
		% top right
		t = text(xl(2),yl(2),str);
		set(t,'horizontalalignment','right');
		set(t,'verticalalignment','top');
end

h = t;