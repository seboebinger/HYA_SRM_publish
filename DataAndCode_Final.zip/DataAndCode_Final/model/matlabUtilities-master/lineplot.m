function h = lineplot(time,data,string,color,style)
% function h = lineplot(xdata,ydata,string,color,style)

if nargin<5
	style = '-';
end

endi = find(~isnan(data),1,'last');
h = line(time,data,'clipping','off','color',color,'linestyle',style);

if ~isempty(string)
	t = text(time(endi),data(endi),string);
	set(t,'color',color,'horizontalalignment','left','verticalalignment','baseline')
	h = [h(:)' t(:)'];
end

end
