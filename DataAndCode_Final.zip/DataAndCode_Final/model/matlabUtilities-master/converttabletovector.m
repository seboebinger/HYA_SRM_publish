function outtable = converttabletovector(intable,varargin)
% outtable = converttabletovector(intable,'var1','var2',...)
%
% outtable = converttabletovector(intable,{'var1','var2',...})
%
% Convert character variables in a table (e.g., '1, 2, 4', or '3..6', or '18-47')
% to numerical vector variables for easier indexing. Possible examples include
% enumerating bad trials, or blocks of trials of a given condition.
%
% J. Lucas McKay
% 30 July 2015

if (length(varargin{1})>1)
    vars = varargin{1};
else
    vars = varargin;
end

% Loop through variables
for varnum = 1:length(vars)
    
    % Save a copy of the original variable
    originalvar = intable{:,vars{varnum}};
    newvar = cell(size(originalvar));
    
    % Loop through the rows of the original variable
    for rownum = 1:length(originalvar)
        rowstring = originalvar{rownum};

        % Delete semicolons, commas, brackets.
        rowstring = strrep(rowstring,';',' ');        
        rowstring = strrep(rowstring,',',' ');        
        rowstring = strrep(rowstring,'{',' ');        
        rowstring = strrep(rowstring,'}',' ');        
        rowstring = strrep(rowstring,'[',' ');        
        rowstring = strrep(rowstring,']',' ');        

        % Alter english conventions for range, e.g., -, --, .., to the Matlab
        % character, :
        rowstring = strrep(rowstring,'--',':');
        rowstring = strrep(rowstring,'-',':');
        rowstring = strrep(rowstring,'..',':');
        
        rowrange = eval(['[' rowstring ']']);
        
        newvar{rownum} = rowrange;
    end
    intable(:,vars{varnum}) = newvar;
end

outtable = intable;

end

