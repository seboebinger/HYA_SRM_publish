function [] = owd()
% owd
% open the current working directory in the system environment.

s = pwd;

if ispc
	winopen(s);
end
if ismac
	eval("!open '" + s + "'");
end
end