% caca.m
close all hidden
clear all