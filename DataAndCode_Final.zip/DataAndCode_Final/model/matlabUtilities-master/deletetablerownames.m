function outtable = deletetablerownames(intable)
% function outtable = deletetablerownames(intable)

outtable = intable;
outtable.Properties.RowNames = {};

end