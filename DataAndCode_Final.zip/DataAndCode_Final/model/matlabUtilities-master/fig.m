function h = fig()
h = figure;

width = 8.5;
height = 11;

ScreenSize = get(0,'ScreenSize');
ScreenPixelsPerInch = get(0,'ScreenPixelsPerInch');

dim = [0 0 0 0];
dim(3) = floor(width*ScreenPixelsPerInch);
dim(4) = floor(height*ScreenPixelsPerInch);
temp = round(.5*(ScreenSize - dim));
dim([1 2]) = temp([3 4]);

set(h,'Position',dim);

fontsize = 10;
set(h,'defaultaxesfontsize',fontsize);
set(h,'defaulttextfontsize',fontsize);
end
