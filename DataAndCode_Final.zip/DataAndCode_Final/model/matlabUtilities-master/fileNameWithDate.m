function s = fileNameWithDate(varargin)
% function s = fileNameWithDate
% 
% function s = fileNameWithDate('baseString',"tempfile")
% function s = fileNameWithDate('extString',".mat")
% function s = fileNameWithDate('extString',".xlsx")

p = inputParser;
addOptional(p,'baseString',"tempfile");
addOptional(p,'dateString',defaultDateString);
addOptional(p,'extString',"");
parse(p,varargin{:});

baseString = string(p.Results.baseString);
dateString = string(p.Results.dateString);
extString = string(p.Results.extString);

if dateString~=""
	dateString = "_" + dateString;
end

if extString~=""
	if startsWith(extString,'.') == false
		extString = "." + extString;
	end
end

s = strtrim(baseString + dateString + extString);

end