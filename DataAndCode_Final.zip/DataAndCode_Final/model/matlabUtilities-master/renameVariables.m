function out = renameVariables(in,varargin)

p = inputParser;
p.addOptional('prefix',"");
p.addOptional('suffix',"");
p.addOptional('exclude',"");
p.addOptional('remove',"");
p.parse(varargin{:});

prefix = string(p.Results.prefix);
suffix = string(p.Results.suffix);
exclude = string(p.Results.exclude);
remove = string(p.Results.remove);

tempTable = in;
tempNames = string(tempTable.Properties.VariableNames);
tempNames(~ismember(tempNames,exclude)) = strrep(prefix + tempNames(~ismember(tempNames,exclude)) + suffix,remove,"");
tempTable.Properties.VariableNames = cellstr(tempNames);

out = tempTable;
end