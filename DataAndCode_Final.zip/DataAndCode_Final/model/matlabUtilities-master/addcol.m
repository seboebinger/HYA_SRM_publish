function col_out = addcol(table_in,str)
% col_out = repmat(str, size(table_in,1),1);
% 
% add a column of ones:
% anyTable.newVarible = addcol(anyTable,1)
% 
% add a column of empty strings:
% anyTable.newVarible = addcol(anyTable,"")

col_out = repmat(str, size(table_in,1),1);
end