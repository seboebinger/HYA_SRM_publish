function answer = quiz(N,type)
% function answer = quiz()
% Ask a math question.
%
% function answer = quiz(N)
% Ask N math questions.
%
% function answer = quiz(N,type)
% Ask N math questions of type "type."


if nargin==0
	N = 1;
end

if nargin>1
	QuestionType = type*ones(1,N);
else
	NumTypes = 3;
	QuestionType = randi(NumTypes,1,N);
end

for i = 1:N
	switch QuestionType(i)
		case 1
			% 1-20 division.
			nums = randi(20,1,1);
			nums(2) = randi(nums(1),1,1);
			Answer = input(['What''s ' num2str(nums(1)) ' divided by ' num2str(nums(2)) '? ']);
			Actual = nums(1)/nums(2);
		case 2
			% 1-20 multiplication.
			nums = randi(20,1,2);
			Answer = input(['What''s ' num2str(nums(1)) ' times ' num2str(nums(2)) '? ']);
			Actual = nums(1)*nums(2);
		case 3
			% Even "percent of" questions.
			p = [5:5:65];
			percent = p(randi(length(p),1));
			number = randi(1000,1);
			places = 10^randi([0 3],1);
			number = number*places;
			
			Answer = input(['What''s ' num2str(percent) ' percent of ' num2str(number) '? ']);
			Actual = percent*number/100;
		otherwise
	end
	
	Error = PercentOff(Answer,Actual);
	
	if Error==0
		DisplayString = 'You''re right!';
	elseif abs(Error)<=5
		DisplayString = 'You''re pretty close.';
	elseif (abs(Error)>5)&(abs(Error)<25)
		DisplayString = 'That must''ve been tough.';
	else
		DisplayString = 'Dude, WTF?';
	end
	DisplayString = [DisplayString ' It''s ' num2str(Actual) '.'];
	
	disp(' ')
	disp(DisplayString)
	disp(' ')

end

end

function Err = PercentOff(Answer,Actual)

Err = 100*(Answer-Actual)/Actual;

end