# Matlab Utilities
A collection of helper functions written by J. Lucas McKay, Ph.D., M.S.C.R. for data visualization and analysis in Matlab software. 
