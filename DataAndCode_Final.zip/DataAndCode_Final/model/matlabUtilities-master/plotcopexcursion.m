function [] = plotcopexcursion(datadir,trial,LABEL,SCALE)
% function [] = plotcopexcursion(datadir,trial,LABEL)
%
% created by J. Lucas McKay, Ph.D.
%
% sample arguments:
%
% datadir = '/Users/jlmckay/Research/Udall Pilot/Data/UP01/Session 1/'
% trial = 1
% LABEL = 'UP01'
% 
% plots the CoP excursion during the given trial.
% 
% function [] = plotcopexcursion(datadir,trial,LABEL,SCALE)
% to override default SCALE of [-10 10 cm]; 

% set scale
if nargin<4
    SCALE = 10*[-1 1];
end
xl = SCALE;
yl = SCALE;
    

if trial<10
    temp = load([datadir 'Trial0' num2str(trial)]);
else
    temp = load([datadir 'Trial' num2str(trial)]);
end

xlim(xl)
ylim(yl)
COP = demean(temp.COP(:,[1 2]));
stdev = nanstd(COP,0,1);
h = line(COP(:,1),COP(:,2),'clipping','off','color','k');
axis equal

p = line([0 stdev(1)],[0 0],'clipping','off','color','k');
transobj(p,SCALE(2)/2,SCALE(2)/2);
t = text(stdev(1),0,num2str(stdev(1),3));
transobj(t,SCALE(2)/2,SCALE(2)/2);

p = line([0 0],[0 stdev(2)],'clipping','off','color','k');
transobj(p,SCALE(2)/2,SCALE(2)/2);
t = text(0,stdev(2),num2str(stdev(2),3));
transobj(t,SCALE(2)/2,SCALE(2)/2);

title(LABEL)

end
