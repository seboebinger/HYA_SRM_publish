function handleout = labelaxis(txt)
% function handle = labelaxis(txt)

t = text(0.5, 0.5,txt);
t.FontSize = 16;
t.HorizontalAlignment = 'center';
axis off

if nargout>0
	handleout = t;
end

end
