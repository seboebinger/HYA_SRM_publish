function out = zeroout(in,sample)

if nargin==1
    sample = 1;
end

if length(sample)>1
    sample = find(sample);
end

out = in - repmat(in(:,sample),1,size(in,2));

end