function [] = plotprocemg(datadir,alltrials,MUSTOPLOT,LABEL,cmap,YSCALE,XSCALE)
% function [] = plotprocemg(datadir,trials,muscles,label,cmap)
%
% created by J. Lucas McKay, Ph.D.
%
% sample arguments:
%
% datadir = '/Users/jlmckay/Research/Udall Pilot/Data/UP01/Session 1/'
% trials = 1:171
% LABEL = 'UP01 ADAPTATION'
% 
% plots the activation of each muscle in the indicated trials in a separate
% figure.
% 
% function [] = plotprocemg(datadir,trials,muscles,label,cmap,YSCALE)
% overrides the default [-5V 0V] y-scale.
% 
% function [] = plotprocemg(datadir,trials,muscles,label,cmap,YSCALE,XSCALE)
% overrides the default [-0.4s 4.5s] x-scale.

if nargin>6
    xl = XSCALE;
else
    xl = [-0.4 4.5];
end
if nargin>5
    yl = YSCALE;
else
    yl = [-5 0];
end
    
for mus = MUSTOPLOT
    fig
    xlim(xl)
    ylim(yl)
    
    stepsize = diff(yl)/length(alltrials);
%     stepsize = diff(yl)/(max(alltrials)-min(alltrials));
    
    for trial_i = 1:length(alltrials)
        trial = alltrials(trial_i);
%         try
        if trial<10
            temp = load([datadir 'Trial0' num2str(trial)]);
        else
            temp = load([datadir 'Trial' num2str(trial)]);
        end
        temptime = temp.atime-temp.platonset;
        tempEMG = temp.EMG(:,1:16);
        MUS = temp.EMGID(1:16,5:end);
        
        yoffset = (trial_i-1)*-stepsize;
        h = lineplot(temptime,(tempEMG(:,mus))+yoffset,num2str(trial),cmap(trial_i,:));
%         catch
%             disp(['plotprocemg error, trial ' num2str(trial)])
%         end
    end
    h = labelfigure([LABEL ' EMG ' num2str(mus) ': ' deblank(MUS(mus,:)) ', V']);
    set(h,'fontsize',12)
    ylabel('V')
end

end
