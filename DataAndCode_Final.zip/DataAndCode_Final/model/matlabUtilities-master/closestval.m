function closest = closestval(list,val)
% function closest = closestval(list,val)
% 
% given a list of possible values, this function finds and returns the
% closest. so, closestval([12 24],23.6) returns 24.
% 
% for a list of perturbation directions, e.g., 0:30:330, be sure to supply
% the directions as 0:30:360 and correct the 360 values manually, as
% follows:
% 
% dirs = closestval(0:30:360,recordeddirs)
% dirs(dirs==360)=0
% 
% J. Lucas McKay, Ph.D.
% 7 December 2012

closest = interp1(list,list,val,'nearest','extrap');

end