function out = makecategorical(in)
% function out = makecategorical(in)
% 
% turns character arrays, cell arrays of strings, etc. into categorical
% arrays. note that this assumes that the input is one column.


datatype = nan;
if iscategorical(in)
    datatype = 'categorical';
end

if iscell(in)
    datatype = 'cell';
end

if ischar(in)
    datatype = 'char';
end


7+3

datatype = categorical(cellstr(datatype))
if datatype=='cell'
    % fill in empty entries
    in(cellfun(@isempty,in)) = repmat({'---null---'});
end

end