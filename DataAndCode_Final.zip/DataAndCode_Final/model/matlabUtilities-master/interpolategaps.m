function [out,fillflag] = interpolategaps(in,gapval)
% function out = interpolategaps(in,gapval)
% function [out,fllflag] = interpolategaps(in,gapval)
% 
% linearly interpolate gaps. use with caution, no gaplen measures provided.
% expects a row vector.
% 
% J. Lucas McKay, Ph.D., M.S.C.R.
% 6 April 2017

% turn into row vector.
in = in(:)';

if nargin>1
    in(in==gapval) = nan;
end

blockindices = bwlabel(isnan(in));
blocks = unique(blockindices);
blockstarts = nan(size(blocks));
blockends = nan(size(blocks));
for i = 1:length(blocks)
    blockstarts(i) = find(blockindices==blocks(i),1,'first');
    blockends(i) = find(blockindices==blocks(i),1,'last');
end

gaps = table(blocks',blockstarts',blockends');
gaps.Properties.VariableNames = {'GapNum' 'GapStart' 'GapEnd'};
gaps(1,:) = [];
gaps.GapLen = gaps.GapEnd-gaps.GapStart+1;

% interpolate. for gaps in the middle of the record, linearly interpolate.
% for gaps at the beginning and end, interpolate the beginning or end
% value.
temp = cell2table(cell(size(gaps,1),2));
temp.Properties.VariableNames = {'InterpInds' 'InterpVals'};
gaps = [gaps temp];
for i = 1:size(gaps,1)
    % if gap is at the start
    if gaps.GapStart(i)==1
        gaps.InterpInds{i} = 1:gaps.GapEnd(i);
        gaps.InterpVals{i} = in(gaps.GapEnd(i)+1)*ones(1,gaps.GapLen(i));
    % if gap is at the end
    elseif gaps.GapEnd(i)==length(in)
        gaps.InterpInds{i} = length(in)-gaps.GapLen(i)+1:length(in);
        gaps.InterpVals{i} = in(gaps.GapStart(i)-1)*ones(1,gaps.GapLen(i));
    % else gap is in the middle
    else
        gaps.InterpInds(i) = {gaps.GapStart(i):gaps.GapEnd(i)};
        gaps.InterpVals(i) = {...
            interp1([gaps.GapStart(i)-1 gaps.GapEnd(i)+1],...
            in([gaps.GapStart(i)-1 gaps.GapEnd(i)+1]),...
            gaps.InterpInds{i})};
    end 
end

% populate output
filled = false(size(in));
for i = 1:size(gaps,1)
    in(gaps.InterpInds{i}) = gaps.InterpVals{i};
    filled(gaps.InterpInds{i}) = true;    
end

out = in;
if nargout>1
    fillflag = filled;
end

end