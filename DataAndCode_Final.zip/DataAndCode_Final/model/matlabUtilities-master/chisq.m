function pval_out = chisq(in)
% function chisq(in)
% wrapper around Matlab's fishertest.m and crosstab.m
%
% usage: chisq([3 4;7 9])
% usage: chisq([3 4 4;7 9 0])
% usage: p = chisq([3 4 4;7 9 0])
%
% no tests of assumptions are performed

sep = '    ';

T = array2table(in);
if all(size(T)<3)
	[h,p,stats] = fishertest(T);
	if ~nargout
		disp(sep)
		disp([sep 'Using fistertest.m'])
		disp(sep)
		disp([sep 'input data:'])
		disp(sep)
		disp(T)
		disp([sep 'P-value:'])
		disp(p)
		disp(stats)
	end
else
	C = cell(1,size(T,2));
	for i = 1:length(C)
		C{i} = T{:,i};
	end
	[t2,chi2,p]=crosstab(C{:});
	if ~nargout
		disp(sep)
		disp([sep 'Using crosstab.m'])
		disp(sep)
		disp([sep 'input data:'])
		disp(sep)
		disp(T)
		disp([sep 'P-value:'])
		disp(p)
	end
end

if nargout
	pval_out = p;
end

end