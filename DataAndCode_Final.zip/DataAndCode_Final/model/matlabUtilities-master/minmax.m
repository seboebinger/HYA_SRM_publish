function out = minmax(in)
% function out = minmax(in)
% 
% returns [nanmin(in(:)) nanmax(in(:))]

out = [nanmin(in(:)) nanmax(in(:))];

end