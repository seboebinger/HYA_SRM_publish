function [] = pdfbind(handles,filename)
% function [] = pdfbind(handles,filename)
% 
% Print the figures pointed at by "handles" to files, bind into a
% multi-page pdf named filename.
% 
% handles should be a vector of handles, such as [1 2 3] for figures 1-3.
% 
% Watch out! This script will overwrite anything in your directory named
% tempfigure*.
% 
% J. Lucas Mckay, 20 July 2010

% Isolate the path, etc, where you'd like the figures to go.	
[pathstr,name,ext] = fileparts(filename);

if nargin<1
	handles = gcf;
elseif isempty(handles)
	handles = gcf;
end

% Print each figure to a temporary .eps file and convert to pdf.
for i = 1:length(handles)
	tempname = sprintf('tempfigure%d',handles(i));
	
	if isempty(pathstr)
		printname = [tempname '.eps'];
	else
		printname = [pathstr filesep tempname '.eps'];
	end
	
	% Print to .eps.
	print(['-f' num2str(handles(i))],'-loose','-depsc2',printname);
	
end
 
% evalstr = ['!~/Research/Matlab\ R2009b/pdfall.sh'];
% eval(evalstr)
% 
% % Convert to pdf with the OS X epstopdf command-line utility.
% evalstr = ['!/sw/bin/epstopdf ' printname]
% eval(evalstr)
% 
% 
% % Convert each temporary .eps file to a pdf.
% 
% epstopdf figure12.eps

end
% 
% 
% 
% print(['-f' num2str(handle)],'-loose','-depsc2',[printname '.eps']);
% end
% 
% if isempty(filename)
% 	filename = [filename sprintf('figure%d',handle)];
% end
% 
% disp(sprintf('Printing Figure %d for Word: Ticks may change.',handle));
% % Future change: move through subplots and check if they have been set
% % manually.
% 
% [pathstr,name,ext] = fileparts(filename);
% 
% if isempty(pathstr)
% 	printname = name;
% else
% 	printname = [pathstr filesep name];
% end
% 
% print(['-f' num2str(handle)],'-loose','-depsc2',[printname '.eps']);
% eval(['!open ' printname '.eps'])
