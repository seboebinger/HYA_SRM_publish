function out = mnsd(in)
% function out = mnsd(in)
% out = [nanmean(in(:)) nanstd(in(:))];
out = [nanmean(in(:)) nanstd(in(:))];

end