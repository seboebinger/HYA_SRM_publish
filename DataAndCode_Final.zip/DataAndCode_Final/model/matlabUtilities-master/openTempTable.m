function out = openTempTable(T,varargin)

p = inputParser;
p.addOptional('WriteRowNames',false);
p.addOptional('WriteVariableNames',false);
p.addOptional('FileType','.xlsx');
p.parse(varargin{:});

fname = [tempname p.Results.FileType];

writetable(T,fname,'WriteVariableNames',p.Results.WriteVariableNames,'WriteRowNames',p.Results.WriteRowNames);
if ismac
eval(['!open ' fname])
end
if ispc
winopen(fname);
end

end