function out = rownum(in)
out = (1:size(in,1))';
end