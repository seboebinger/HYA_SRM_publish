function mn = timeaverage(data,flags,varargin)
% function mn = timeaverage(data,flags,col1vals,col2vals,col3vals,etc.)
% 
% J. Lucas McKay, Ph.D.
% 3 April 2013
% 
% outputs an n x 3 matrix, with columns of mean, mean-sd, mean+sd.

lookup = true(size(data,1),1);
for i = 1:length(varargin)
    lookup = lookup & ismember(flags(:,i),varargin{i});
end
mn = nanmean(data(lookup,:),1);
sd = nanstd(data(lookup,:),0,1);

mn = [mn(:) mn(:)-sd(:) mn(:)+sd(:)];

end