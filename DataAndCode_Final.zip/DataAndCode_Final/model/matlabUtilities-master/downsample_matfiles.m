function out = downsample_matfiles(varargin)
% function newnames = downsample_matfiles('selectsourcedirectory',true)
% function newnames = downsample_matfiles('selectdestdirectory',true)
% function newnames = downsample_matfiles('sourcedirectoryname',directoryname)
% function newnames = downsample_matfiles('destdirectoryname',directoryname)
% function newnames = downsample_matfiles('sourcefilenames',sourcefilenames)
% function newnames = downsample_matfiles('suffix',suffix_string)
% 
% usage:
% downsample_matfiles('selectsourcedirectory',true,'selectdestdirectory',true,'suffix',[])
% allows user to select source and destination directory, creates
% downsampled files with identical filenames to destination files.
% 
% downsample_matfiles('selectsourcedirectory',true)
% allows user to select source directory, creates files in the same
% directory with suffix '_downsampled', e.g., 'Trial01_downsampled.mat'
% 
% downsample_matfiles('selectsourcedirectory',true,'suffix','_d')
% allows user to select source directory, creates files in the same
% directory with suffix '_d', e.g., 'Trial01_d.mat' 
% 
% J. Lucas McKay, Ph.D., M.S.C.R.
% 2017 06 01

p = inputParser;
addOptional(p,'selectsourcedirectory',false);
addOptional(p,'selectdestdirectory',false);
addOptional(p,'sourcedirectoryname',[]);
addOptional(p,'destdirectoryname',[]);
addOptional(p,'sourcefilenames',{});
addOptional(p,'destfilenames',{});
addOptional(p,'suffix','_downsampled');
parse(p,varargin{:});

% identify source directory
if p.Results.selectsourcedirectory
    sourcedirectory = uigetdir('/~','Select Source Directory');
else
    sourcedirectory = p.Results.sourcedirectoryname;
end

% identify destination directory
if p.Results.selectdestdirectory
    destdirectory = uigetdir(sourcedirectory,'Select Destination Directory');
elseif ~isempty(p.Results.destdirectoryname)
    destdirectory = p.Results.destdirectoryname;
else
    destdirectory = sourcedirectory;
end

% identify .mat files to downsample (sourcefilenames)
sourcefilenames = p.Results.sourcefilenames;
if isempty(sourcefilenames)
    sourcefilenames = getmatfiles(sourcedirectory);
end

% identify destination .mat files (destfilenames)
destfilenames = p.Results.destfilenames;
if isempty(destfilenames)
    destfilenames = createdestfilenames(sourcedirectory,destdirectory,sourcefilenames,p.Results.suffix);
end

% loop through files and downsample
for i = 1:size(sourcefilenames,1)
    downsamplefile(sourcefilenames(i,:),destfilenames(i,:));
end

if nargout
    out = destfilenames;
end

end

function out = getmatfiles(in)
dirlist = dir([in filesep '*.mat']);
out = [];
for i = 1:length(dirlist)
    out = strvcat(out,[dirlist(i).folder filesep dirlist(i).name]);
end
end

function destfilenames = createdestfilenames(sourcedirectory,destdirectory,sourcefilenames,suffix)

% replace source directory in sourcefilenames with dest directory
f1 = char(strrep(cellstr(sourcefilenames),sourcedirectory,destdirectory));
f2 = char(strrep(cellstr(f1),'.mat',[suffix '.mat']));

destfilenames = f2;

end

function [] = downsamplefile(source,dest)
% check whether the filenames are the same - if so, throw an error
if strcmp(source,dest)
    error('downsample_matfiles:downsamplefile:overwriteError',['Overwrite Source .mat file ' source ' Forbidden'])
end

% The resample code resamples the original signals from 1200 Hz to 1080 Hz.
% Here, P and Q are specified so that 1200 * P / Q = 1200. 
P = 9;
Q = 10;

r = @(in) resample(in,P,Q);

s = load(source);
d.Accels = r(s.Accels);
d.AnalogFrameRate = s.AnalogFrameRate*P/Q;
d.COMAccel = r(s.COMAccel);
d.COMPos = s.COMPos;
d.COMPosminusLVDT = s.COMPosminusLVDT;
d.COMVelo = s.COMVelo;
d.EMG = r(s.EMG);
d.EMGID = s.EMGID;
d.Forces = r(s.Forces);
d.GRF = r(s.GRF);
d.JC = s.JC;
d.LVDT = r(s.LVDT);
d.MarkerID = s.MarkerID;
d.Markers = s.Markers;
d.VideoFrameFate = s.VideoFrameRate;
d.atime = r(s.atime);
d.mass = s.mass;
d.mtime = s.mtime;
d.platonset = s.platonset;
d.COP = r(s.COP);
d.COPID = s.COPID;

save(dest,'-struct','d')

if 0
    % compare plots of EMG
    figure
    for i = 1:16
        plotij(16,1,i,1)
        plot(s.atime,s.EMG(:,i));
        plot(d.atime,d.EMG(:,i)+0.5);
        legend({'recorded','downsampled+offset for visualization'})
        title(s.EMGID(i,:))
        xlabel('time')
        ylabel('EMG (V)')
    end
end

end