function out = softplus(in)
	out = log(1+exp(in));
end