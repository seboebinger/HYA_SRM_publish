function [] = playhandel()
handel = load('handel.mat');
sound(handel.y, handel.Fs)
end
