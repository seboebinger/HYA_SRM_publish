function [] = plottrial(trial)
% function [] = plottrial(trial)
%
% Plots trial kinematics, forces, and EMG on a single figure. Inspired by
% plots produced in the Macpherson laboratory.
%
% J. Lucas McKay, Ph.D.
% 2012 11 30

defaultdir = '/Users/jlmckay/Research/Rectus/F/ProcessedData/Neurolab/ParkinsonDisease/';

if nargin==0
    if exist(defaultdir)==2
        currentdir = pwd;
        cd(defaultdir)
        [filename, pathname] = uigetfile([defaultdir '*'],'select file');
        trial = [pathname filename];
        cd(currentdir)
    else
        [filename, pathname] = uigetfile([defaultdir '*'],'select file');
        trial = [pathname filename];
    end
end

% Load the trial
load(trial);

% Code to preprocess plot data

% Missing markers are set to zero. For markers numerically equal to zero,
% set to NaN. Note that the raw data markers must be used, here -
% otherwise, the filtering introduces artifacts when markers appear and
% disappear.
Markers = rawData.video.markers;
for i = 1:size(Markers,1)
    for j = 1:25
        if (Markers(i,j,1)==0)&(Markers(i,j,2)==0)&(Markers(i,j,3)==0)
            Markers(i,j,:)=nan;
        end
    end
end

% % Don't show markers within 20 cm of the origin.
% Markers(Markers<200) = nan;

% plot(squeeze(Markers(:,5,3)),'.')
% 
% figure
% subplot(1,2,2)
% plot(squeeze(Markers(:,5,3)),'.')
% ylim([0 1800])
% xlabel('frames (120 Hz)')
% ylabel('C7 Z (mm) (PROCESSED)')
% subplot(1,2,1)
% plot(squeeze(rawData.video.markers(:,5,3)),'.')
% xlabel('frames (120 Hz)')
% ylabel('C7 Z (mm) (RAW)')
% ylim([0 1800])

% Calculate perturbation direction from recorded data.

% Subtract off first sample.
Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);

% Determine maximum absolute displacement to calculate perturbation
% direction. Note that this is required because the platform may be
% returning at the end of the trial.
[DisplacementTH,DisplacementR] = cart2pol(Displacement(:,1),Displacement(:,2));
DisplacementTH = DisplacementTH*180/pi;
[peakdisp, temp] = max(DisplacementR);
pertdir = DisplacementTH(temp);
pertdir(pertdir<0) = pertdir(pertdir<0)+360;

% Calculate peak perturbation displacement, velocity, and acceleration from recorded data.

% Calculate displacement in direction of perturbation. For ease of reading,
% the zeroing procedure is included again.
Displacement = LVDT - repmat(LVDT(1,:),size(LVDT,1),1);
DisplacementPD = Displacement(:,1)*cosd(pertdir) + Displacement(:,2)*sind(pertdir);
peakdisp = max(DisplacementPD);

% Calculate velocity in direction of perturbation.
Velocity = Velocity - repmat(Velocity(1,:),size(Velocity,1),1);
VelocityPD = Velocity(:,1)*cosd(pertdir) + Velocity(:,2)*sind(pertdir);
peakvel = max(VelocityPD);

% Calculate acceleration in direction of perturbation.
Acceleration = Accels - repmat(Accels(1,:),size(Accels,1),1);
AccelerationPD = Acceleration(:,1)*cosd(pertdir) + Acceleration(:,2)*sind(pertdir);
peakacc = max(AccelerationPD);


% Calculate stance width as average distance between the heel markers
% during the first 0.25 seconds. Note that this is calculated as a vector
% norm, so should work if the subject is facing a different direction.
% Markers are in mm, so divide by 10 for cm.
stancewidth = 0.1*norm(mean(squeeze(Markers(mtime<0.25,24,:)) - squeeze(Markers(mtime<0.25,18,:))));




% Plotting code
figh = fig;


% Perturbation kinematics subplots
NROWS = 4;
NCOLS = 7;

XL = [atime(1) atime(end)];
YLaccel = 0.25*[-1 1];
YLvel = 40*[-1 1];
YLpos = 10*[-1 1];

platonsetlinespec = '--k';

subplot(NROWS,NCOLS,15)
title('X Accel (g)')
xlim(XL); ylim(YLaccel); p = line(atime,Accels(:,1),'clipping','off');
plot(platonset*[1 1],YLaccel,platonsetlinespec)

subplot(NROWS,NCOLS,16)
title('X Vel (cm/s)')
xlim(XL); ylim(YLvel); p = line(atime,Velocity(:,1),'clipping','off')
plot(platonset*[1 1],YLvel,platonsetlinespec)

subplot(NROWS,NCOLS,17)
title('X Pos (cm)')
xlim(XL); ylim(YLpos); p = line(atime,LVDT(:,1),'clipping','off')
plot(platonset*[1 1],YLpos,platonsetlinespec)

subplot(NROWS,NCOLS,22)
title('Y Accel (g)')
xlim(XL); ylim(YLaccel); p = line(atime,Accels(:,2),'clipping','off')
plot(platonset*[1 1],YLaccel,platonsetlinespec)

subplot(NROWS,NCOLS,23)
title('Y Vel (cm/s)')
xlim(XL); ylim(YLvel); p = line(atime,Velocity(:,2),'clipping','off')
plot(platonset*[1 1],YLvel,platonsetlinespec)

subplot(NROWS,NCOLS,24)
title('Y Pos (cm)')
xlim(XL); ylim(YLpos); p = line(atime,LVDT(:,2),'clipping','off')
plot(platonset*[1 1],YLpos,platonsetlinespec)


% Raw subject kinematics subplots
subplot(NROWS,NCOLS,[1 2 3 8 9 10])
title('Raw Kinematics')

% Index the markers, for ease of describing the segments.
LFHD=1;
RFHD=2;
LBHD=3;
RBHD=4;
C7=5;
CLAV=6;
RBAK=7;
LSHO=8;
RSHO=9;
LASI=10;
RASI=11;
LPSI=12;
RPSI=13;
LTHI=14;
LKNE=15;
LTIB=16;
LANK=17;
LHEE=18;
LTOE=19;
RTHI=20;
RKNE=21;
RTIB=22;
RANK=23;
RHEE=24;
RTOE=25;

markernames = [...
    'LFHD'
    'RFHD'
    'LBHD'
    'RBHD'
    'C7  '
    'CLAV'
    'RBAK'
    'LSHO'
    'RSHO'
    'LASI'
    'RASI'
    'LPSI'
    'RPSI'
    'LTHI'
    'LKNE'
    'LTIB'
    'LANK'
    'LHEE'
    'LTOE'
    'RTHI'
    'RKNE'
    'RTIB'
    'RANK'
    'RHEE'
    'RTOE'
    ];

Nmarkers = length(markernames);
Nmarkerframes = size(Markers,1);
MarkerCMap = lbmap(Nmarkerframes,'bluegray');

% make the plots
for i = 1:Nmarkers
    p = plot3(Markers(:,i,1),Markers(:,i,2),Markers(:,i,3));
    set(p,'color',MarkerCMap(floor(end/2),:))
end
set(gca,'CameraPosition',[3553.62 -3373.68 4671.19])
axis equal

% for i = 1:Nmarkers
%     for j = 1:Nmarkerframes
%     p = plot3(Markers(j,i,1),Markers(j,i,2),Markers(j,i,3));
%     set(p,'marker','.');
%     set(p,'color',MarkerCMap(j,:))
%     end
% end
% set(gca,'CameraPosition',[3553.62 -3373.68 4671.19])
% axis equal

% pick frame 10 and frame end-10;
startframe = 10;
endframe = Nmarkerframes-10;

% headband, shoulders, right back triangle, asis-psis, left femur, left
% shank, left foot, right femur, right shank, right foot
connectframes = {...
    [LFHD RFHD RBHD LBHD LFHD];
    [C7 RSHO CLAV LSHO C7];
    [C7 RSHO RBAK C7];
    [LASI RASI RPSI LPSI LASI];
    [LASI LKNE LTHI LASI];
    [LKNE LANK LTIB LKNE];
    [LANK LHEE LTOE LANK];
    [RASI RKNE RTHI RASI];
    [RKNE RANK RTIB RKNE];
    [RANK RHEE RTOE RANK];
    }

for i = [startframe endframe]
    for j = 1:length(connectframes)
        p = plot3(Markers(i,connectframes{j},1),Markers(i,connectframes{j},2),Markers(i,connectframes{j},3));
        set(p,'color',MarkerCMap(i,:))
    end
end



% EMG subplots
subplotorder = [4:7:25 5:7:26 6:7:27 7:7:28];
XL = [atime(1) atime(end)];
YL = [0 4];
for i = 1:16
    subplot(NROWS,NCOLS,subplotorder(i))
    xlim(XL)
    ylim(YL)
    title(deblank(EMGID(i,5:end)))
    p = line(atime,EMG(:,i),'clipping','off');
    plot(platonset*[1 1],YL,platonsetlinespec)
end




labelstr = {...
sprintf('file      %s',trial);
sprintf('st width  % 3.0f cm',stancewidth);
sprintf('pert dir  % 3.0f �',pertdir);
sprintf('peak disp % 3.0f cm',peakdisp);
sprintf('peak vel  % 3.0f cm/s',peakvel);
sprintf('peak acc  % 3.2f g',peakacc);
}

h = labelfigure(labelstr);
set(h,'fontsize',10);

end

function h = fig()
h = figure;

ScreenSize = get(0,'ScreenSize');
width = ScreenSize(3);
height = ScreenSize(4);
margin = floor(0.1*min([width height]));
set(h,'position',[margin margin width-2*margin height-2*margin])
% magfac = 1.5;
% width = 11*magfac;
% height = 8.5*magfac;
%
% % Screen size, in pixels
% ScreenSize = get(0,'ScreenSize');
% % Screen PPI
% ScreenPixelsPerInch = get(0,'ScreenPixelsPerInch');
% ScreenSizeInches = ScreenSize/ScreenPixelsPerInch;
%
% dim = [0 0 0 0];
% dim(3) = floor(width*ScreenPixelsPerInch);
% dim(4) = floor(height*ScreenPixelsPerInch);
% temp = round(.5*(ScreenSize - dim));
% dim([1 2]) = temp([3 4]);
%
% set(h,'Position',dim);

fontsize = 10;
set(h,'defaultaxesfontsize',fontsize);
set(h,'defaulttextfontsize',fontsize);
% set(h,'toolbar','none')
% set(h,'menubar','none')

end
