function handle_out = bigfigure(varargin)
% handle = bigfigure(2)
% handle = bigfigure
% bigfigure(3)

p = inputParser;
addOptional(p,'handle',[]);
p.parse(varargin{:});

rootwindow = get(0);
if isempty(p.Results.handle)
	f = figure;
else
	f = figure(p.Results.handle);
end
f.Position = rootwindow.ScreenSize;

if nargout
	handle_out = f;
end

end