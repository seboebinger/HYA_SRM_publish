function h = puttextbelow(t,string)
% function h = puttextbelow(handle,string)
% 

% Get the extent, position, and alignment of the first string.
textent = get(t,'Extent');
tposn = get(t,'Position');
thoriz = get(t,'horizontalalignment');
tvert = get(t,'verticalalignment');

t = text(tposn(1),tposn(2)-textent(4),string);
set(t,'horizontalalignment',thoriz,'verticalalignment',tvert);

h = t;
