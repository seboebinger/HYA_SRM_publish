function out = timeintegral(x,t)
% function out = timeintegral(xdata,timedata)
% 
% approximate the integral of a function x(t) with a cumulative sum.


x = x(:);
t = t(:);

out = cumsum(x.*[0; diff(t)],'omitnan');


% quick proof with a function with an algebraic integral
if 0
	t = linspace(0,2,100)'
	f_t = t;
	f_t_int = cumsum(f_t.*[0; diff(t)])
	figure
	plot(t,[f_t f_t_int])
	f_t_int(end)
end


end

