function [] = print_all_figures_to_eps()
% function [] = print_all_figures_to_eps()
% 
% prints all open figures to .eps files fig01.eps, fig02.eps, etc. in the
% current directory. be careful not to overwrite!
% 
% J. Lucas Mckay, Ph.D. 2011

figList = get(0,'children');

for i = 1:length(figList)
	fi = figList(i);
	fnum = fi.Number;
	evalStr = "print -depsc2 -tiff -r300 -painters -f"+fnum+" fig"+fnum+"_"+clean(fi.Name)+".eps"
	eval(evalStr)
end

end