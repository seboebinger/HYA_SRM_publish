function h = addfitline(x,y)

[b,~,residuals,~,stats] = regress(y(:),[x(:) ones(size(x(:)))]);
p = stats(3);

% calculate pearson's rho
[rho_pearson,pval_pearson] = corr(x,y,'rows','complete','type','Pearson');
[rho_spearman,pval_spearman] = corr(x,y,'rows','complete','type','Spearman');

xl = get(gca,'xlim');
yl = get(gca,'ylim');

r = [min(xl) max(xl)];

% l = line(r,b(1)*r+b(2),'linestyle','-','color',color,'clipping','off')
l = line(r,b(1)*r+b(2),'linestyle','-','color','k','clipping','off');

% str = ['   slope = ' num2str(b(1),3) '; intercept = ' num2str(b(2),3) '; p <= ' num2str(p,3)]
str = sprintf('slope = %3.2f; intercept = %3.2f\nPearson''s rho = %1.2f; p <= %0.3f\nSpearman''s rho = %1.2f; p <= %0.3f',b(1),b(2),rho_pearson,pval_pearson,rho_spearman,pval_spearman)

if b(1)>=0
%     t = text(0,1,str);
%     set(t,'units','normalized','horizontalalignment','left','verticalalignment','top','fontsize',get(gcf,'DefaultAxesFontSize'))
    t = text(xl(1),yl(2),str);
    set(t,'horizontalalignment','left','verticalalignment','top','fontsize',get(gcf,'DefaultAxesFontSize'))
else
%     t = text(1,1,str);
%     set(t,'units','normalized','horizontalalignment','right','verticalalignment','top','fontsize',get(gcf,'DefaultAxesFontSize'))
    t = text(xl(2),yl(2),str);
    set(t,'horizontalalignment','right','verticalalignment','top','fontsize',get(gcf,'DefaultAxesFontSize'))
end

h = [l(:)' t(:)'];

end
