function [h,k,p,residuals] = regressplot(x,y,color,style)
% function [h,k,p,residuals] = regressplot(x,y,color,style)

if nargin<6
	style = '-';
end

middlehalf = [round(length(x)/4):round(3*length(x)/4)];
gray = 0.6*[1 1 1];

h = line(x,y,'clipping','off','color',color,'marker','.','linestyle','none');
% h = line(x,y,'clipping','off','color',gray,'marker','.','linestyle','none');
% h = line(x(middlehalf),y(middlehalf),'clipping','off','color',color,'marker','.','linestyle','none');

[b,~,residuals,~,stats] = regress(y(:),[x(:) ones(size(x(:)))]);
% calculate pearson's rho
[rho,pval] = corr(x,y,'rows','complete');
p = stats(3);

r = [min(x(:)) max(x(:))];

% l = line(r,b(1)*r+b(2),'linestyle','-','color',color,'clipping','off')
l = line(r,b(1)*r+b(2),'linestyle','-','color','k','clipping','off')

yl = get(gca,'ylim');
xl = get(gca,'xlim');

% str = ['   slope = ' num2str(b(1),3) '; intercept = ' num2str(b(2),3) '; p <= ' num2str(p,3)]
str = sprintf('   slope = %3.1f; intercept = %3.1f; p <= %0.3f\n   rho = %1.2f; p <= %0.3f',b(1),b(2),p,rho,pval)
t = text(xl(1),yl(2),str);
set(t,'horizontalalignment','left','verticalalignment','top')

h = [h(:)' l(:)' t(:)'];

k = b(1);
end
