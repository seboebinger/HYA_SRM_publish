function episodes = chunk(in)
% function episodes = chunk(in)
% 
% chunk.m
% J. Lucas McKay, Ph.D., M.S.C.R.
% 2017 04 05
% 
% takes a vector of numerical values (including nan) and returns the epochs
% containing chunks of unique values in a table called "episodes".
% 
% episodes = chunk([1 1 1 nan nan 2 2 2 2 2 2 90 90 90 2 2 2 nan nan -30 90 90 90 2 2])
% episodes = 
% 
%     Value    EpisodeNum    ValueEpisodeNum    StartIndex    EndIndex
%     _____    __________    _______________    __________    ________
% 
%       1      1             1                   1             3      
%     NaN      2             1                   4             5      
%       2      3             1                   6            11      
%      90      4             1                  12            14      
%       2      5             2                  15            17      
%     NaN      6             1                  18            19      
%     -30      7             1                  20            20      
%      90      8             2                  21            23      
%       2      9             3                  24            25    

% turn the input into a vector
in = in(:);

% replace nan values with an indicator if necessary. these will be replaced
% at the end.
[c] = unique(in);
nanblocks = bwlabel(isnan(in));
nanblocks(nanblocks>0) = max(c) + nanblocks(nanblocks>0);
inmasked = in;
inmasked(nanblocks>0) = nanblocks(nanblocks>0);

% find the unique values of the input vector in the order in which they
% appear.
[c] = unique(inmasked,'stable');

episodes = cell2table(cell(0,5));
episodes.Properties.VariableNames = {'Value' 'EpisodeNum' 'ValueEpisodeNum' 'StartIndex' 'EndIndex'};

for ci = c'
    episodes = [episodes; findepisodes(inmasked,ci)];
end


% replace indicator values with nan if necessary.
if length(unique(nanblocks))>1
    nanvals = unique(nanblocks); nanvals(1) = [];
    episodes.Value(ismember(episodes.Value,nanvals)) = nan;
end

% reorder rows based on starting index of each block.
episodes = sortrows(episodes,{'StartIndex'})

episodes.EpisodeNum = rownum(episodes.Value);

end

function episodes = findepisodes(in,value)

% use the image processing toolbox to find "connected objects."
blockindices = bwlabel(in==value);
blocks = unique(blockindices);
blockstarts = nan(size(blocks));
blockends = nan(size(blocks));
for i = 1:length(blocks)
    blockstarts(i) = find(blockindices==blocks(i),1,'first');
    blockends(i) = find(blockindices==blocks(i),1,'last');
end
% delete zero blocks
blocks(1) = [];
blockstarts(1) = [];
blockends(1) = [];

temp = nan(size(blocks));
episodes = table(value*ones(size(blocks)),temp,blocks,blockstarts,blockends);
episodes.Properties.VariableNames = {'Value' 'EpisodeNum' 'ValueEpisodeNum' 'StartIndex' 'EndIndex'};

end

function out = rownum(in)
out = (1:size(in,1))';
end

function out = colnum(in)
out = (1:size(in,2));
end