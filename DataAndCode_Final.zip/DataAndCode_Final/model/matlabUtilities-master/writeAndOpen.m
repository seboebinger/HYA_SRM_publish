function [outName] = writeAndOpen(t,fName)
% function [outName] = writeAndOpen(t)
% 
% write a table to file in the current directory and open it (overwrites
% existing tables, so be careful.)
% only compliant with OS X for now

if nargin<2
fName = inputname(1)+".xlsx";
end

eval("!rm "+fName);

writetable(t,fName);

eval("!open "+fName);

if nargout
	outName = fName;
end

end