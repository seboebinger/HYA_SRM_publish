function reject_h0 = FDR(p_values,q_star)
% function reject_h0 = FDR(p_values,q_star)
% 
% Implemented version of false discovery control as in Benjamini and
% Hochberg, 1995.
% 
% Example from paper can be tested as:
% p_values = [0.0001 0.0004 0.0019 0.0095 0.0201 0.0278 0.0298 0.0344 0.0459 0.3240 0.4262 0.5719 0.6258 0.7590 1.000]';
% q_star = 0.05;
% FDR(p_values,q_star)

if nargin<2
    q_star = 0.05;
end

p_values = sort(p_values(:));
m = length(p_values);
reject_h0 = false(size(p_values));

% Work from the end of the vector up, as in the paper.
for i = m:-1:1
    if p_values(i)<=(i*q_star/m)
        reject_h0(i) = true;
        reject_h0(i:-1:1) = true;
        break;
    end
end

end