function [] = printeps(handles,basename)
% function [] = printeps(handles)
% 
% Print the figures pointed at by the vector of handles (e.g., [1 2] is
% figures 1 and 2) to files of the type tempfigure01.eps and tempfigure02.eps
% 
% The leading zeros are there because they assist a great deal in batch
% processing.
% 
% function [] = printeps(handles,basename)
% 
% If a string is supplied for "basename", then that string is used.
% 
% Note that if the basename is supplied as directoryname/basename, then the
% files are placed in the appropriate directory. If the directory does not
% exist, then the script will attempt to create it. Watch out - for
% compatability reasons, you should avoid spaces, special characters, and
% slashes in filenames.
% 
% J. Lucas Mckay, 20 July 2010

if nargin<1
	handles = gcf;
elseif isempty(handles)
	handles = gcf;
end

if nargin<2
	basename = 'tempfigure';
end

% Figure numbers will be appended with leading zeros. This helps the
% scripting process later a great deal.

% Examine where the files will end up.
printname = [basename num2str(handles(1),'%02d') '.eps'];

[pathstr,name,ext] = fileparts(printname);

% Check if the directory exists. If not, create it.
if ~isempty('pathstr')
	if exist(pathstr,'dir')~=7
		disp(['attempting to create ' pathstr])
		eval(['!mkdir ' pathstr])
	end
end

% Print each figure to a temporary .eps file.
for i = 1:length(handles)	
	printname = [pathstr '/' basename num2str(handles(i),'%02d') '.eps'];
	disp(['printing ' printname])
	print(['-f' num2str(handles(i))],'-loose','-depsc2',printname);
end

end

% evalstr = ['!~/Research/Matlab\ R2009b/pdfall.sh'];
% eval(evalstr)
% 
% % Convert to pdf with the OS X epstopdf command-line utility.
% evalstr = ['!/sw/bin/epstopdf ' printname]
% eval(evalstr)
% 
% 
% % Convert each temporary .eps file to a pdf.
% 
% epstopdf figure12.eps
% 
% 
% 
% print(['-f' num2str(handle)],'-loose','-depsc2',[printname '.eps']);
% end
% 
% if isempty(filename)
% 	filename = [filename sprintf('figure%d',handle)];
% end
% 
% disp(sprintf('Printing Figure %d for Word: Ticks may change.',handle));
% % Future change: move through subplots and check if they have been set
% % manually.
% 
% [pathstr,name,ext] = fileparts(filename);
% 
% if isempty(pathstr)
% 	printname = name;
% else
% 	printname = [pathstr filesep name];
% end
% 
% print(['-f' num2str(handle)],'-loose','-depsc2',[printname '.eps']);
% eval(['!open ' printname '.eps'])
