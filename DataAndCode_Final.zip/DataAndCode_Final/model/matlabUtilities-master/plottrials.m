function [] = plottrials(files,mus)

clear
load pre90filenames
load pre270filenames
load post90filenames
load post270filenames

filenames1 = pre90filenames(25:27,:)
filenames2 = pre270filenames(1:3,:)


files = filenames1;
files = filenames2;

NROWS = 3;
NCOLS = 3;
MUSNUM = 15;
NFILES = size(files,1);

EMGYL = [-3 3];
ACCYL = [-0.2 0.2];
POSYL = [-10 10];
XL = [-0.5 1.5];

fig
labelfigure(files)
title([files{i} ' ' deblank(filedata.EMGID(MUSNUM,5:end))])

for i = 1:NFILES
    filedata = load(files{i});
    atime = filedata.atime - filedata.platonset;

    plotij(NROWS,NCOLS,1,i)
    ylim(EMGYL)
    xlim(XL)
    ploth = clipx(atime,filedata.rawData.analog.emg(:,MUSNUM),'clipping','off')
    title([deblank(filedata.EMGID(MUSNUM,5:end))])

    plotij(NROWS,NCOLS,2,i)
    ylim(ACCYL)
    xlim(XL)
    ploth = clipx(atime,filedata.Accels(:,1),'clipping','off','linestyle','--')
    ploth = clipx(atime,filedata.Accels(:,2),'clipping','off','linestyle','-')
    title('ACCEL')

    plotij(NROWS,NCOLS,3,i)
    ylim(POSYL)
    xlim(XL)
    ploth = clipx(atime,filedata.LVDT(:,1),'clipping','off','linestyle','--')
    ploth = clipx(atime,filedata.LVDT(:,2),'clipping','off','linestyle','-')
    title('POS')
end

end