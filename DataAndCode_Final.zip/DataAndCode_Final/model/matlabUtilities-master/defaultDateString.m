function s = defaultDateString
% function s = defaultDateString

s = string(datestr(now,'yyyy-mm-dd_HH-MM-SS'));

end
