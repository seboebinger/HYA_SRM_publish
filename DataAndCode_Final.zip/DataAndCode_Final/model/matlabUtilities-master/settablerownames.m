function outtable = settablerownames(intable,varname)
% function outtable = settablerownames(intable,'name_of_variable_in_table')
% 
% set the row names of a given table to the supplied variable
% 
% J. Lucas McKay, Ph.D., M.S.C.R.

outtable = intable;
var = intable{:,varname};

if ischar(var)
    outtable.Properties.RowNames = cellstr(var);
elseif iscell(var)
    outtable.Properties.RowNames = var;
end




