function categoricalvar = double2categorical(doublevar,formatstr)
% function categoricalvar = double2categorical(doublevar)
% function categoricalvar = double2categorical(doublevar,format)
% JLM, 2016-05-27

if nargin<2
    formatstr='%d';
end

doublevar = doublevar(:);

N = length(doublevar);

cellvar = cell(N,1);

for i = 1:N
    cellvar{i} = sprintf(formatstr,doublevar(i));
end

categoricalvar = categorical(cellvar);


