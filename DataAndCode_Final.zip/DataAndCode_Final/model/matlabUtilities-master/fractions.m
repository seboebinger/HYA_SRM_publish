function [] = fractions()

 reshape([1:100],10,10)'.^-1
 
end