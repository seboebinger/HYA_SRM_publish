function pval_out = paramt(in)
% based on 
% http://vassarstats.net/textbook/ch11pt1.html
% 2017 12 20
% still cannot get this to match ttest2 with effective DOF measures

% satterwaithe formula for degrees of freedom from 
% http://www.statisticshowto.com/satterthwaite-formula/



% reconfigure inputs
T = array2table(in);
T.Properties.VariableNames = {'n' 'mn' 'sd'};

% calculate sum of squared deviates
T.ss = (T.sd.^2).*(T.n-1);

if size(T,1)==2
testres.meandiff = T.mn(1)-T.mn(2);
testres.pooledvar = sum(T.ss)/(sum(T.n)-2);
testres.pooledse = (testres.pooledvar/T.n(1) + testres.pooledvar/T.n(2))^0.5;
testres.t = testres.meandiff / testres.pooledse;
testres.dof = sum(T.n)-2;
testres.p = tcdf(testres.t,testres.dof);
else
end
T.se = (T.var./T.n).^0.5;

sep = '    ';


if size(T,1)==2
	T.mudiff(1,1) = 0;
	T.mudiff(2,1) = T.mn(2)-T.mn(1);
	testres.t = T.mudiff(2,1) / sum(T.sd.^2./T.n).^0.5;
	testres.dof = sum(T.n)-2;
	testres.p = tcdf(testres.t,testres.dof);
else
end

disp(sep)
disp(T)
disp(sep)
disp(testres)

switch size(T,1)
	case 1
		7+3
	case 2
		7+3
end

if nargout
	pval_out = p;
end

end