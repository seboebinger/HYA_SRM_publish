function [] = ticks(xy,xt,xtl)

labelstoinclude = ismember(xt,xtl);

labels = num2str(xt(:));
labels(~labelstoinclude,:) = ' ';

if xy==0
    set(gca,'xtick',xt);
    set(gca,'xticklabel',labels);
elseif xy==1
    set(gca,'ytick',xt);
    set(gca,'yticklabel',labels);
end

end