function box_handles=drawbox(xvals, col, yvals)
% function hrec=draw_box(xvals, col, yvals)
%
% This function draws a square box, of color specified by the RGB 3-vector
% col, at the coordinates specified by xvals and yvals. xvals and yvals
% must be vectors of lengths which are multiples of two. Any of the
% arguments can be replaced by an empty matrix, though at least xvals must
% be supplied.
%
% The boxes are drawn behind any current curves on the plot. If yvals or
% xvals are left unspecified, the current dimensions of the plot are used.
%
% A vector of handles to each box is returned.
%
% JLM 15 June 2006
% plot(1:10)
% draw_box([0 10],[.9 .9 .9],[7 9])


% Default values for color and Y Limit if arguments are omitted.
if nargin<3, yvals=get(gca,'YLim'); end
if nargin<2, col=[.8 .8 .8]; end

% If the color argument is empty, or the string 'default', use the default color.
if strcmp(col,'default')||isempty(col)
	col=[.8 .8 .8];
end

% Similarly, if the other arguments are empty, use the X- and Y- limits of
% the plot.
if isempty(xvals), xvals=get(gca,'XLim'); end
if isempty(yvals), yvals=get(gca,'YLim'); end

% Ensure that there are coordinates for square boxes.
if mod(length(xvals),2)
	error('draw_box: Length of xvals must be divisible by two.');
end
if mod(length(yvals),2)
	error('draw_box: Length of yvals must be divisible by two.');
end

num_horiz_boxes=length(xvals)/2;
num_vert_boxes=length(yvals)/2;

% Remember the old objects and hold state so you can copy them in front of the boxes.
old_plots=get(gca,'Children');
old_hold=ishold;

% Set hold to on.
hold on

hrec=[];
for i=1:num_horiz_boxes
	for j=1:num_vert_boxes
		x0=xvals(1+(i-1)*2);
		x1=xvals(2*i);

		y0=yvals(1+(j-1)*2);
		y1=yvals(2*j);

		h=fill([x0 x1 x1 x0],[y0 y0 y1 y1],[1 1 1]);
		set(h,'facecolor',col);

		if strcmp(col,'none')
			set(h,'LineStyle','-');
		else
			set(h,'LineStyle','none');
		end

		hrec=[hrec,h];
	end
end

% Make sure the axes draw in front of the patch objects.
set(gca,'Layer','top');

% Copy the old objects in front of the patches, and then delete the old
% copies. To preserve the original order, flip the vector.
% copyobj(flipud(old_plots),gca)
copyobj(old_plots,gca)
delete(old_plots)

% Restore hold state.
if ~old_hold
	hold off
end

if nargout>0
	box_handles=hrec;
end

end