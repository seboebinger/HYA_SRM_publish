function h = vscalebar(vlen,vloc,str,hloc)
% function h = vscalebar(vlen,vloc)
% function h = vscalebar(vlen,vloc,str)
% function h = vscalebar(vlen,vloc,str,hloc)

xl = get(gca,'xlim');
yl = get(gca,'ylim');


if nargin<4
	hloc = 'right';
end

if nargin<3
	str = num2str(vlen);
end

if nargin<2
    vloc = max(yl)-vlen/2;
end

switch hloc
	case 'right'
		% top right
		x = [xl(2) xl(2)];
		y = vloc+0.5*vlen*[-1 1];
		l = line(x,y,'clipping','off','color','k');
		
		t = text(mean(x),mean(y),str);
		set(t,'horizontalalignment','right');
		set(t,'verticalalignment','middle');
end

h = [l t];