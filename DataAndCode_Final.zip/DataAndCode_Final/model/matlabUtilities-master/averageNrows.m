function out = averageNrows(in,N)
% function out = averageNrows(in,N)
% 
% takes an n*m matrix and returns an n/N * m matrix where each row is the
% average of the appropriate N rows.

nr1 = size(in,1);
nr2 = nr1/N;
nc = size(in,2);

out = nan(nr2,nc);

for i = 1:nr2
    out(i,:) = nanmean(in(N*(i-1)+(1:N),:),1);
end

end