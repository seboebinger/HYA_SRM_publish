function out = strrepreg(origtext,oldpattern,newtext)
% function out = strrepreg(in,pattern)
% wrapper around strrep that expects regexp patterns like ^ and $

% BROKEN

7+3

out = string();
for i = 1:length(origtext)
	oldChar = char(origtext(i));
	oldPatt = char(oldpattern);
	oldPatt = "_"
	
	[oldPattStart,oldCharSplit] = regexp(oldChar,oldPatt,'start','split');
	newStr = "";
	for 
	
	char(origte
end

% find occurrences of pattern
indices = regexp(origtext,oldpattern,'split');




end