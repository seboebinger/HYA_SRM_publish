function [] = makepdf(handles,filename,filelocation)
% function [] = makepdf(handles,filename,filelocation)
% 
% Print the figures pointed at by the vector handles (e.g., [1 2] is
% figures 1 and 2) to individual eps files of the type filename001.eps,
% filename002.eps, etc., as well as a multi-page filename.pdf.
% 
% If an argument is supplied for filelocation, all files will be placed
% there. If the directory does not exist, an attempt will be made to create
% it.
% 
% Requires OS X 10.5+ 
% 
% NB: avoid special characters in filenames.
% 
% J. Lucas Mckay, 20 July 2010, with help from Jeff Bingham and Dr. Julia Choi

% plot([1 2],'r')
% figure
% plot([1 2],'g')
% figure
% plot([1 2],'b')
% 
% makepdf([1:3],'temporaryname','~/Desktop/MAKEPDFTEST')

if nargin<1
	handles = gcf;
elseif isempty(handles)
	handles = gcf;
end

if nargin<2
	filename = 'tempfig';
end

if nargin<3
	filelocation = [];
end

if ~isempty(filelocation)
	if exist(filelocation,'dir')~=7
		disp(['attempting to create ' filelocation])
		eval(['!mkdir ' filelocation])
	end
end

% Print all figures to a temporary .ps file
psname = fullfile(filelocation,[filename '.ps']);
pdfname = fullfile(filelocation,[filename '.pdf']);

% Loop through and append each figure to the end of the .ps file.
for i = 1:length(handles)
	epsname = fullfile(filelocation,[filename num2str(handles(i),'%03d') '.eps']);
	figname = fullfile(filelocation,[filename num2str(handles(i),'%03d') '.fig']);
	print(['-f' num2str(handles(i))],'-loose','-depsc2',epsname);
	saveas(i,figname)
	if i>1
		print(['-f' num2str(handles(i))],'-loose','-dpsc2',psname,'-append');
	else
		print(['-f' num2str(handles(i))],'-loose','-dpsc2',psname);
	end
end

system(['pstopdf ' psname]);
system(['rm ' psname]);

end