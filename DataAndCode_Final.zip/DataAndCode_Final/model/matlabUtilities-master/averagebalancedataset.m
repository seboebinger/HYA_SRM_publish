function dsav = averagebalancedataset(ds,vars,rows,obsnames)
% function dsav = averagebalancedataset(ds,varnames,rows,obsnames)

nvars = length(vars);
nobs = length(rows);

avdata = cell(nobs,nvars);

for i = 1:nobs
    for j = 1:nvars
        temp = ds{rows{i},vars{j}};
        avdata(i,j) = {nanmean(temp)};
    end
end

dsav = cell2table(avdata,'VariableNames',vars','RowNames',obsnames');

end
