function inds = time2ind(timevec,times)
% function inds = time2ind(timevec,times)
%
% function takes a vector of continuous time (note - not a matlab time
% object, just doubles) and returns the sample nearest to each of the
% supplied "times"

indvec = 1:length(timevec);
inds = nan(size(times));
for i = 1:length(inds)
	inds(i) = round(interp1(timevec,indvec,times(i)));
end


end