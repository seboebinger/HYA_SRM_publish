function out = findkeys(in,keys)
% function keys = findkeys(in,keys)
% 
% keys = findkeys({'sand';'sandbox';'nerf';'apple'},{'sand','apple'}) returns
% {'sand';'sand';[];'apple'}
% 
% JLM 2016 12 8

numkeys = length(keys);

out = cell(size(in));
for i=1:length(keys)
out(cellfun(@(in) ~isempty(in),strfind(in, keys{i}))) = keys(i);
end

end