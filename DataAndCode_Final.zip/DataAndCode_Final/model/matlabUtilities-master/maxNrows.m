function out = maxNrows(in,N)
% function out = maxNrows(in,N)
% 
% takes an n*m matrix and returns an n/N * m matrix where each row is the
% max of the appropriate N rows.

nr1 = size(in,1);
nr2 = nr1/N;
nc = size(in,2);

out = nan(nr2,nc);

for i = 1:nr2
    out(i,:) = nanmax(in(N*(i-1)+(1:N),:),[],1);
end

end