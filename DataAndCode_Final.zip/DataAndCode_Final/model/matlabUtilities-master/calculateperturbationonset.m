function [perturbationonset] = calculateperturbationonset(trialdata)
% function [perturbationonset] = calculateperturbationonset(trialdata)
% 
% J. Lucas McKay, Ph.D.
% 3 April 2013
% 
% This method recalculates perturbation onset based on a threshold applied
% to acceleration magnitude. It has only been validated on A-P trials of
% certain magnitudes! 

% calculate the sample at which the acceleration hits 6SD.
bkgdmn = nanmean(trialdata.Accels(trialdata.atime<0.25,2));
accelmag = abs(trialdata.Accels(:,2)-bkgdmn);

bkgdmn = nanmean(accelmag(trialdata.atime<0.25));
bkgdsd = nanmean(accelmag(trialdata.atime<0.25));

% onsetind = find(accelmag>bkgdmn+l1*bkgdsd,1,'first');
% onsetind = find(accelmag(1:onsetind)<bkgdmn+l2*bkgdsd,1,'last');
onsetind = find(accelmag>bkgdmn+0.016,1,'first');

% add a sample offset to the identified onset sample to account for the
% average 10 ms lag between the acceleration zero crossing and the
% threshold crossing.
onsetind = onsetind - 15;
perturbationonset = trialdata.atime(onsetind);

end