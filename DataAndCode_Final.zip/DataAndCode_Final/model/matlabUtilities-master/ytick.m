function [] = ytick(in)

set(gca,'ytick',in);

end