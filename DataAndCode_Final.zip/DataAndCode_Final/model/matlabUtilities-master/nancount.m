function N = nancount(in,dim)

if nargin<2
	dim = 1;
end

nonempty = ones(size(in));
nonempty(isnan(in)) = 0;

N = sum(nonempty,dim);


end