function out = midpoints(in)
x = 1:length(in);
y = in;
out = interp1(x,y,x(1:end-1)+0.5);
end