function out = stackindex(in)

out = [num2cell(1:size(in,2)); in];

end
