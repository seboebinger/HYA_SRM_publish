function out = wide2tall(in,collapseVarNames,newVarName,sourceVarName)
% function out = wide2tall(in,collapseVarNames,newVarName,sourceVarName)
% 
% change a table from wide to tall. e.g., 
% exemplarTall = wide2tall(exemplarData,["EMG_TA_L_norm" "EMG_TA_R_norm" "EMG_MGAS_L" "EMG_MGAS_R"],"e","mus");

% check size of input
nRows = size(in,1);
nVars = length(collapseVarNames);

% create output; duplicate entire table to allocate memory
out = repmat(in,nVars,1);
sourceVar = repmat(collapseVarNames,nRows,1);

% copy in first entry to allocate memory
out{:,sourceVarName} = sourceVar(:);
out(:,newVarName) = out(:,collapseVarNames(1));

% loop through and copy over
for i =1:(nRows*nVars)
	out{i,newVarName} = out{i,out{i,sourceVarName}};
end

out(:,collapseVarNames) = [];

end