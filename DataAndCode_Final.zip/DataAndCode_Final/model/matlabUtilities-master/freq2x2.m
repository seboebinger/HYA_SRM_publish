function varargout = freq2x2(v1,v2)

[numav,~,p,avlab] = crosstab(v1,v2);

[nrows,ncols] = size(numav);

% add up column totals
freqs = [numav nansum(numav,2)];
freqs = [freqs; nansum(freqs,1)];

rowlabs = [string(avlab(1:nrows,1)); "Total"];
collabs = [string(avlab(1:ncols,2)); "Total"];

% because variables cannot be named numbers, replace:
collabs(1:end-1) = "val_"+collabs(1:end-1);

freqTable = array2table(freqs);
freqTable.Properties.RowNames = cellstr(rowlabs);
freqTable.Properties.VariableNames = cellstr(collabs);

freqTable{end+1,:} = [nan(1,length(collabs)-1) round(p,3)];
freqTable.Properties.RowNames{end} = 'P-Value';

if nargout==0
	disp("frequencies and chi-squared p-value:")
	disp(freqTable)
else
	varargout = freqTable;
end

end