function h = verticalscale(location,len,str)
% function h = verticalscale(location,len,str)

if nargin<3
	str = num2str(len);
end

xl = get(gca,'xlim');
yl = get(gca,'ylim');

switch location
	case 1
		% top right
		x = [xl(2) xl(2)];
		y = [yl(2) yl(2)-len];
		l = line(x,y,'clipping','off','color','k');
		
		t = text(mean(x),mean(y),str);
		set(t,'horizontalalignment','right');
		set(t,'verticalalignment','middle');
end

h = [l t];