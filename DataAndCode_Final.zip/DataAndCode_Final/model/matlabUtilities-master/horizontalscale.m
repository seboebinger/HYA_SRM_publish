function h = horizontalscale(location,len,str)

if nargin<3
	str = num2str(len);
end

xl = get(gca,'xlim');
yl = get(gca,'ylim');

offset = -0.05*[yl(2)-yl(1)];

switch location
	case 1
		% bottom left
		x = [xl(1) xl(1)+len];
		y = [yl(1) yl(1)]+offset;
		l = line(x,y,'clipping','off','color','k');
		
		t = text(mean(x),mean(y),str);
		set(t,'horizontalalignment','center');
		set(t,'verticalalignment','top');
	case 2
		% bottom right
		x = [xl(2) xl(2)-len];
		y = [yl(1) yl(1)]+offset;
		l = line(x,y,'clipping','off','color','k');
		
		t = text(mean(x),mean(y),str);
		set(t,'horizontalalignment','center');
		set(t,'verticalalignment','top');
end

h = [l t];