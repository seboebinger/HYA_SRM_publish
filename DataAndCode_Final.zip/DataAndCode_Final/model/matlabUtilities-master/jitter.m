function out = jitter(in,amt)
% function out = jitter(in,amt)
% 
% add a small amount of jitter to the input vector.
% if amt is omitted 10% of mean value is assumed.

if nargin<2
	amt = 0.1*nanmean(in);
end

noise = amt*(rand(size(in))-0.5);

out = noise+in;

end