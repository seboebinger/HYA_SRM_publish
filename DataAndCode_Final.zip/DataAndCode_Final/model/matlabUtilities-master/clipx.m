function handle = clipx(xdata,ydata,varargin)

XL = get(gca,'xlim');

newx = xdata(xdata>=min(XL)&xdata<=max(XL));
newy = ydata(xdata>=min(XL)&xdata<=max(XL));

handle = line(newx,newy,varargin{:});

end