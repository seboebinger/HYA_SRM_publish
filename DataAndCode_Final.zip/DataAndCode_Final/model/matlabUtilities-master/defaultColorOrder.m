function cmap = defaultColorOrder
cmap = get(0,'DefaultAxesColorOrder')
end