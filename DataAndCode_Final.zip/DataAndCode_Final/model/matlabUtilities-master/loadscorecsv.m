function [] = loadscorecsv(varargin)
% function [] = loadscorecsv(scorefile,destdir)
% 
% This function loads a .csv file exported from google docs as .csv into a
% data directory.
% 
% Either argument can be left empty for a file dialog. As a shortcut, you
% can call loadscorecsv('default') and it will bring up a file dialog and
% save the .mat file next to the .csv.
% 
% J. Lucas McKay, Ph.D.
% 19 October 2012

if length(varargin)==2
    scorefile = varargin(1);
    destdir = varargin(2);
elseif length(varargin)==1
    if strcmp(varargin(1),'default')
        [scorefile,scorepath] = uigetfile('*.csv','select score file');
        % set the destination directory to the source directory, but omit
        % trailing file separator.
        destdir = scorepath(1:end-1);
        % reassemble the scorefile as a full path. this seems strange, but
        % needs to be done to keep from modifying code around line 35.
        scorefile = [scorepath scorefile];
    else
        scorefile = varargin(1);
        destdir = [];
    end
elseif length(varargin)==0
    scorefile = [];
    destdir = [];
end

if isempty(scorefile)
    [scorefile,scorepath] = uigetfile('*.csv','select score file');
else
    [scorepath,scorefile,scoreext] = fileparts(scorefile);
    scorefile = [scorefile scoreext];
end

ncols = ExcelCol('AS');
nheaderrows = 26;

% read the .csv file into the cell array "data."
fid = fopen([ensuretrailingfilesep(scorepath) scorefile],'r');
data = cell(1,ncols);
datarow = 1;
while (~feof(fid))    
    temp1 = textscan(fid,'%s',ncols-1,'delimiter',',');
    temp2 = textscan(fid,'%s',1,'delimiter','\n');
    data(datarow,:) = [temp1{1}' temp2{1}'];
    datarow = datarow+1;
end
fclose(fid);

% copy a few important variables out of the cell array.
subject = deblank(data{1,2});
session = eval(data{2,2});
kinematicprocessing_rev1init = deblank(data{6,2});
kinematicprocessing_rev1date = deblank(data{7,2});
trialscoring_rev1init = deblank(data{10,2});
trialscoring_rev1date = deblank(data{11,2});
trialscoring_rev2init = deblank(data{12,2});
trialscoring_rev2date = deblank(data{13,2});
trialscoring_revTinit = deblank(data{14,2});
trialscoring_revTdate = deblank(data{15,2});

% extract the trial name (a cell array) and the trial number (a vector of
% numbers). to ensure that these are nicely formatted, deblank.
trialname = data(27:end,ExcelCol('AH'));
trialnumber = data(27:end,ExcelCol('AI'));
temp = [];
for i = 1:length(trialnumber)
    trialname{i} = deblank(trialname{i});
    temp(i) = eval(trialnumber{i});
end
trialnumber = temp(:); clear temp;

% extract the variable names.
outputvarnames = data(26,ExcelCol('AJ'):ExcelCol('AS'));

% extract the logical values.
outputvardata = data(27:end,ExcelCol('AJ'):ExcelCol('AS'));
temp = [];
for i = 1:size(outputvardata,1)
    for j = 1:size(outputvardata,2)
        temp(i,j) = eval(outputvardata{i,j});
    end
end
outputvardata = temp; clear temp;

if isempty(destdir)
    destdir = uigetdir(scorepath,'select save location');
end

dateloaded = date;
clear ans data datarow fid i j ncols nheaderrows temp* varargin

% assemble the output file name
% check for trailing file separator
matfilename = [ensuretrailingfilesep(destdir) subject 'scoringresults.mat'];

% check for overwrite
if exist(matfilename)==2
    warning('loadscorecsv: destination file exists already. not saving.')
else
    save(matfilename)
end

end

function out = ensuretrailingfilesep(in)
% function out = ensuretrailingfilesep(in)
% 
% This small function checks whether the last character of a file path
% matches the file separator on the system. If it doesn't, it adds one and
% returns it. Otherwise, it just returns the input argument.
% 
% J. Lucas McKay, Ph.D.
% 2 November 2012

% check whether last character matches the file sep. if it does, do
% nothing. if it doesn't, add it.
if strcmp(in(end),filesep)
    out = in;
else
    out = [in filesep];
end

end