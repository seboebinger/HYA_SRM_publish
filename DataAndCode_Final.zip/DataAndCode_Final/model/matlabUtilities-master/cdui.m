function [] = cdui()

dir = uigetdir();
cd(dir)

end