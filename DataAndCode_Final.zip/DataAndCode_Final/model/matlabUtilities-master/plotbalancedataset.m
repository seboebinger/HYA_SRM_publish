function out = plotbalancedataset(ds,rowvars,colvars,coltitles,flipvars,xl,yl,clipvars)
% function out = plotbalancedataset(datatable,rowvarnames,colvars,coltitles,flipvars,xl,yl,clipvars)
% 
% Edited 11 October 2015
% Added PLOTSD flag. Set flag if you would like to plot the standard
% deviation.

PLOTSD = 1;
PLOTTRIALS = 0;

nobs = size(ds,1);
if isempty(colvars)
    colvars = {[]};
    for i = 1:nobs
        colvars(i) = {false(size(ds,1),1)};
        colvars{i}(i) = true;
    end
end

if isempty(rowvars)
    rowvars = ds.Properties.VariableNames;
    rowvars(strcmp('atime_s',rowvars))=[];
end

if isempty(flipvars)
    flipvars = zeros(length(rowvars),1);
end

if nargin<8
    clipvars = zeros(length(rowvars),1);
end

% plot everything except for 'atime_s.' note that this is really only
% needed to provide sensible default behavior when no rows have been
% specified.
% nrows = sum(~strcmp('atime_s',rowvars));
nrows = length(rowvars);
ncols = length(colvars);
lw=0.25;
wordfigure([],11,17,10);
% figure

% initialize output table.
avdata = cell(1);
sddata = cell(1);

for nc = 1:ncols
    
    for nr = 1:nrows
        atime = ds.atime_s(colvars{nc},:);
        atime(2:end,:) = [];
        inds = atime>=xl(1)&atime<xl(2);
        
        temp = ds{colvars{nc},rowvars{nr}};
        
        avdata(nc,nr) = {nanmean(temp)};
        sddata(nc,nr) = {nanstd(temp,0,1)};
        
        plotij(nrows,ncols,nr,nc);
        
        timetrace = atime(inds);
        rawtraces = ds{colvars{nc},rowvars{nr}}(:,inds);
        meantrace = nanmean(rawtraces);
        stdtrace = nanstd(rawtraces,0,1);
        ubtrace = meantrace+stdtrace;
        lbtrace = meantrace-stdtrace;
        
        if clipvars(nr)
            meantrace(meantrace<0) = 0;
            lbtrace(lbtrace<0) = 0;
            ubtrace(ubtrace<0) = 0;            
        end
        
        try
            if flipvars(nr) == 1
                if PLOTTRIALS
                p = plot(atime(inds),-temp(:,inds));
                set(p, 'clipping','off','linewidth',lw)
                end
               
                if PLOTSD
                    p = plot(timetrace,-ubtrace);
                    set(p, 'clipping','off','linewidth',0.5*lw,'color',0.5*[1 1 1])
                    p = plot(timetrace,-lbtrace);
                    set(p, 'clipping','off','linewidth',0.5*lw,'color',0.5*[1 1 1])
                end                
                p = plot(timetrace,-meantrace);
                set(p, 'clipping','off','linewidth',8*lw,'color','k')
                
            else
                if PLOTTRIALS
                p = plot(atime(inds),temp(:,inds));
                set(p, 'clipping','off','linewidth',lw)
                end
                if PLOTSD
                    p = plot(timetrace,ubtrace);
                    set(p, 'clipping','off','linewidth',0.5*lw,'color',0.5*[1 1 1])
                    p = plot(timetrace,lbtrace);
                    set(p, 'clipping','off','linewidth',0.5*lw,'color',0.5*[1 1 1])
                end                
                p = plot(timetrace,meantrace);
                set(p, 'clipping','off','linewidth',8*lw,'color','k')
            end
        catch
        end
        
        if ~isempty(xl)
            xlim(xl);
        end
        if ~isempty(yl)
            if ~isempty(yl{nr})
                if flipvars(nr)==1
                    ylim(sort(-yl{nr}))
                else
                    ylim(yl{nr})
                end
            end
        end
        
        if ~isempty(coltitles{nc})
            title({coltitles{nc}; rowvars{nr}})
        else
            title(rowvars{nr})
        end
    end
    
end

% keep a copy of analog time.
for nc = 1:ncols
    avdata(nc,nrows+1) = {atime};
end
rowvars(end+1) = {'atime_s'};

if nargout
    % In case there have been placeholder variables added, examine only the
    % unique variables    
    [C,IA,IC] = unique(rowvars','stable');
    
    out = cell2table(avdata(:,IA),'VariableNames',rowvars(IA,:)','RowNames',coltitles');
end

end