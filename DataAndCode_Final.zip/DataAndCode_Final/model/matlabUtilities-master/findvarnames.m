function varnames = findvarnames(dataset,str)
% function varnames = findvarnames(dataset,str)
% 
% J. Lucas McKay, Ph.D.
% 28 October 2013

inds = regexp(dataset.Properties.VarNames,str);
varnames = dataset.Properties.VarNames(find(~cellfun('isempty',inds)));

end