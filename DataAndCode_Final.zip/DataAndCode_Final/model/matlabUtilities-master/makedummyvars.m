function [dummyvars,levelnames] = makedummyvars(cellarray)
% function [dummyvars,levelnames] = makedummyvars(cellarray)
% 
% provided with a cell array of strings, this function creates dummy
% numerical variables for each unique string. note that the dummy variables
% are used in the order of appearance in the array cellarray. cellarray
% should be Nx1 or 1xN.
% 
% J. Lucas McKay, Ph.D.
% 20 August 2013

levelnames = unique(cellarray,'stable');
dummyvars = nan(size(cellarray));
for i = 1:length(levelnames)
    dummyvars(strcmp(levelnames{i},cellarray)) = i;
end

end