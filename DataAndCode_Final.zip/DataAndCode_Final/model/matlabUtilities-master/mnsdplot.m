function [handles] = mnsdplot(bardata,xloc)
% function h = mnsdplot(mnsd,xloc)
% 
% mnsd: matrix of mean+sd data, mean in column 1, sd in column 2.
% if xloc is supplied, bars are plotted at those locations.

    if nargin<2
    xloc = 1:size(bardata,1)
    end
    
    b = bar(xloc,bardata(:,1));
    h = b;
    set(b,'facecolor','k')
    for i = 1:size(bardata,1)
        p = plot(xloc(i)*[1 1],bardata(i,1)+[0 bardata(i,2)],'k');
        h(end+1) = p;
        p = plot(xloc(i)*[1 1],bardata(i,1)+[-bardata(i,2) 0],'color',[1 1 1]);
        h(end+1) = p;
    end
    
    if nargout
        handles=h;
    end
   
    xlim([min(xloc)-1 max(xloc)+1])
    set(gca,'xtick',xloc)
end