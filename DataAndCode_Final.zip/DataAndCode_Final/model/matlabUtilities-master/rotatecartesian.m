function [X_prime,Y_prime] = rotatecartesian(arg1,arg2,arg3)

if nargin==2
    theta_deg = arg2;
    X = arg1(:,1);
    Y = arg1(:,2);    
end
if nargin==3
    X = arg1(:);
    Y = arg2(:);
    theta_deg = arg3;
end

X = X(:);
Y = Y(:);

c1 = cosd(theta_deg);
s1 = sind(theta_deg);

X_prime = c1*X + s1*Y;
Y_prime = -s1*X + c1*Y;

if nargout<2
    X_prime = [X_prime Y_prime];
end
end
