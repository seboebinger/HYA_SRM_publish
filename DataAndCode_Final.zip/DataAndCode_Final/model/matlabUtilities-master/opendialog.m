function out = opendialog()
% function out = opendialog()
% 
% Opens a dialog box to choose a .mat file, and loads it as a struct that
% is returned. Useful if you want to load two similar .mat files at once,
% but don't want to supply a string for their location.

[filename,pathname] = uigetfile();

fullfile = [pathname filename];

out = load(fullfile);

end