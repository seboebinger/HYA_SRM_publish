function emg = highpassrectifyEMG(EMG)

SampleRate = 1080;

nyquist_frequency = SampleRate/2;

%%% Create filters
% High pass filter at 35 Hz
[filt_high_B,filt_high_A] = butter(3,35/nyquist_frequency,'high');
% Low pass filter at 40 Hz
[filt_low_B,filt_low_A] = butter(3,40/nyquist_frequency,'low');

%%% Filter EMG signals

% High pass filter at 35 Hz
emg = filtfilt(filt_high_B, filt_high_A,EMG);

% Demean and rectify
emg = abs(demean(emg));

end