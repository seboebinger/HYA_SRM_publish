function out = replicateNrows(in,N)
% function out = replicateNrows(in,N)
%
% takes an n*m matrix and returns an n*N *m matrix where each of the original rows are
% replicated N times. note that this is different from repmat(in,N,1), as
% the rows are ordered as 1 1 1 2 2 2 3 3 3, rather than 1 2 3 1 2 3 1 2 3.

nr1 = size(in,1);
nr2 = nr1*N;
nc = size(in,2);

out = [];

for i = 1:nr1
    for j = 1:N
        out = [out; in(i,:)];
    end
end

end