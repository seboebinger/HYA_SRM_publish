function h = labelfigure(label)
% function h = labelfigure(label)
%
% place a label in the top left of the current figure.
% 
% last edit:
% 2017 03 30
% make textbox smaller
% update handle graphics calls


a = annotation('textbox',[0 0 1 1]);
a.FitBoxToText = 'on';
a.String = label;
a.LineStyle = 'none';
% 
% set(a,'string',label);
% set(a,'fontsize',8);
% set(a,'edgecolor','none')
if nargout
    h = a;
end

% move the object to the back of the list
% set(gca,'children',circshift(allchild(gca),1));
end