function out = shuffle(in)
% function out = shuffle(in)
% 
% returns a random permutation of the matrix in.
% J. Lucas McKay, Ph.D.
% 17 October 2013

temp = in(:);
temp = temp(randperm(length(temp)));
out = reshape(temp,size(in));

end