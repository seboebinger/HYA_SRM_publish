function out = colnum(in)
out = (1:size(in,2));
end