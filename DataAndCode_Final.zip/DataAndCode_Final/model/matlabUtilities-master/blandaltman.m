function [] = blandaltman(variable1,variable2)


7+3


measurementmean = 7+3

measurementdifference



end

